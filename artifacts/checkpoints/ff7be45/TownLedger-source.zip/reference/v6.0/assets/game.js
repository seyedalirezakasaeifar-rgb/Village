// SOURCE: 00-foundation.js
'use strict';
// TownLedger: offline small-town economic policy laboratory. Separate Android WebView adaptation.
(function(){
const ART_DATA={};
const $=id=>document.getElementById(id), clamp=(x,a,b)=>Math.max(a,Math.min(b,x)),money=x=>(x<0?'−':'')+'$'+Math.round(Math.abs(x)).toLocaleString('en-CA');
const fmt=x=>Number(x||0).toLocaleString('en-CA',{maximumFractionDigits:1});
const esc=x=>String(x==null?'':x).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const rn=(a,b)=>a+random()*(b-a),pick=a=>a[random()*a.length|0];
const first=['Arthur','Alice','Thomas','Eleanor','Henry','Margaret','Jack','Edith','Charles','Emily','George','Rose','William','Florence','James','Clara','Robert','Agnes','Daniel','Ivy','Samuel','Hannah','Oliver','Mabel','Edward','Beatrice','Frederick','Ada','Joseph','Grace','Peter','Julia','Benjamin','Isabel'];
const surnames=['Bennett','Parker','Sutton','Miller','Hughes','Clarke','Foster','Wright','Carter','Howard','Taylor','Moore','Campbell','Ward','Russell','Harris','Reed','Turner','Hill','Smith','Brooks','Davies','Morgan','Baker','Wilson','Grant'];
const T=56, TW=72, TH=36, RW=T*TW+140,RH=T*TH+120;
const types={
 bank:{n:'Bank Branch',cost:0,col:'#a3b0a6',jobs:0},
 worksite:{n:'Private Construction Site',cost:0,col:'#c0a076',jobs:0},
 apartment:{n:'Apartment House',cost:0,col:'#b7ab91',jobs:0},
 tower:{n:'High-rise Residences',cost:0,col:'#a0afb1',jobs:0},
 factory:{n:'Manufacturing Works',cost:9800,col:'#879398',jobs:14,build:'Factory'},
 warehouse:{n:'Freight Depot',cost:12000,col:'#927b65',jobs:10,build:'Freight Depot'},
 office:{n:'Commercial Offices',cost:14200,col:'#a5a69b',jobs:13,build:'Office'},
 college:{n:'Private College',cost:18000,col:'#a9a088',jobs:8,build:'College'},
 airport:{n:'Regional Airfield',cost:0,col:'#879c9e',jobs:18},
 metro_station:{n:'Underground Station',cost:18000,col:'#496a7a',jobs:0,build:'Private Underground'},
 repair:{n:'Resurface road',cost:135,col:'#a0a28b',jobs:0,build:'Repair'},
 home:{n:'Cottage',cost:1700,col:'#cbaf75',jobs:0,build:'Home'},
 grocer:{n:'Grocer',cost:4300,col:'#a96d49',jobs:7,build:'Grocer'},
 bakery:{n:'Bakery',cost:3600,col:'#b77b56',jobs:7,build:'Bakery'},
 mill:{n:'Flour Mill',cost:4800,col:'#869888',jobs:8,build:'Flour Mill'},
 farm:{n:'Farm',cost:3100,col:'#ad9d54',jobs:9,build:'Farm'},
 forestry:{n:'Forestry',cost:3000,col:'#6c8d65',jobs:8,build:'Forestry'},
 sawmill:{n:'Sawmill',cost:4100,col:'#ac865e',jobs:8,build:'Sawmill'},
 quarry:{n:'Quarry',cost:3900,col:'#92928d',jobs:8,build:'Quarry'},
 contractor:{n:'Construction Co.',cost:4400,col:'#b2a38e',jobs:8,build:'Contractor'},
 townhall:{n:'Town Hall',cost:0,col:'#d6c6a4',jobs:0},
 police:{n:'Constabulary',cost:7600,col:'#6588a7',jobs:5,build:'Police Station'},
 fire:{n:'Fire Brigade',cost:6900,col:'#bb745b',jobs:5,build:'Fire Brigade'},
 clinic:{n:'Clinic',cost:8000,col:'#bdb7a3',jobs:6,build:'Clinic'},
 park:{n:'Public Green',cost:550,col:'#6c987a',jobs:0,build:'Park'},
 school:{n:'Village School',cost:6900,col:'#ac9372',jobs:0,build:'School'},
 courthouse:{n:'Magistrates Court',cost:8400,col:'#9a9887',jobs:0,build:'Court'},
 watchtower:{n:'Watchtower',cost:4900,col:'#879089',jobs:0,build:'Watchtower'},
 square:{n:'Market Square',cost:2500,col:'#aca486',jobs:0,build:'Market Square'},
 fishery:{n:'River Fishery',cost:3500,col:'#75a5a2',jobs:7,build:'Fishery'},
 tavern:{n:'Village Tavern',cost:3200,col:'#b28c56',jobs:6,build:'Tavern'},
};
const goods={grain:2,flour:3,food:3.3,logs:2,timber:4,stone:3,manufactures:8.5};
const formulas={farm:{out:'grain',qty:140,inp:null,amount:0},mill:{out:'flour',qty:175,inp:'grain',amount:105},bakery:{out:'food',qty:200,inp:'flour',amount:105},grocer:{out:null,qty:0,inp:'food',amount:0},forestry:{out:'logs',qty:170},sawmill:{out:'timber',qty:130,inp:'logs',amount:100},quarry:{out:'stone',qty:125},fishery:{out:'food',qty:130},factory:{out:'manufactures',qty:85,inp:'timber',amount:58}};
const buildIcons={metro_station:'Ⓜ',repair:'↻',road:'═',home:'⌂',grocer:'▣',bakery:'♨',mill:'◈',farm:'❖',forestry:'♣',sawmill:'▥',quarry:'◆',contractor:'⚒',police:'♜',fire:'♨',clinic:'✚',park:'♣',school:'✎',courthouse:'⚖',watchtower:'♜',square:'◉',fishery:'≈',tavern:'♨',factory:'⚙',warehouse:'▤',office:'▦',college:'♜'};
const buildCost={metro_station:18000,road:65,repair:135,home:1700,grocer:4300,bakery:3600,mill:4800,farm:3100,forestry:3000,sawmill:4100,quarry:3900,contractor:4400,police:7600,fire:6900,clinic:8000,park:550,school:6900,courthouse:8400,watchtower:4900,square:2500,fishery:3500,tavern:3200,factory:9800,warehouse:12000,office:14200,college:18000};
const defs=[
 ['incomeTax','Income tax',0,40,1,'%','Share of earnings paid by working residents to the town.'],
 ['profitTax','Business profit tax',0,45,1,'%','Tax on positive net operating profit of private businesses.'],
 ['propertyTax','Property tax (annual)',0,5,.1,'%','Tax on property values, charged to owners daily in annualized instalments.'],
 ['foodTax','Food sales tax',0,30,1,'%','Collected from purchases at local grocers; reduces food affordability.'],
 ['utilityTax','Domestic energy levy',0,30,1,'%','Levied on actual household heating and electricity bills. Raises funds, increases living costs.'],
 ['commercialRate','Business property rate (annual)',0,8,.25,'%','Annual tax on privately operating premises, payable even in years with weak profits.'],
 ['minWage','Minimum daily wage',10,90,1,'$','Raises pay but also raises labour costs for small firms.'],
 ['permitFee','Business entry permit',0,3000,25,'$','Fee charged when an investor opens a new enterprise.'],
 ['policeBudget','Constabulary budget / day',0,800,10,'$','Fund patrols, investigators and public safety. Stations improve coverage.'],
 ['defenseBudget','Fire and civil defence / day',0,800,10,'$','Maintains emergency preparedness. Stations improve response.'],
 ['aidBudget','Housing assistance / day',0,600,10,'$','Direct household transfers, prioritized by hardship and low savings.'],
 ['energyAidBudget','Heating assistance / day',0,400,10,'$','Pays energy bills for low-cash households, especially in winter.'],
 ['transitBudget','Commuter transit / day',0,250,10,'$','Supports journeys to work and improves access to jobs across the borough.'],
 ['outreachBudget','Community outreach / day',0,300,10,'$','Local support services that reduce isolation and some risk factors.'],
 ['employmentSubsidy','Wage subsidy / worker / day',0,15,1,'$','Town reimburses employers per filled job, subject to available funds.'],
 ['importTariff','Import tariff',0,40,1,'%','Adds costs to imported food and industrial materials, producing revenue.'],
 ['healthBudget','Clinic & public health / day',0,500,10,'$','Fund preventive treatment, clinic equipment and household health.'],
 ['educationBudget','School & training / day',0,500,10,'$','Raises worker skill and increases business productivity gradually.'],
 ['roadBudget','Road maintenance / day',0,250,10,'$','Upkeep for roads and local access; poor service lowers trade efficiency.'],
 ['zoningRestriction','Building restrictions',0,100,5,'%','Higher restrictions slow private homebuilding, reducing housing supply.'],
 ['businessRegulation','Business compliance rules',0,100,5,'%','Safeguards can lower workplace incidents but add costs to local firms.'],
 ['militiaBudget','Civil defence volunteers / day',0,400,10,'$','Reserve volunteers who help manage exceptional floods and regional emergencies.'],
 ['bankReserve','Bank minimum reserve',5,35,1,'%','Bank cash reserves against deposits. Higher levels lower lending capacity and help meet withdrawals.'],
 ['lendingRules','Credit underwriting standards',0,100,5,'%','Strict standards constrain risky borrowing but reduce investment and consumption credit.'],
 ['depositGuarantee','Deposit insurance coverage',0,100,5,'%','When a bank fails, cover this share of otherwise lost deposits using available municipal funds.'],
 ['treasuryInvestment','Regional reserve investment share',0,100,5,'%','Share of surplus municipal cash available to buy outside-region securities when trade liquidity is low.']
];
const defaults={incomeTax:12,profitTax:12,propertyTax:1.1,foodTax:4,utilityTax:2,commercialRate:.6,energyAidBudget:35,transitBudget:35,minWage:28,permitFee:250,policeBudget:180,defenseBudget:140,aidBudget:100,outreachBudget:40,employmentSubsidy:0,importTariff:0,healthBudget:70,educationBudget:90,roadBudget:25,zoningRestriction:25,businessRegulation:25,militiaBudget:25,bankReserve:12,lendingRules:35,depositGuarantee:0,treasuryInvestment:60,imports:true};
let G=null,active='',buildMode='',selected=null,paused=false,speed=1,toastTimeout=0,chosenScenario='settlement',draftPolicy={},overlay='none',pendingEvent=null,previousDailyCash=0,autoSaveOK=true,filterPeople='all',filterFirms='all',citizenQuery='',constructionCategory='all',showTutorial=true,roadPainted=new Set(),roadBatchDirty=false;
let bitmap=document.createElement('canvas');bitmap.width=RW;bitmap.height=RH;let bg=bitmap.getContext('2d',{alpha:false,willReadFrequently:false});
const cv=$('view'),ctx=cv.getContext('2d',{alpha:false});let cw=1000,ch=600,dpr=1,cam={x:RW/2,y:RH/2,zoom:.68};let dirty=true,staticDirty=true;let vehicles=[];
// FINANCIAL ECONOMY: banks are separate cash-holding agents. Deposits are
// liabilities, NOT additional currency in the conservation check. Loans move
// actual reserves to borrowers and return principal + interest on repayment.
const FIN_BANK_NAMES=['Vale Mutual Savings','Mercantile & County Bank','First Borough Credit'];

// SOURCE: 05-systems.js
// Deterministic model services. Presentation has its own hash-based randomness.
const RELEASE=Object.freeze({"version":"6.0.0","code":12,"edition":"Seasons of the Vale","schema":4,"package":"org.townledger.vale"});
let rngState=42,visualState=918273,simulationBusy=false;
const perfStats={frames:[],ticks:[],effective:1,backlog:0,days:0,elapsed:0,errors:[]};
function random(){rngState=(rngState+0x6D2B79F5)>>>0;let t=rngState;t=Math.imul(t^(t>>>15),t|1);t^=t+Math.imul(t^(t>>>7),t|61);return ((t^(t>>>14))>>>0)/4294967296;}
function visualRandom(){visualState=(Math.imul(visualState,1664525)+1013904223)>>>0;return visualState/4294967296;}
function hash(n){n=Math.imul((n^0x9e3779b9)>>>0,0x85ebca6b);n^=n>>>13;return (Math.imul(n,0xc2b2ae35)^(n>>>16))>>>0;}
function book(from,to,amount,reason,entity=-1){if(!(amount>0))return;G.transactions=G.transactions||[];G.transactions.push({day:G.day,from,to,amount,reason,entity});if(G.transactions.length>800)G.transactions.splice(0,G.transactions.length-800);}
function ensureSystems(){
 if(!G)return;
 G.nextLoanId=G.nextLoanId??0;G.schema=RELEASE.schema;G.release=RELEASE.version;G.development={fields:0,redevelopments:0,towers:0,airfields:0,...G.development};
 G.investors=G.investors||[{id:0,name:'Vale Property Partnership',cash:0,invested:0,spending:0}];
 G.transactions=G.transactions||[];G.observations=G.observations||[];G.policyExperiments=G.policyExperiments||[];
 G.transport=G.transport||{journeys:[],next:1,arrived:0,delayed:0,cancelled:0};
 G.accounts=G.accounts||{baseline:totalMoney(),maxError:0};
 G.scenarioSeed=G.scenarioSeed||G.worldSeed||42;ensureGoodsAccounts();
 G.housingMarket=G.housingMarket||{rentIndex:1,landIndex:1,transactions:0};
 G.councilArchive=G.councilArchive||[];
 for(const b of G.buildings){if(!b.title)b.title={kind:b.owner>=0?'household':'regional',id:b.owner};if(b.baseValue==null)b.baseValue=b.value;}
}
function propertyInvestor(){ensureSystems();return G.investors[0];}
function financeConstruction(cost,entity=-1){
 if(!Number.isFinite(cost)||cost<=0)return false;
 const investor=propertyInvestor();
 if(investor.cash<cost){const injection=cost-investor.cash;if(G.region<injection)return false;G.region-=injection;investor.cash+=injection;investor.invested+=injection;book('Regional capital',investor.name,injection,'Equity subscription',entity);}
 const contractors=G.firms.filter(f=>f.kind==='contractor'&&!f.closed);
 const local=contractors.length?cost*.44:0;
 investor.cash-=cost;investor.spending+=cost;
 if(local){const c=contractors[G.day%contractors.length];c.cash+=local;c.revenue+=local;book(investor.name,c.name,local,'Construction labour and margin',entity);}
 G.region+=cost-local;book(investor.name,'Regional suppliers',cost-local,'Building materials and external construction',entity);
 return true;
}
function developmentQuote(place,kind,demand){
 const central=clamp(1-(Math.abs(place.x-27)+Math.abs(place.y-27))/50,.12,1),housing=kind==='home';
 const cost=(housing?buildCost.home:types[kind]?.cost||5000)+(housing?G.policy.zoningRestriction*9:G.policy.permitFee);
 const rent=housing?2.5*(3.1+G.policy.zoningRestriction*.035)*G.housingMarket.rentIndex:0;
 const annualNet=housing?rent*360*.66:Math.max(0,(demand.applicants[kind]||0)*4.5)*(1-G.policy.profitTax/100)*12;
 const land=Math.round(700+central*1350+Math.max(0,demand.housingPressure-45)*16);
 const hurdle=.055+G.policy.lendingRules*.00035+(100-demand.confidence)*.0004;
 return {cost,land,rent,annualNet,yield:annualNet/(cost+land),hurdle,central,expected:annualNet-(cost+land)*hurdle};
}
function explainDevelopment(b,q,use){b.investment={day:G.day,use,...q};b.title={kind:'investor',id:0};b.owner=-2;const investor=G.investors[0];if(G.region>=q.land){G.region-=q.land;investor.cash+=q.land;investor.invested+=q.land;book('Regional capital',investor.name,q.land,'Equity for land purchase',b.id);investor.cash-=q.land;G.region+=q.land;book(investor.name,'Regional landowner',q.land,'Parcel title acquired',b.id);}}
function housingMarketDay(force=false){
 const living=G.households.filter(h=>h.people.length),stock=G.buildings.filter(b=>['home','apartment','tower'].includes(b.kind));
 const units=stock.reduce((n,b)=>n+(b.kind==='tower'?9:b.kind==='apartment'?4:1),0);
 const occupied=G.households.filter(h=>h.people.length&&readBuild(h.home)).length;
 const vacancy=Math.max(0,units-occupied),target=clamp(.88+(1-vacancy/Math.max(1,units))* .28+G.policy.zoningRestriction*.002, .65,1.5);
 G.housingMarket.rentIndex=G.housingMarket.rentIndex*.985+target*.015;
 if(G.day%30!==0&&!force)return;
 for(const b of stock){
  const access=graph().portals.has(b.id),central=clamp(1-(Math.abs(b.x-27)+Math.abs(b.y-27))/55,.1,1);
  const want=b.baseValue*G.housingMarket.rentIndex*(.73+central*.23+(access?.10:-.20))*(.7+b.condition*.003);
  b.value=b.value*.88+want*.12;b.marketRent=(b.kind==='tower'?9:b.kind==='apartment'?4:1)*8*G.housingMarket.rentIndex;
 }
 const median=stock.map(b=>b.value).sort((a,b)=>a-b)[Math.floor(stock.length/2)]||0;
 G.housingMarket={...G.housingMarket,units,occupied,vacancy,medianValue:median,landIndex:median/50000};
 // Voluntary acquisitions use existing savings; no occupant is removed.
 const listing=stock.find(b=>b.owner===-2&&b.kind==='home'&&!b.redevelopment);
 if(listing){const price=listing.value*.92,buyer=living.find(h=>h.cash>price+5000);
  if(buyer){buyer.cash-=price;G.investors[0].cash+=price;listing.owner=buyer.id;listing.title={kind:'household',id:buyer.id};G.housingMarket.transactions++;book(buyer.name+' household',G.investors[0].name,price,'Property title purchase; tenancy preserved',listing.id);}}
}
function expireCouncilLetters(){
 const keep=[];for(const item of G.councilInbox||[]){if(G.day-item.day>120){G.councilArchive.unshift({...item,closed:G.day,response:'No council action; existing policy retained'});}else keep.push(item);}
 G.councilInbox=keep;G.councilArchive=G.councilArchive.slice(0,40);
}
function recordObservation(){
 const hm=G.housingMarket||{},fs=G.firms.filter(f=>!f.closed),incomes=G.households.filter(h=>h.people.length).map(h=>(h.income-h.tax)/h.people.length).sort((a,b)=>a-b);
 const obs={day:G.day,population:G.stats.population,employment:G.stats.employment,hardship:G.stats.hardship,treasury:G.treasury,businesses:fs.length,construction:G.projects.length,rentIndex:hm.rentIndex,medianValue:hm.medianValue||0,vacancy:hm.vacancy||0,privateSpend:G.development.privateSpend||0,profit:fs.reduce((n,f)=>n+(f.netProfit||0),0),medianIncome:incomes[Math.floor(incomes.length/2)]||0,bankLiquidity:G.banks.reduce((n,b)=>n+b.cash,0),debt:G.loans.filter(l=>l.status==='active').reduce((n,l)=>n+l.balance,0)};
 G.observations.push(obs);if(G.observations.length>1200)G.observations.shift();
 for(const e of G.policyExperiments){if(!e.after&&G.day-e.day>=180)e.after={...obs};}
}
function validateTown(){
 const issues=[],claimed=new Set(),members=new Set(),workers=new Set();
 for(const b of G.buildings)for(const id of footprintOf(b)){if(claimed.has(id)||G.tiles[id]===1||G.tiles[id]===2||G.landUse?.[id])issues.push('Occupied footprint collision '+b.id+':'+id);claimed.add(id);}
 for(const h of G.households){if(!Number.isFinite(h.cash)||h.cash<-.01)issues.push('Invalid household cash '+h.id);for(const id of h.people){if(members.has(id)||G.people[id]?.hh!==h.id||G.people[id]?.deceased||G.people[id]?.movedAway)issues.push('Household membership '+id);members.add(id);}}
 for(const p of G.people)if(!p.deceased&&!p.movedAway&&!members.has(p.id))issues.push('Unhoused identity '+p.id);
 for(const f of G.firms){if(!Number.isFinite(f.cash)||f.cash<-.01)issues.push('Invalid business cash '+f.id);for(const id of f.workers){if(workers.has(id)||G.people[id]?.job!==f.id)issues.push('Employment ownership '+id);workers.add(id);}}
 for(const b of G.banks)if(!Number.isFinite(b.cash)||b.cash<-.01)issues.push('Bank balance '+b.id);
 for(const v of traffic)for(let i=0;i<v.path.length;i++){if(G.tiles[v.path[i]]!==1)issues.push('Vehicle off road '+v.id);if(i&&Math.abs(v.path[i]%T-v.path[i-1]%T)+Math.abs((v.path[i]/T|0)-(v.path[i-1]/T|0))!==1)issues.push('Invalid route '+v.id);}
 for(const f of G.firms)for(const [k,n] of Object.entries(f.stock))if(!Number.isFinite(n)||n<-.0001)issues.push('Invalid commodity stock '+f.id+':'+k);
 for(const row of goodsBalance())if(!Number.isFinite(row.error)||Math.abs(row.error)>.02)issues.push('Commodity accounting '+row.good+':'+row.error);
 return {ok:issues.length===0,issues,total:totalMoney(),population:G.stats.population,day:G.day};
}
function systemsDay(){
 ensureSystems();housingMarketDay();municipalProcurement();householdFormation();birthsAndGenerations();expireCouncilLetters();commodityPriceReview();
 if(G.day%30===0){const error=Math.abs(totalMoney()-G.accounts.baseline);G.accounts.maxError=Math.max(G.accounts.maxError,error);}
 G.rngState=rngState;
}
function checksum(text){let h=2166136261;for(let i=0;i<text.length;i++){h^=text.charCodeAt(i);h=Math.imul(h,16777619);}return (h>>>0).toString(16);}
function archivePayload(){G.rngState=rngState;G.trafficState={vehicles:traffic,clock:frameClock,elapsed:trafficElapsed,gates:[...intersectionGates],serial:vehicleSerial};G.visualState=visualState;return JSON.stringify(G);}
function percentile(a,p){if(!a.length)return 0;const b=a.slice().sort((x,y)=>x-y);return b[Math.min(b.length-1,Math.floor(b.length*p))];}

// SOURCE: 10-finance.js
function ensureFinance(){
 if(!G)return;
 if(!Array.isArray(G.banks))G.banks=[];
 if(!Array.isArray(G.loans))G.loans=[];
 if(!G.finance)G.finance={failures:0,businessDefaults:0,householdDefaults:0,creditIssued:0,depositLosses:0,insuredPayouts:0,foreclosures:0,downzonings:0,insolvencies:0,bankRuns:0};
 for(const h of G.households){if(!h.deposits||typeof h.deposits!=='object'||Array.isArray(h.deposits))h.deposits={};if(!Number.isFinite(h.creditScore))h.creditScore=.65;}
 for(const f of G.firms){if(!Number.isFinite(f.creditScore))f.creditScore=.68;if(!Number.isFinite(f.lossDays))f.lossDays=0;}
}
function seedBanks(){
 ensureFinance();if(G.banks.length)return;
 const capital=[34000,29000,26000],depositAPY=[.016,.024,.031],loanAPY=[.071,.085,.109];
 for(let i=0;i<3;i++){const equity=Math.min(capital[i],Math.max(0,G.region-50000));G.region-=equity;
  G.banks.push({id:i,name:FIN_BANK_NAMES[i],cash:equity,depositAPY:depositAPY[i],loanAPY:loanAPY[i],closed:false,runDays:0,losses:0,interestEarned:0,interestPaid:0,loansOriginated:0});
 }
 // Voluntary deposits: cash leaves household wallets and enters bank vaults.
 for(const h of G.households){const b=G.banks[h.id%3];const amount=Math.max(0,Math.min(h.cash,Math.round(h.cash*(.08+(h.id%5)*.055))));
  h.cash-=amount;b.cash+=amount;h.deposits[b.id]=amount;
 }
}
function bankDeposits(bankId){let n=0;for(const h of G.households)n+=Math.max(0,h.deposits?.[bankId]||0);for(const f of G.firms)n+=Math.max(0,f.deposits?.[bankId]||0);return n}
function bankLoans(bankId){return G.loans.filter(l=>l.bankId===bankId&&l.status==='active').reduce((n,l)=>n+l.balance,0)}
function bankEquity(b){return b.cash+(b.regionCredit||0)+bankLoans(b.id)-bankDeposits(b.id)}
function availableBank(b){const reserve=Math.max(bankDeposits(b.id)*((G.policy.bankReserve??12)/100),Math.max(0,bankEquity(b))*.30);return Math.max(0,b.cash-reserve)}
function bestBank(loan=false){return G.banks.filter(b=>!b.closed&&availableBank(b)>3500&&bankEquity(b)>1000).sort((a,b)=>loan?a.loanAPY-b.loanAPY:b.depositAPY-a.depositAPY)[0]||null}
function bankLoan(kind,id,amount,term=360){
 ensureFinance();let owner=kind==='firm'?G.firms[id]:G.households[id];if(!owner||owner.closed)return null;
 if(G.loans.some(l=>l.status==='active'&&l.ownerType===kind&&l.ownerId===id))return null;
 const strict=(G.policy.lendingRules??35)/100;const score=clamp(owner.creditScore??.65,.05,.99);
 const ratio=kind==='firm'?amount/Math.max(1,owner.cash+1500):amount/Math.max(1,owner.cash+(owner.deposits?Object.values(owner.deposits).reduce((a,v)=>a+v,0):0));
 if(score < .32+strict*.25||ratio>7.8-strict*3.2||amount<100)return null;
 const b=G.banks.filter(b=>!b.closed&&availableBank(b)>=amount*1.20&&bankEquity(b)>amount*.08).sort((a,b)=>a.loanAPY-b.loanAPY)[0];if(!b)return null;
 const rate=b.loanAPY+strict*.022+(1-score)*.055;
 b.cash-=amount;owner.cash+=amount;
 const loan={id:((G.nextLoanId= Math.max(G.nextLoanId||0,G.loans.length))+1),bankId:b.id,ownerType:kind,ownerId:id,original:amount,balance:amount,rate,term,created:G.day,arrears:0,status:'active',paid:0};
 G.loans.push(loan);b.loansOriginated++;G.finance.creditIssued+=amount;
 if(kind==='firm')owner.debt=(owner.debt||0)+amount;
 return loan;
}
function loanPayments(){
 for(const l of G.loans){if(l.status!=='active'||l.balance<=0)continue;
  const owner=l.ownerType==='firm'?G.firms[l.ownerId]:G.households[l.ownerId];if(!owner){l.status='default';continue;}
  const lender=l.bankId<0?null:G.banks[l.bankId];
  const interest=l.balance*l.rate/360;
  const minPrincipal=Math.min(l.balance,l.original/Math.max(30,l.term));
  const due=minPrincipal+interest;
  // Borrowers cannot pay more than cash. Failed firms cannot create repayment funds.
  const paid=Math.min(Math.max(0,owner.cash),due);
  const paidInterest=Math.min(paid,interest),paidPrincipal=Math.max(0,paid-paidInterest);
  owner.cash-=paid;if(lender&&!lender.closed){lender.cash+=paid;lender.interestEarned+=paidInterest}else G.region+=paid;
  l.balance=Math.max(0,l.balance-paidPrincipal+(interest-paidInterest));l.paid+=paid;
  if(l.ownerType==='firm'){owner.debt=Math.max(0,(owner.debt||0)-paidPrincipal+(interest-paidInterest));owner.expenses=(owner.expenses||0)+paidInterest;}
  if(paid<due*.8){l.arrears++;owner.creditScore=clamp(owner.creditScore-.004,.08,.99);}else {l.arrears=Math.max(0,l.arrears-1);owner.creditScore=clamp(owner.creditScore+.0004,.08,.99);}
  if(l.balance<.01){l.balance=0;l.status='repaid';if(l.ownerType==='firm')owner.debt=0;}
  else if(l.arrears>=95||owner.closed&&l.arrears>=12){
   l.status='default';if(l.ownerType==='firm'){owner.debt=Math.max(0,(owner.debt||0)-l.balance);G.finance.businessDefaults++;}
   else G.finance.householdDefaults++;
   if(lender&&!lender.closed)lender.losses+=l.balance;
   owner.creditScore=clamp(owner.creditScore-.22,.05,.99);
   story((l.ownerType==='firm'?owner.name:'The '+owner.name+' household')+' defaulted on a bank loan of '+money(l.balance)+'.','bad',l.ownerType==='firm'?owner.building:owner.home);
  }
 }
}
function depositTransfer(h,b,amount){
 if(!b||b.closed||amount<=0)return 0;amount=Math.max(0,Math.min(h.cash,amount));h.cash-=amount;b.cash+=amount;h.deposits[b.id]=(h.deposits[b.id]||0)+amount;return amount;
}
function withdrawal(h,b,amount){
 if(!b||b.closed||amount<=0)return 0;amount=Math.min(amount,h.deposits?.[b.id]||0,b.cash);
 h.deposits[b.id]-=amount;b.cash-=amount;h.cash+=amount;return amount;
}
function liquidateBank(b,reason='Insolvent balance sheet'){
 if(b.closed)return;const claims=bankDeposits(b.id);
 b.closed=true;G.finance.failures++;
 // A failed bank's loan assets are sold to regional creditors for a conservative
 // haircut; the cash price funds the receivership. Region receives loan rights.
 let transferred=0;for(const l of G.loans){if(l.bankId!==b.id||l.status!=='active')continue;
  const purchase=Math.min(G.region,Math.max(0,l.balance*.35));G.region-=purchase;b.cash+=purchase;
  l.bankId=-1;transferred++;
 }
 if((b.regionCredit||0)>0){const value=b.regionCredit;const sale=Math.min(G.region,value*.83);G.region-=sale;b.cash+=sale;b.regionCredit=0;}
 const liquidCash=Math.max(0,b.cash),uninsured=clamp(G.policy.depositGuarantee??0,0,100)/100;
 const recovery=claims>0?Math.min(1,liquidCash/claims):1;
 let losses=0,payout=0;
 for(const entity of [...G.households,...G.firms]){
  if(!entity.deposits)continue;const claim=Math.max(0,entity.deposits[b.id]||0);if(!claim)continue;
  const recovered=claim*recovery,shortfall=claim-recovered;
  entity.cash+=recovered;b.cash-=recovered;payout+=recovered;entity.deposits[b.id]=0;
  // A deposit guarantee pays against a quantified loss from municipal funds,
  // not freshly invented reserves. Insufficient budget leaves uncovered losses.
  const insured=Math.min(shortfall*uninsured,G.treasury);
  G.treasury-=insured;entity.cash+=insured;G.finance.insuredPayouts+=insured;
  losses+=shortfall-insured;
 }
 G.finance.depositLosses+=losses;
 G.region+=Math.max(0,b.cash);b.cash=0;
 story(b.name+' entered receivership: '+reason+'. Depositor losses '+money(losses)+', '+transferred+' loans sold to regional lenders.','bad');
}
function regionalCapitalMarket(){
 // Depositor-backed private investment and municipal savings purchase bonds
 // in the outside trading region. Bonds remain assets on lender balance sheets;
 // cash actually moves to the region to finance demand for local exports.
 if(!G||!G.banks)return;
 G.publicReserve=Number.isFinite(G.publicReserve)?G.publicReserve:0;
 for(const b of G.banks){if(b.closed)continue;
  const due=(b.regionCredit||0)*.037/360;
  const paid=Math.min(due,Math.max(0,G.region));
  G.region-=paid;b.cash+=paid;b.interestEarned+=paid;
  if(paid+1e-6<due)b.regionArrears=(b.regionArrears||0)+(due-paid);
  else b.regionArrears=Math.max(0,(b.regionArrears||0)-paid*.15);
 }
 const publicInterest=Math.min(G.region,G.publicReserve*.024/360);
 G.region-=publicInterest;G.treasury+=publicInterest;
 if(G.day%30!==0)return;
 const targetRegion=3500000;
 // Local savings reach external borrowers only when credit is required.
 if(G.region<targetRegion){
  const fraction=clamp((G.policy.treasuryInvestment??60)/100,0,1);
  const invest=Math.max(0,Math.min(210000,(G.treasury-240000)*.30*fraction,targetRegion-G.region));
  if(invest>200){G.treasury-=invest;G.region+=invest;G.publicReserve+=invest;}
  for(const b of G.banks){if(b.closed)continue;
   const claims=bankDeposits(b.id);
   const minimumCash=Math.max(9000,claims*.42);
   const limit=Math.max(0,claims*.54-(b.regionCredit||0));
   const amount=Math.max(0,Math.min(180000,b.cash-minimumCash,limit,targetRegion-G.region));
   if(amount>1000&&bankEquity(b)>claims*.015){b.cash-=amount;b.regionCredit=(b.regionCredit||0)+amount;G.region+=amount;}
  }
 }else if(G.region>targetRegion+1200000){
  // Bond market repayments are actual transfers, not asset write-offs.
  for(const b of G.banks){if(b.closed||!b.regionCredit)continue;
   const redeem=Math.min(b.regionCredit*.10,G.region-(targetRegion+500000));
   if(redeem>0){b.regionCredit-=redeem;G.region-=redeem;b.cash+=redeem;}
  }
 }
 if(G.treasury<25000&&G.publicReserve>0&&G.region>75000){
  const redeem=Math.min(G.publicReserve,85000,G.region-50000);G.publicReserve-=redeem;G.region-=redeem;G.treasury+=redeem;
 }
}
function bankCompetition(){
 if(G.day%90!==0)return;
 // Rates are quoted independently. Liquidity, credit demand, regulation and
 // default histories affect spreads, allowing depositors and borrowers to shop.
 for(const b of G.banks){if(b.closed)continue;
  const deposits=bankDeposits(b.id),liquid=deposits>0?b.cash/deposits:1;
  const stress=Math.max(0,1.25-liquid);
  const demand=clamp((G.stats.businesses||20)/80,0,.6);
  const risk=clamp((G.policy.lendingRules??35)/100,0,1);
  const targetLoan=clamp(.054+b.id*.007+risk*.018+stress*.025+demand*.012,.045,.17);
  b.loanAPY=b.loanAPY*.72+targetLoan*.28;
  const targetDeposit=clamp(.013+b.id*.003+stress*.008+Math.min(.012,targetLoan*.09),.006,.052);
  b.depositAPY=b.depositAPY*.75+targetDeposit*.25;
 }
}
function bankMarketEntry(){
 if(G.day%360!==0||G.banks.length>=9||G.region<100000)return false;
 const operating=G.banks.filter(b=>!b.closed);
 const population=G.stats.population||0;
 if(operating.length>=3&&(population<700||operating.length>=4))return false;
 if(operating.length>=2&&(G.stats.marketConfidence||50)<36)return false;
 const initial=25000+Math.min(15000,Math.max(0,population-350)*14);
 if(G.region<initial+50000)return false;
 G.region-=initial;
 const id=G.banks.length;
 const names=['Riverside Savings & Loan','County Agricultural Credit','Broadway Commercial Bank','East Bank Mutual','Cooperative Industrial Bank','Western Exchange Bank'];
 const bank={id,name:names[(id-3+names.length)%names.length],cash:initial,depositAPY:.027,loanAPY:.081,closed:false,runDays:0,losses:0,interestEarned:0,interestPaid:0,loansOriginated:0};
 G.banks.push(bank);
 let branch=G.buildings.find(b=>b.kind==='bank'&&G.banks[b.bankId]?.closed);
 if(!branch){const candidates=buildableCandidates('business');let place=candidates[0];if(place){branch={id:G.nextId++,kind:'bank',x:place.x,y:place.y,value:75000,condition:100,owner:-1,firm:-1,hh:-1};G.buildings.push(branch);invalidateRoads(false);}}
 if(branch)branch.bankId=id;
 staticDirty=true;dirty=true;
 story(bank.name+' opened after raising '+money(initial)+' in subscribed regional capital. Depositors now have another choice.','good',branch?.id||0);
 return true;
}
function bankDaily(){
 ensureFinance();loanPayments();regionalCapitalMarket();bankCompetition();bankMarketEntry();
 // Keep fulfilled and defaulted loan history bounded; active loans are never discarded.
 if(G.loans.length>2500){const past=G.loans.filter(l=>l.status!=='active');const removable=new Set(past.slice(0,Math.max(0,G.loans.length-1800)).map(l=>l.id));if(removable.size)G.loans=G.loans.filter(l=>!removable.has(l.id));}

 // Overnight funds deposited with the regional clearing market earn a floating yield.
 // Every dollar of interest is paid by that counterparty; no currency is minted.
 for(const b of G.banks){if(b.closed)continue;const yieldRate=clamp(b.depositAPY+.009,.018,.067);const earnings=Math.min(G.region,b.cash*yieldRate/360);G.region-=earnings;b.cash+=earnings;b.interestEarned+=earnings;}
 for(const bank of G.banks){if(bank.closed)continue;const expense=Math.min(bank.cash,4+(bank.loansOriginated||0)*.22);bank.cash-=expense;const beneficiaries=G.households.filter(h=>h.people.length>0);if(beneficiaries.length){let worker=beneficiaries[(G.day+bank.id*17)%beneficiaries.length];worker.cash+=expense*.7;G.region+=expense*.3;}else G.region+=expense;}
 for(const b of G.banks){if(b.closed)continue;
  // Interest accrues daily to depositors as a claim on bank assets.
  // It is capped by the bank's non-impaired equity to avoid uncontrolled negative values.
  const claims=bankDeposits(b.id),cap=Math.max(0,bankEquity(b));
  const interest=Math.min(claims*b.depositAPY/360,cap*.012);
  if(interest>0&&claims>0){for(const entity of [...G.households,...G.firms]){const bal=entity.deposits?.[b.id]||0;if(bal>0)entity.deposits[b.id]+=interest*bal/claims;}
   b.interestPaid+=interest;}
 }
 // Withdrawal/deposit decisions are monthly rather than per-frame.
 if(G.day%30===0){
  for(const h of G.households){if(!h.people.length)continue;const deposited=Object.values(h.deposits||{}).reduce((a,v)=>a+v,0);
   const need=Math.max(0,Math.min(deposited,h.people.length*30-h.cash));
   if(need>0){let remaining=need;const balances=Object.entries(h.deposits).sort((a,b)=>b[1]-a[1]);for(const [id] of balances){if(remaining<=.001)break;remaining-=withdrawal(h,G.banks[+id],remaining);}}
   else if(h.cash>Math.max(900,h.people.length*600)){
    const bank=G.banks.filter(b=>!b.closed&&bankEquity(b)>0).sort((a,b)=>b.depositAPY-a.depositAPY)[0];
    if(bank)depositTransfer(h,bank,(h.cash-h.people.length*500)*.18);
   }
  }
  for(const b of G.banks){if(b.closed)continue;
   // Defaults deteriorate solvency. A reserve shortage generates withdrawals
   // only if confidence is already low, making runs endogenous, not arbitrary.
   const claims=bankDeposits(b.id),capital=bankEquity(b);
   const liquid=claims>0?b.cash/claims:1;
   const requiredEquity=Math.max(2200,claims*.035);
   if(capital>=0&&capital<requiredEquity&&liquid>.25&&G.region>requiredEquity+50000){
    const issue=Math.min(50000,requiredEquity-capital+1500,G.region*.05);
    G.region-=issue;b.cash+=issue;b.equityRaised=(b.equityRaised||0)+issue;
    if(G.day%360===0)story(b.name+' raised '+money(issue)+' in new private equity to strengthen depositor protection.','neutral');
   }
   if(capital<0||liquid<(G.policy.bankReserve??12)/180){b.runDays++;
    const panic=clamp((.16-liquid)*.4+(claims*.03-capital)/Math.max(1,claims)*.5,0,.15);
    if(panic>.005){for(const h of G.households){const d=h.deposits?.[b.id]||0;if(d>0)withdrawal(h,b,d*panic);}
     G.finance.bankRuns++;}
   }else b.runDays=Math.max(0,b.runDays-1);
   if(bankEquity(b)<-100||b.runDays>=12||claims>0&&b.cash<1&&b.runDays>=4)liquidateBank(b,capital<0?'Loan losses exceeded capital':'Sustained deposit withdrawals');
  }
 }
 // Struggling companies can apply for a genuinely funded line of credit.
 if(G.day%60===0){
  const candidate=G.households.filter(h=>h.people.length>0&&h.cash<120&&h.creditScore>.6&&h.worklessness<20).sort((a,b)=>a.cash-b.cash).slice(0,2);
  for(const h of candidate)bankLoan('household',h.id,Math.round(400+h.people.length*210),150);
 }
 if(G.day%35===0){const s=G.firms.filter(f=>!f.closed&&f.cash<2800&&f.age>35&&f.lossDays<14&&f.profit> -45&&f.strain<18&&f.creditScore>.56)
   .sort((a,b)=>a.cash-b.cash).slice(0,Math.max(2,Math.ceil(G.firms.length*.08)));
  for(const f of s){const loan=bankLoan('firm',f.id,Math.round(clamp(6800-f.cash,2300,6500)),420);
   if(loan)story(f.name+' received '+money(loan.original)+' of working-capital credit from '+G.banks[loan.bankId].name+'.','neutral',f.building);
  }
 }
}
function liquidateFirm(f,reason){
 // Insolvent companies dispose of stock/equipment, pay secured creditors, and
 // distribute only the residual to shareholders. Assets cannot pay twice.
 if(!f||f.closed)return false;
 const site=readBuild(f.building);
 const stockValue=Object.entries(f.stock||{}).reduce((n,[key,value])=>n+Math.max(0,value)*(goods[key]||1),0);
 const salvage=Math.max(0,Math.min(G.region,stockValue*.18+(site?.value||0)*.015));
 G.region-=salvage;f.cash+=salvage;
 for(const l of G.loans){if(l.ownerType!=='firm'||l.ownerId!==f.id||l.status!=='active')continue;
  const amount=Math.min(Math.max(0,f.cash),Math.max(0,l.balance));
  f.cash-=amount;l.balance=Math.max(0,l.balance-amount);l.paid+=amount;
  const bank=l.bankId>=0?G.banks[l.bankId]:null;
  if(bank&&!bank.closed)bank.cash+=amount;else G.region+=amount;
  if(l.balance<.01){l.balance=0;l.status='repaid';}
  else {l.status='default';G.finance.businessDefaults++;if(bank&&!bank.closed)bank.losses+=l.balance;f.creditScore=clamp((f.creditScore||.6)-.20,.05,.99);}
 }
 const residual=Math.max(0,f.cash);f.cash=0;f.debt=0;
 const shareholder=G.households[f.owner];if(shareholder)shareholder.cash+=residual;else G.region+=residual;
 for(const [good,qty] of Object.entries(f.stock))goodsEntry(good,'exports',qty);
 f.stock={};f.closed=true;G.finance.insolvencies++;
 for(const id of f.workers)if(G.people[id])G.people[id].job=-1;
 f.workers=[];
 story(f.name+' entered liquidation: '+reason+'. Creditors received asset proceeds before shareholders.','bad',f.building);
 return true;
}
function liquidityStress(){
 // Firms go bankrupt after actual negative operating history and persistent
 // inability to satisfy creditors, not from a random destruction roll.
 for(const f of G.firms){if(f.closed)continue;
  if(f.profit<0&&f.cash<3000)f.lossDays++;else f.lossDays=Math.max(0,(f.lossDays||0)-2);
  if(f.lossDays>68&&f.cash<360)liquidateFirm(f,f.lossDays+' consecutive financially weak days');
 }
}
function outwardMigration(){
 if(G.day%30!==0)return 0;
 const hardship=G.stats.hardship||0,unemployment=G.stats.unemployment||0;
 if(hardship<25&&unemployment<26&&(G.regionalDemand||1)>.68)return 0;
 const chance=clamp(.035+Math.max(0,hardship-25)*.004+Math.max(0,unemployment-26)*.003,0,.27);
 if(random()>chance)return 0;
 const choices=G.households.filter(h=>h.home>=0&&h.people.length>0&&h.stress>42&&h.cash<Math.max(550,h.people.length*260))
  .sort((a,b)=>(b.stress-a.stress)+(a.cash-b.cash)*.005);
 if(!choices.length)return 0;
 const h=choices[0],oldHome=readBuild(h.home),departures=h.people.slice();
 for(const id of departures){const p=G.people[id];if(!p)continue;p.movedAway=true;p.job=-1;
  for(const f of G.firms)if(f.workers.includes(id))f.workers=f.workers.filter(n=>n!==id);
 }
 h.people=[];
 // External migrants take cash with them. Their remaining bank deposits are
 // still real liabilities to external depositors, not municipal residents.
 G.region+=Math.max(0,h.cash);h.cash=0;
 story('The '+h.name+' family left town after persistent hardship and weak job prospects, leaving a vacant home.','bad',oldHome?.id||0);
 recompute();return departures.length;
}
function reverseRedevelopment(){
 if(G.day%60!==0||!G.autoBuild)return false;
 const d=cityDemand();
 // Building owners react to actual vacancy and declining values. A tower will
 // not be razed while families still depend on its units.
 if(d.housingPressure>42||d.homeDemand>12)return false;
 const towers=G.buildings.filter(b=>['tower','apartment'].includes(b.kind)&&!b.redevelopment&&
   !G.projects.some(p=>p.id===b.id));
 for(const b of towers){
  const occupied=(b.units||[]).map(id=>G.households[id]).filter(h=>h&&h.home===b.id&&h.people.some(id=>!G.people[id]?.deceased&&G.people[id]?.movedAway!==true));
  if(occupied.length>1)continue;
  if((G.day-(b.lastRedeveloped||0))<480)continue;
  const cost=b.kind==='tower'?48000:19000;
  if(G.region<cost+30000)continue;
  // Owner pays demolition and conversion; no residents disappear.
  privateContract(cost);
  const sole=occupied[0];const formerUnits=(b.units||[]).slice();b.kind='home';b.footprint=[roadId(b.x,b.y)];invalidateBuildingIndex();invalidateRoads(false);b.units=[];b.hh=sole?.id??-1;b.value=Math.max(35000,Math.round(b.value*.28));b.replacedKind='tower';b.lastRedeveloped=G.day;
  for(const hid of formerUnits){const household=G.households[hid];if(household&&household.id!==sole?.id&&household.home===b.id)household.home=-1;}
  if(sole){sole.home=b.id;if(!G.homes.includes(b.id))G.homes.push(b.id)}
  G.finance.downzonings++;G.development.downzonings=(G.development.downzonings||0)+1;
  staticDirty=true;dirty=true;
  story('Vacancy and falling land values led a developer to replace an underused high-rise with a single residence.','neutral',b.id,b.hh);
  return true;
 }
 return false;
}
function financePanel(){
 ensureFinance();const active=G.loans.filter(l=>l.status==='active');
 const deposits=G.banks.reduce((n,b)=>n+bankDeposits(b.id),0),credit=active.reduce((n,l)=>n+l.balance,0);
 return head('Banking and credit markets')+tip('Banks compete for deposits and make loans from actual available cash. Firms can fail after losses and debt defaults; banks can enter receivership following asset losses and withdrawals. Deposits are liabilities, not extra money.')+
 `<div class="statgrid">${stat('Household deposits',money(deposits))}${stat('Outstanding credit',money(credit))}${stat('Operating banks',G.banks.filter(b=>!b.closed).length+' / '+G.banks.length)}${stat('Bank failures',G.finance.failures)}${stat('Business insolvencies',G.finance.insolvencies)}${stat('Loan defaults',G.finance.businessDefaults+G.finance.householdDefaults)}${stat('Depositor losses',money(G.finance.depositLosses))}${stat('Converted towers',G.finance.downzonings)}</div>`+
 head('Competing institutions')+G.banks.map(b=>`<div class="council-card"><h3>${esc(b.name)} · ${b.closed?'IN RECEIVERSHIP':'OPEN'}</h3>${strip('Deposits owed',money(bankDeposits(b.id)))}${strip('Cash reserves',money(b.cash))}${strip('Loan portfolio',money(bankLoans(b.id)))}${strip('Regional securities',money(b.regionCredit||0))}${strip('Equity after impairments',money(bankEquity(b)))}${strip('Savings interest',Math.round(b.depositAPY*10000)/100+'% annual')}${strip('Base lending rate',Math.round(b.loanAPY*10000)/100+'% annual')}</div>`).join('')+
 head('Current debtors')+active.slice(0,24).map(l=>{const owner=l.ownerType==='firm'?G.firms[l.ownerId]:G.households[l.ownerId];return `<div class="entry"><strong>${esc(owner?.name||'Unknown debtor')}</strong><small> ${money(l.balance)} outstanding · ${(100*l.rate).toFixed(1)}% interest · ${esc(G.banks[l.bankId]?.name||'Regional creditor')}</small></div>`}).join('')+
 head('Municipal savings')+strip('Public regional-bond holdings',money(G.publicReserve||0))+strip('Liquid municipal cash',money(G.treasury))+head('Financial history')+miniChart('deposits')+tip('Council policies influence reserve requirements, credit standards and whether public funds insure part of the deposits lost in a bank liquidation. Bank failures are possible without being guaranteed.');
}


// SOURCE: 20-world.js
function seed(seedValue=42){
 crewDay=-1;crewsUsed=new Map();regionalCrews=0;rngState=(Number(seedValue)>>>0)||42;visualState=918273;traffic=[];trafficClock=0;frameClock=0;trafficElapsed=0;vehicleSerial=0;intersectionGates.clear();
 draftPolicy={};roadBatchDirty=false;
 const tiles=new Array(T*T).fill(0);
 for(let y=0;y<T;y++)for(let x=0;x<T;x++){
   let road=(((x===27||y===27)&&x>=8&&x<=48&&y>=8&&y<=48)||((x===14||x===40)&&y>=14&&y<=40)||((y===14||y===40)&&x>=14&&x<=40)||((x===20||x===34)&&y>=20&&y<=34)||((y===20||y===34)&&x>=20&&x<=34));
   if(road)tiles[y*T+x]=1;
   else if(x<5+Math.sin(y*.2)*1.7 || x===5 && y%4===0)tiles[y*T+x]=2;
   else if((x<11||x>46||y<11||y>46)&&random()<.39)tiles[y*T+x]=3;
   else if(random()<.085)tiles[y*T+x]=3;
 }
 G={version:3,day:1,year:1,month:1,tiles,buildings:[],homes:[],people:[],households:[],firms:[],policy:{...defaults},
    treasury:90000,debt:0,publicReserve:0,region:15000000,projects:[],metro:{cash:0,stations:[],lines:[],fare:2.75,rides:0,revenue:0,expenses:0,dailyRides:0,daysInDeficit:0,operating:false,invested:0},development:{homes:0,firms:0,roads:0,stations:0,lastReport:null,decisions:[]},privateRoads:[],landUse:{},fieldOwner:{},fieldCount:{},airport:null,autoBuild:true,nextId:1,history:[],events:[],journal:[],records:[],stats:{},cumulative:{incomeTax:0,profitTax:0,propertyTax:0,foodTax:0,utilityTax:0,commercialRate:0,permits:0,tariffs:0,spending:0,crime:0,fires:0,welfare:0},cases:[],speed:1,scenario:chosenScenario,achievements:[],council:{approval:65,elections:0,confidence:65,factions:{workers:60,merchants:62,homeowners:60,public:66},lastApproval:65},ambition:'balanced',ambitionDays:{},lastMonth:{},crisesHandled:0,policyOutcomes:[],construction:0,worldSeed:Math.floor(random()*99999999),weather:'clear',season:0,regionalDemand:1,neighborhoods:[],lastEventDay:1,unrest:0,education:46,health:74,historyLong:[]};
 const add=(kind,x,y,opt={})=>{if(G.tiles[roadId(x,y)]===1||G.tiles[roadId(x,y)]===2)throw Error('Founding structure overlaps a roadway or river');G.tiles[roadId(x,y)]=0;let b={id:G.nextId++,kind,x,y,value:Math.round(types[kind].cost*10),condition:100,owner:-1,firm:-1,hh:-1,...opt};G.buildings.push(b);return b};
 add('townhall',26,26,{value:150000});add('police',24,26,{value:90000});add('fire',29,25,{value:80000});add('clinic',28,29,{value:74000});add('school',25,28,{value:70000});add('square',28,26,{value:15000});
 const firms=['grocer','grocer','grocer','bakery','bakery','mill','mill','farm','farm','farm','farm','forestry','forestry','sawmill','quarry','contractor','contractor','grocer','bakery','farm','tavern'];
 let slots=[];
 for(let y=7;y<49;y++)for(let x=7;x<49;x++)if(canPlace(x,y,true))slots.push([x,y]);
 slots=slots.filter(([x,y])=>Math.abs(x-27)+Math.abs(y-27)<35).sort((a,b)=>{let da=Math.abs(a[0]-27)+Math.abs(a[1]-27),db=Math.abs(b[0]-27)+Math.abs(b[1]-27);return da-db+rn(-2,2)});
 slots=slots.filter(([x,y])=>{let h=(x*331+y*113)%11;return h!==2&&h!==4});
 for(let i=0;i<3;i++){const spot=slots.shift();if(spot)add('bank',...spot,{value:75000,bankId:i});}
 for(const kind of firms){
   // At founding, farms and major works already occupy actual land, not a tiny
   // decorative square. Keep candidate lots in sync with newly claimed plots.
   const idx=slots.findIndex(([x,y])=>canPlace(x,y,true,kind)&&(kind!=='farm'||Math.abs(x-27)+Math.abs(y-27)>=18));
   const pos=idx>=0?slots.splice(idx,1)[0]:slots.shift();
   if(pos){const large=LANDMARK_SIZE[kind]&&canPlace(pos[0],pos[1],true,kind);
    const f=createFirm(kind,...pos,true,add);
    if(large&&f){const b=G.buildings.find(b=>b.id===f.building);reserveFootprint(b,kind);}
    slots=slots.filter(([x,y])=>!buildingAt(x,y));
   }
 }
 // Neighbourhoods grow along existing roads, rather than a single wall of
 // identical cottages around the town hall. Preserve each household's address.
 const quarters=[[20,22],[34,22],[21,34],[35,34],[16,27],[39,27]];
 for(let i=0;i<(chosenScenario==='frontier'?32:67)&&slots.length;i++){
   const q=quarters[i%quarters.length];let index=-1,best=Infinity;
   for(let k=0;k<slots.length;k++){
    const [sx,sy]=slots[k];if(!canPlace(sx,sy,true,'home'))continue;
    const d=Math.abs(sx-q[0])+Math.abs(sy-q[1]);
    let crowd=0;for(const building of G.buildings){const reach=Math.abs(sx-building.x)+Math.abs(sy-building.y);
      if(reach<=2)crowd+=building.kind==='home'?1.45:building.kind==='farm'?3.8:building.firm>=0?1.1:.45;
    }
    const score=d*1.7+crowd*1.5+Math.abs(sx-27)*.045+random()*.5;
    if(score<best){best=score;index=k}
   }
   if(index<0)break;
   const p=slots.splice(index,1)[0];const b=add('home',...p,{value:Math.round(rn(35000,70000))});
   const family={id:G.households.length,name:pick(surnames),cash:Math.round(rn(180,3500)),home:b.id,owner:-1,people:[],income:0,rent:0,food:0,tax:0,aid:0,crimeLoss:0,stress:rn(10,30),security:rn(75,100),last:[],worklessness:0};
   G.households.push(family);G.region-=family.cash;G.homes.push(b.id);b.hh=family.id;
 }
 for(let i=0;i<G.households.length;i++){
   const hh=G.households[i];const count=i<35?3:2;
   for(let j=0;j<count;j++){
     let p={id:G.people.length,name:pick(first)+' '+hh.name,age:Math.round(rn(j===0?25:7,j===0?68:68)),skill:rn(.3,1),health:rn(65,100),hh:hh.id,job:-1,life:rn(45,82),last:[]};
     G.people.push(p);hh.people.push(p.id)
   }
 }
 // The five founding farmsteads own actual surrounding wheat or maize fields.
 // Reserve farmland after town lots are allocated so crops never invade roads
 // or homes. Cropland is not itself a decorative building or a cash subsidy.
 for(const f of G.firms.filter(f=>f.kind==='farm')){
  const plots=fieldLotsNear(f,5);let planted=0;
  for(const plot of plots){if(G.tiles[plot.id]!==0||G.landUse[plot.id]||buildingAt(plot.x,plot.y))continue;
    G.landUse[plot.id]=1;G.fieldOwner[plot.id]=f.id;planted++;
  }
  G.fieldCount[f.id]=planted;G.development.fields=(G.development.fields||0)+planted;
 }
 for(let b of G.buildings)if(b.kind==='home')b.owner=(random()<.35?b.hh:random()*G.households.length|0);
 assignJobs();recompute();const counts={population:G.people.length,employment:G.stats.employment,hardship:G.stats.hardship,safety:G.stats.safety,businesses:G.firms.length,treasury:G.treasury};
 G.journal.push({day:1,name:'Village founded',message:'Town hall records open. Follow real people, employers and policy consequences.',baseline:counts});
 G.events.push({day:1,text:'A new council has taken responsibility for the prosperity of the Vale.',type:'neutral'});setupScenario();seedBanks();ensureSystems();initializeScenario();G.scenarioSeed=seedValue;G.accounts={baseline:totalMoney(),maxError:0};housingMarketDay(true);recordObservation();save();
 staticDirty=true;dirty=true;
}
function cityCell(x,y){return x>=0&&x<T&&y>=0&&y<T?G.tiles[y*T+x]:-1}
// A site owns every square in its footprint. Legacy saves without a footprint
// retain their one-square plot; newly built landmarks reserve all their land.
const LANDMARK_SIZE={farm:[2,2],factory:[2,2],warehouse:[2,2],college:[2,2],
 airport:[2,2],metro_station:[2,2],tower:[2,2],apartment:[2,2],school:[2,2]};
function footprintFor(x,y,kind){const [w,h]=LANDMARK_SIZE[kind]||[1,1];const result=[];
 for(let dy=0;dy<h;dy++)for(let dx=0;dx<w;dx++)result.push((y+dy)*T+x+dx);
 return result;}
function footprintOf(b){return Array.isArray(b.footprint)&&b.footprint.length?b.footprint:[roadId(b.x,b.y)];}
let cacheBuildingsFor=null,cacheBuildingsCount=-1,cacheFootprintRevision=0,indexFootprintRevision=-1,
 buildingsByTile=new Map(),buildingsById=new Map();
function invalidateBuildingIndex(){cacheFootprintRevision++;cacheBuildingsCount=-1;}
function refreshBuildingIndex(){if(cacheBuildingsFor===G&&cacheBuildingsCount===G.buildings.length&&indexFootprintRevision===cacheFootprintRevision)return;
 cacheBuildingsFor=G;cacheBuildingsCount=G.buildings.length;indexFootprintRevision=cacheFootprintRevision;
 buildingsByTile=new Map();buildingsById=new Map();
 for(const b of G.buildings){buildingsById.set(b.id,b);for(const id of footprintOf(b))if(!buildingsByTile.has(id))buildingsByTile.set(id,b);}
}
function buildingAt(x,y){if(x<0||x>=T||y<0||y>=T)return null;refreshBuildingIndex();return buildingsByTile.get(y*T+x)||null;}
function nearRoad(x,y){return roadOffsets.some(d=>cityCell(x+d[0],y+d[1])===1)}
function canPlace(x,y,roads=true,kind='home',ignore=null){
 const dims=LANDMARK_SIZE[kind]||[1,1];if(x<2||y<2||x+dims[0]>T-2||y+dims[1]>T-2)return false;
 let access=false;
 for(let dy=0;dy<dims[1];dy++)for(let dx=0;dx<dims[0];dx++){
  const ax=x+dx,ay=y+dy,id=roadId(ax,ay),owner=buildingAt(ax,ay);
  if(![0,3].includes(G.tiles[id])||G.landUse?.[id]||(owner&&owner.id!==ignore?.id))return false;
  if(nearRoad(ax,ay))access=true;
 }
 return !roads||access;
}
function reserveFootprint(b,kind=b.kind){b.footprint=footprintFor(b.x,b.y,kind);for(const id of b.footprint)if(G.tiles[id]===3)G.tiles[id]=0;invalidateBuildingIndex();invalidateRoads(false);staticDirty=true;}
function findLandmarkLot(kind,candidates){return candidates.find(v=>canPlace(v.x,v.y,true,kind))||null;}
function getFootprintIssues(){const occupied=new Map(),issues=[];
 for(const b of G.buildings){for(const id of footprintOf(b)){
  if(!Number.isInteger(id)||id<0||id>=T*T){issues.push('invalid footprint '+b.id);continue;}
  if(G.tiles[id]===1)issues.push('structure on roadway '+b.id+' at '+id);
  if(G.tiles[id]===2)issues.push('structure in water '+b.id+' at '+id);
  if(G.landUse?.[id])issues.push('structure overlapping reserved land '+b.id+' at '+id);
  if(occupied.has(id)&&occupied.get(id)!==b.id)issues.push('overlapping structures '+b.id+' / '+occupied.get(id));
  occupied.set(id,b.id);
 }}return issues;}
function createFirm(kind,x,y,setup=false,addFn=null){
 if(!setup&&!canPlace(x,y,true,kind))return null;
 const b=addFn?addFn(kind,x,y):{id:G.nextId++,kind,x,y,value:Math.round(types[kind].cost*10),condition:100,owner:-1,firm:-1,hh:-1};
 if(!addFn){G.tiles[y*T+x]=0;G.buildings.push(b);if(LANDMARK_SIZE[kind]&&!setup)reserveFootprint(b,kind);}
 const f={id:G.firms.length,building:b.id,name:(kind==='grocer'?'Village Stores':kind==='bakery'?'Baker & Sons':types[kind].n)+' '+pick(['& Co.','Ltd.','Works','Trading','of '+pick(['Oakford','Hawthorn','Eastmead'])]),kind,
 cash:Math.round(rn(10000,24000)),stock:{grain:40,flour:40,food:80,logs:30,timber:30,stone:30},jobs:Math.max(3,Math.ceil(types[kind].jobs*.70)),workers:[],wage:Math.round(rn(26,37)),price:rn(4,7),debt:0,revenue:0,expenses:0,profit:0,tax:0,theft:0,age:0,strain:0,history:[],owner:G.households.length?random()*G.households.length|0:-1};
 if(G.goodsAccounts)for(const [good,qty] of Object.entries(f.stock))goodsEntry(good,'imports',qty);
 G.firms.push(f);b.firm=f.id;if(!setup)invalidateRoads();return f;
}
function assignJobs(){
 if(!G||!G.people)return;
 const free=G.people.filter(p=>!p.deceased&&p.movedAway!==true&&p.age>=16&&p.age<=70&&p.job<0);
 const net=graph(),maxJourney=13+(G.policy.transitBudget||0)/8;
 const vacancies=G.firms.filter(f=>!f.closed&&f.workers.length<f.jobs).sort((a,b)=>(b.wage-a.wage));
 for(const f of vacancies){let workplace=readBuild(f.building),port=net.portals.get(f.building);
  if(!workplace||port==null)continue;
  while(f.workers.length<f.jobs&&free.length){let best=-1,score=Infinity;
   for(let i=0;i<free.length;i++){const candidate=free[i],hh=G.households[candidate.hh],home=hh&&readBuild(hh.home);
    if(!home)continue;const hport=net.portals.get(home.id);if(hport==null||net.parts[hport]!==net.parts[port])continue;
    const distance=roadDistance(hport,port);
    if(distance>maxJourney&&!hasMetroCommute(home,workplace))continue;
    const mismatch=Math.abs(candidate.skill-.7)*3,rank=distance*.74+mismatch+candidate.id*.00001;
    if(rank<score){score=rank;best=i}
   }
   if(best<0)break;const person=free.splice(best,1)[0];person.job=f.id;f.workers.push(person.id);
  }
 }
}
function readBuild(id){refreshBuildingIndex();return buildingsById.get(id)}
function workerIncome(f){return Math.max(G.policy.minWage,f.wage)}
function credit(h,amount){h.cash+=amount}
function transferBudget(to,amount,cat){let paid=Math.max(0,Math.min(G.treasury,amount));G.treasury-=paid;to.cash+=paid;G.cumulative.spending+=paid;return paid}
function story(text,type='neutral',bid=-1,hid=-1){G.events.unshift({day:G.day,text,type,bid,hid});if(G.events.length>160)G.events.length=160}
function transferTreasury(amount,cat){const pay=Math.max(0,amount);G.treasury+=pay;G.cumulative[cat]=(G.cumulative[cat]||0)+pay;return pay}
function regionBuy(f,good,amount,price=marketPrice(good)){if(!f||!G.region)return 0;const portal=graph().portals.get(f.building);const linked=portal!=null&&graph().parts[portal]===graph().mainPart;const access=linked?1:0;const regionalDemand=(1+G.buildings.filter(b=>b.kind==='square').length*.025+G.firms.filter(f=>f.kind==='warehouse'&&!f.closed).length*.065+(G.airport?.operating ? .13 : 0))*(G.scenario==='hardtimes'&&G.day<540?.52:G.scenario==='frontier'&&G.day<280?.78:1);const qty=Math.max(0,Math.min(f.stock[good]||0,amount*access*regionalDemand*clamp(G.regionalDemand||1,.30,1.3),G.region/Math.max(price,1)));const cash=qty*price;f.cash+=cash;G.region-=cash;f.stock[good]-=qty;goodsEntry(good,'exports',qty);f.revenue+=cash;return qty}
function regionImport(f,good,qty){if(!G.policy.imports)return 0;const net=graph(),port=net.portals.get(f.building);if(port==null||net.parts[port]!==net.mainPart)return 0;const tariff=G.policy.importTariff/100;const unit=marketPrice(good)*(1+tariff);let n=Math.max(0,Math.min(qty,Math.floor(f.cash/unit)));if(n<=0)return 0;
 const total=n*unit,levy=total*tariff/(1+tariff);f.cash-=total;f.expenses+=total;f.stock[good]=(f.stock[good]||0)+n;goodsEntry(good,'imports',n);G.region+=total-levy;transferTreasury(levy,'tariffs');return n;
}
function trade(f,good,units){units=Math.max(0,units-pendingGoods(f,good));if(units<=0)return 0;
 const net=graph(),buyer=readBuild(f.building),sourceRoad=net.portals.get(f.building);
 const sources=G.firms.filter(v=>!v.closed&&(v.stock[good]||0)>0&&v.id!==f.id&&(formulas[v.kind]?.out===good||v.kind==='warehouse')).map(v=>{
  const b=readBuild(v.building),port=net.portals.get(v.building);
  const linked=port!=null&&sourceRoad!=null&&net.parts[port]===net.parts[sourceRoad];
  const distance=b&&buyer?roadDistance(sourceRoad,port):Infinity;
  return {f:v,linked,distance,shipping:linked?(0.008+distance*.0009)*clamp(1.42-G.policy.roadBudget/220,.65,1.42):Infinity}
 }).filter(s=>s.linked).sort((a,b)=>a.shipping-b.shipping);
 let left=units;for(const source of sources){const seller=source.f,price=marketPrice(good),unit=price*(1+source.shipping);
  const wear=(G.stats.roadCondition||85),carriageRate=source.shipping*(1+Math.max(0,75-wear)/110);
  let n=Math.min(seller.stock[good],left,Math.floor(f.cash/(price*(1+carriageRate))));if(n<=0)continue;
  const amt=n*price,carriage=n*price*carriageRate;
  seller.cash+=amt;seller.revenue+=amt;f.cash-=amt+carriage;f.expenses+=amt+carriage;G.region+=carriage;G.cumulative.freight=(G.cumulative.freight||0)+carriage;
  seller.stock[good]-=n;dispatchGoods(seller,f,good,n,routeBetween(readBuild(seller.building),readBuild(f.building)));left-=n;if(left<=0)break
 }
 if(left>0)regionImport(f,good,left);
 return units-left;
}

// SOURCE: 25-scenarios.js
// Existing capital in authored starts is funded before the opening balance sheet.
function initializeScenario(){
 if(chosenScenario!=='regional')return;
 G.scenario='regional';Object.assign(G.policy,{incomeTax:13,profitTax:14,zoningRestriction:20,transitBudget:160,policeBudget:300,defenseBudget:220,healthBudget:180,educationBudget:220,aidBudget:250});
 const kinds=['factory','office','warehouse','grocer','bakery','factory','office','contractor','tavern','college'];
 // Reserve actual employment sites before bidding housing onto the remaining land.
 for(let n=0;n<78;n++){
  const kind=kinds[n%kinds.length];let site=buildableCandidates('business').find(p=>canPlace(p.x,p.y,true,kind));
  if(!site){privatelyBuiltRoads({...cityDemand(),homeDemand:100,businessDemand:100,freeLots:0});site=buildableCandidates('business').find(p=>canPlace(p.x,p.y,true,kind));}if(!site)continue;
  const cost=types[kind].cost,capital=21000;if(G.region<cost+capital+50000)break;
  financeConstruction(cost);G.region-=capital;const f=createFirm(kind,site.x,site.y);if(!f)throw Error('Scenario investment lost its parcel');
  f.cash=capital;f.jobs=kind==='factory'?14:kind==='office'?13:kind==='college'?8:Math.max(3,Math.ceil(types[kind].jobs*.70));f.wage=32;f.age=90;
  book('Regional capital',f.name,capital,'Opening enterprise equity',f.building);
 }
 for(let n=0;n<150&&G.stats.population<650;n++){
  const site=buildableCandidates('housing').find(p=>canPlace(p.x,p.y,true,'apartment'));
  if(!site){privatelyBuiltRoads({...cityDemand(),homeDemand:100,businessDemand:100,freeLots:0});continue;}
  const cost=39000;if(!financeConstruction(cost))break;
  const b={id:G.nextId++,kind:'apartment',x:site.x,y:site.y,value:175000,baseValue:175000,condition:93,owner:-2,firm:-1,hh:-1,units:[],title:{kind:'investor',id:0},footprint:footprintFor(site.x,site.y,'apartment')};
  for(const id of b.footprint)if(G.tiles[id]===3)G.tiles[id]=0;G.buildings.push(b);invalidateBuildingIndex();invalidateRoads(false);
  for(let k=0;k<4;k++){const h=addHouseholdAt(b,2500);if(h)b.units.push(h.id);}b.hh=b.units[0]??-1;
  G.development.privateSpend=(G.development.privateSpend||0)+cost;recompute();
 }
 assignJobs();recompute();G.journal.push({day:1,name:'Market Cross opening balance sheet',message:'An established regional borough. Apartment owners and employers funded their land, buildings and working capital before this council took office.',baseline:{...G.stats,treasury:G.treasury}});
 story('Market Cross inherits dense housing, manufacturing and services. Transport investors will judge whether new infrastructure pays.','neutral');
}

// SOURCE: 30-economy.js
function dailyEconomy(){
 const P=G.policy;
 for(const f of G.firms){f.revenue=0;f.expenses=0;f.profit=0;f.tax=0;f.age++;}
 for(const p of G.people)p.publicWork=false;
 for(const h of G.households){h.income=0;h.rent=0;h.food=0;h.tax=0;h.incomeTax=0;h.energyTax=0;h.aid=0;h.utilities=0;h.energyRebate=0;h.travel=0;h.discretionary=0;h.last=[]}
 for(const h of G.households){const target=Math.max(45,h.people.length*12);if(h.cash>=target)continue;for(const [id,amount] of Object.entries(h.deposits||{}).sort((a,b)=>b[1]-a[1])){withdrawal(h,G.banks[+id],Math.min(amount,target-h.cash));if(h.cash>=target)break;}}
 // Working inventory chain: farms -> mills -> bakeries -> grocers, forests -> sawmills.
 for(const kind of ['farm','fishery','forestry','quarry','mill','sawmill','bakery','factory'])for(const f of G.firms){
   if(f.kind!==kind||f.closed)continue;
   const plan=formulas[kind];if(!plan)continue;
   let workforceSkill=f.workers.length?f.workers.reduce((t,id)=>t+(G.people[id]?.skill||.5),0)/f.workers.length:.5;
   let ratio=clamp(f.workers.length/Math.max(1,f.jobs),.15,1)*(.78+workforceSkill*.38)*(1-Math.max(0,65-G.education)*.001);
   if(f.kind==='farm')ratio*=[.75,1.25,1.65,.35][Math.floor((G.month-1)/3)];
   if(f.kind==='farm'){const fields=G.fieldCount?.[f.id]||0;ratio*=1+Math.min(1.8,fields*.055);if(G.weather==='drought')ratio*=.84;}if(f.kind==='farm'&&G.weather==='storm')ratio*=.80;if(f.kind==='farm'&&G.weather==='drought')ratio*=.66;
   ratio*=.94+Math.min(1,G.policy.roadBudget/90)*.06;
   let qty=Math.round(plan.qty*ratio);if(plan.inp){
       const need=Math.max(1,Math.round(plan.amount*ratio));if((f.stock[plan.inp]||0)<need)trade(f,plan.inp,need-(f.stock[plan.inp]||0));
       const used=Math.min(need,f.stock[plan.inp]||0);f.stock[plan.inp]=Math.max(0,(f.stock[plan.inp]||0)-used);goodsEntry(plan.inp,'consumed',used);qty=Math.round(qty*used/need)
   }
   f.stock[plan.out]=(f.stock[plan.out]||0)+qty;goodsEntry(plan.out,'produced',qty);
 }
 // Regional market pays for exports from producing firms, at constrained quantities.
 for(const f of G.firms){if(f.closed)continue;let out=formulas[f.kind]&&formulas[f.kind].out;
   if(out&&f.stock[out]>45)regionBuy(f,out,Math.max(0,f.stock[out]-45)*.57,marketPrice(out)*rn(1.05,1.23));
   if(f.kind==='tavern'){let tourism=Math.max(0,(G.stats.safety||65)*.8+(G.buildings.filter(b=>b.kind==='park'||b.kind==='square').length)*6+rn(-20,30));let income=Math.min(G.region,tourism);G.region-=income;f.cash+=income;f.revenue+=income;}
   if(f.kind==='contractor'){let income=180+Math.round(rn(-45,100));if(G.region>=income){G.region-=income;f.cash+=income;f.revenue+=income}}
 }
 regionalIndustryDay();
 // Grocers purchase wholesale food. Actual stock limits household purchases.
 for(const f of G.firms.filter(f=>f.kind==='grocer'&&!f.closed))if((f.stock.food||0)+pendingGoods(f,'food')<600)trade(f,'food',720-(f.stock.food||0));
 for(const h of G.households){
   if(!h.people.length)continue;
   // private rent transfers to the property owner
   const house=readBuild(h.home);const rent=(h.temporaryHousing?0:1)*h.people.length*(3.1+P.zoningRestriction*.035)*(G.housingMarket?.rentIndex||1);
   const paid=Math.min(h.cash,rent);h.cash-=paid;h.rent+=paid;
   if(house&&G.households[house.owner]&&house.owner!==h.id)credit(G.households[house.owner],paid);
   else if(house&&house.owner===h.id)h.cash+=paid;
   else if(house?.owner===-2)propertyInvestor().cash+=paid;else G.region+=paid;
   // Grocery budget, sales tax and availability are actual transactions
   let need=h.people.length*1.60;let remaining=need;
   const home=readBuild(h.home);const shops=G.firms.filter(f=>f.kind==='grocer'&&!f.closed&&f.stock.food>0).map(f=>({f,score:f.price*.8+Math.abs((readBuild(f.building)?.x||20)-(home?.x||25))*.12+Math.abs((readBuild(f.building)?.y||20)-(home?.y||25))*.12+rn(0,3)})).sort((a,b)=>a.score-b.score).map(o=>o.f);
   for(const shop of shops){let unit=shop.price*(1+P.foodTax/100);let n=Math.min(remaining,shop.stock.food,h.cash/unit);
     if(n<=0)continue;const val=n*unit,tax=n*shop.price*P.foodTax/100;
     h.cash-=val;h.food+=val;shop.cash+=val-tax;shop.revenue+=val-tax;shop.stock.food-=n;goodsEntry('food','consumed',n);transferTreasury(tax,'foodTax');remaining-=n;if(remaining<.01)break;
   }
   if(remaining>.1){h.stress=clamp(h.stress+remaining*1.2,0,100);h.security=clamp(h.security-.04,0,100)}else h.stress=clamp(h.stress-.08,0,100);
   // Power, water and heating are real recurring household expenses, not an abstract happiness modifier.
   const cold=G.month>=10||G.month<=2,storm=G.weather==='storm';
   const essential=h.people.length*(2.25+(cold?2.65:0)+(storm?.9:0));
   const bill=essential*(1+(P.utilityTax||0)/100),paidEnergy=Math.min(h.cash,bill);
   const energyBase=paidEnergy/(1+(P.utilityTax||0)/100),levy=paidEnergy-energyBase;
   h.cash-=paidEnergy;h.utilities=paidEnergy;h.energyTax+=levy;G.region+=energyBase;transferTreasury(levy,'utilityTax');
   if(paidEnergy<bill*.75)h.stress=clamp(h.stress+1.1,0,100);
   // Travelling to work has a cost; the council can fund a partial transit network.
   for(const pid of h.people){const worker=G.people[pid];if(!worker||worker.job<0)continue;const firm=G.firms[worker.job];if(!firm||firm.closed)continue;
     const house=readBuild(h.home),workplace=readBuild(firm.building);if(!house||!workplace)continue;
     const dist=Math.abs(house.x-workplace.x)+Math.abs(house.y-workplace.y);
     const underground=hasMetroCommute(house,workplace)&&G.metro?.operating;
     const fare=underground?G.metro.fare:dist*.035*(1-clamp((P.transitBudget||0)/280,0,.65));
     const farePaid=Math.min(h.cash,fare);
     h.cash-=farePaid;h.travel+=farePaid;
     if(underground){G.metro.cash+=farePaid;G.metro.revenue+=farePaid;G.metro.dailyRides++;G.metro.rides++;}
     else G.region+=farePaid;
   }
 }
 // A mature town must recycle accumulated household savings through local
 // demand, otherwise every firm eventually starves while banks hoard deposits.
 // Families purchase actual manufactured goods, repairs, services and leisure.
 // All amounts leave personal cash/bank vaults and enter the firm's cash account.
 const consumerKinds=new Set(['factory','office','contractor','warehouse','grocer','bakery','sawmill','tavern','college']);
 const consumerStores=G.firms.filter(f=>!f.closed&&consumerKinds.has(f.kind)&&f.workers.length>0&&f.cash>=0);
 if(consumerStores.length){
  for(const h of G.households){if(!h.people.length)continue;
   const deposits=Object.values(h.deposits||{}).reduce((a,v)=>a+v,0);
   const wealth=h.cash+deposits;
   const intended=Math.min(85,Math.max(0,wealth-h.people.length*900)*.00078);
   if(intended<.5)continue;
   if(h.cash<intended){const balances=Object.entries(h.deposits||{}).sort((a,b)=>b[1]-a[1]);for(const [id,amount] of balances){withdrawal(h,G.banks[+id],Math.min(amount,intended-h.cash));if(h.cash>=intended)break;}}
   let budget=Math.min(intended,h.cash);
   const attempts=Math.min(4,consumerStores.length);
   for(let j=0;j<attempts&&budget>.01;j++){
    const f=consumerStores[(h.id*7+G.day*3+j*13)%consumerStores.length];
    const stockItem=f.kind==='factory'?'manufactures':f.kind==='sawmill'?'timber':f.kind==='grocer'?'food':f.kind==='bakery'?'food':null;
    const unit=stockItem?marketPrice(stockItem)*1.35:1;
    const amount=stockItem?Math.min(budget/Math.max(unit,.01),f.stock[stockItem]||0)*unit:budget/Math.max(1,attempts-j);
    if(amount<=.001)continue;
    h.cash-=amount;h.discretionary=(h.discretionary||0)+amount;f.cash+=amount;f.revenue+=amount;budget-=amount;
    if(stockItem){f.stock[stockItem]=Math.max(0,(f.stock[stockItem]||0)-amount/unit);goodsEntry(stockItem,'consumed',amount/unit);}
    h.stress=clamp(h.stress-.003,0,100);
   }
  }
 }
 // Optional household purchases support local hospitality businesses when residents can afford them.
 const taverns=G.firms.filter(f=>f.kind==='tavern'&&!f.closed);
 if(taverns.length)for(const h of G.households){if(h.cash<h.people.length*450)continue;let expense=Math.min(h.cash*.0014,5.5);if(expense<=0)continue;let f=taverns[h.id%taverns.length];h.cash-=expense;f.cash+=expense;f.revenue+=expense;h.leisure=(h.leisure||0)+expense;h.stress=clamp(h.stress-.03,0,100)}
 // Salaries and income taxes (taxes transfer to the treasury).
 for(const f of G.firms){if(f.closed)continue;
   const w=workerIncome(f);let workers=f.workers.length;
   for(const id of f.workers){let p=G.people[id];if(!p)continue;let h=G.households[p.hh];if(!h)continue;
      let gross=Math.min(w,Math.max(0,f.cash));f.cash-=gross;f.expenses+=gross;
      let tax=gross*P.incomeTax/100;h.cash+=gross-tax;h.income+=gross;h.tax+=tax;h.incomeTax+=tax;transferTreasury(tax,'incomeTax');
      if(gross<w*.9){h.stress=clamp(h.stress+1,0,100);f.strain++}
   }
   let subsidy=Math.min(G.treasury,workers*P.employmentSubsidy);if(subsidy){G.treasury-=subsidy;f.cash+=subsidy;G.cumulative.spending+=subsidy}
   let compliance=Math.min(f.cash,(P.businessRegulation/100)*Math.max(1,f.workers.length)*.9);f.cash-=compliance;f.expenses+=compliance;G.region+=compliance;
   let site=readBuild(f.building),due=site?site.value*(P.commercialRate||0)/100/365:0,rate=Math.min(f.cash,due);
   f.cash-=rate;f.expenses+=rate;transferTreasury(rate,'commercialRate');
   f.profit=f.revenue-f.expenses;if(f.profit>0){let tx=Math.min(f.cash,f.profit*P.profitTax/100);f.cash-=tx;f.tax+=tx;transferTreasury(tx,'profitTax');}f.netProfit=f.profit-f.tax;
   // New wage offers respond to losses and a shrinking cash runway, subject to the legal floor.
   if(f.netProfit<0&&f.cash<Math.max(10000,f.wage*Math.max(1,f.workers.length)*90)&&f.wage>P.minWage)f.wage=Math.max(P.minWage,f.wage*.995);
   if(f.cash<80)f.strain+=2;else f.strain=Math.max(0,f.strain-1);
   if(f.strain>55&&!f.closed)liquidateFirm(f,'sustained cash shortages');
   if(f.profit>0&&G.households[f.owner]){let dividend=Math.max(0,Math.min(f.cash*.008,f.profit*.08));f.cash-=dividend;G.households[f.owner].cash+=dividend;}
   f.history.push(f.cash);if(f.history.length>45)f.history.shift();
 }
 // Owners pay property tax; town funds services using existing cash.
 if(P.propertyTax>0)for(const b of G.buildings.filter(b=>['home','apartment','tower'].includes(b.kind))){
    let owner=b.owner===-2?propertyInvestor():G.households[b.owner];if(!owner)continue;let due=b.value*P.propertyTax/100/365;let pay=Math.min(owner.cash,due);owner.cash-=pay;transferTreasury(pay,'propertyTax');
 }
 // Public service budgets pay into households as staff wages, remainder buys regional supplies.
 const services=[['police',P.policeBudget],['fire',P.defenseBudget],['outreach',P.outreachBudget]];
 G.actualServiceFunding={police:0,fire:0,outreach:0};
 for(const [kind,budget] of services){let amt=Math.max(0,Math.min(budget,G.treasury));G.actualServiceFunding[kind]=budget>0?amt/budget:0;if(amt<1)continue;G.treasury-=amt;G.cumulative.spending+=amt;
    const casual=G.people.filter(p=>!p.deceased&&p.movedAway!==true&&p.age>=18&&p.age<=70&&p.job<0),n=Math.min(casual.length,Math.round(amt/30));
    const staff=[];for(let i=0;i<n;i++)staff.push(casual[(G.day*17+i)%casual.length]);
    let salaries=Math.min(amt*.55,staff.length*25),each=staff.length?salaries/staff.length:0;
    for(const p of staff){const h=G.households[p.hh];if(h){h.cash+=each;h.income+=each;p.publicWork=true}}
    G.region+=amt-salaries;
 }
 // Housing assistance reaches financially strained households.
 const hardship=G.households.filter(h=>h.people.length>0).sort((a,b)=>(a.cash/Math.max(1,a.people.length))-(b.cash/Math.max(1,b.people.length)));
 let aid=Math.min(P.aidBudget,G.treasury);for(const h of hardship){if(aid<1)break;if(h.cash/h.people.length>250&&h.stress<55)break;
   const v=Math.min(aid,30);G.treasury-=v;h.cash+=v;h.aid+=v;aid-=v;G.cumulative.welfare+=v;G.cumulative.spending+=v;h.stress=clamp(h.stress-.35,0,100)
 }
 // Targeted heating grants transfer town funds to households most exposed to energy costs.
 let winterAid=Math.min(P.energyAidBudget||0,G.treasury);
 for(const h of hardship){if(winterAid<=0)break;if(h.cash>h.people.length*430&&h.stress<52)continue;
   let eligible=Math.max(0,h.people.length*(G.month>=10||G.month<=2?3.5:1.7));let grant=Math.min(winterAid,eligible);
   G.treasury-=grant;h.cash+=grant;h.energyRebate=grant;h.aid+=grant;G.cumulative.welfare+=grant;G.cumulative.spending+=grant;winterAid-=grant;
 }
 // Firms can recover or new ones arrive if real investment funds survive.
 if(G.day%44===0){const f=G.firms.filter(f=>f.closed&&G.region>10000&&P.permitFee<1500&&random()<clamp(.42+(G.stats.marketConfidence||50)/260-P.businessRegulation/500, .05,.72))[0];if(f){
    let investment=9500+P.permitFee;G.region+=f.cash;G.region-=investment;f.cash=investment-P.permitFee;f.closed=false;f.strain=0;f.lossDays=0;f.wage=Math.max(P.minWage,Math.min(f.wage,f.cash/Math.max(1,f.jobs)/50));transferTreasury(P.permitFee,'permits');story('New investors reopened '+f.name+'.','good',f.building);assignJobs();
 }}
 // Shortage/unemployment affects household wellbeing over time.
 for(const h of G.households){let workers=h.people.filter(id=>G.people[id]&&G.people[id].job>=0).length;
   h.worklessness=workers?0:h.worklessness+1;
   if(h.cash<h.people.length*70)h.stress=clamp(h.stress+.4,0,100);
   if(workers===0)h.stress=clamp(h.stress+.2,0,100);
   if(h.cash>h.people.length*600)h.stress=clamp(h.stress-.2,0,100);
 }
}
function policePower(){const b=G.buildings.filter(b=>b.kind==='police').length,court=G.buildings.filter(b=>b.kind==='courthouse').length;const funded=G.actualServiceFunding?.police??1;return clamp(.035+funded*((G.policy.policeBudget/(G.stats.population*.7+1))*.48 + b*.10+court*.05),.035,.95)}
function defensePower(){const b=G.buildings.filter(b=>b.kind==='fire').length;const funded=G.actualServiceFunding?.fire??1;return clamp(.025+funded*((G.policy.defenseBudget/(G.stats.population*.65+1))*.50+b*.1),.025,.96)}
function incidents(){
 const unemployment=1-G.people.filter(p=>!p.deceased&&p.movedAway!==true&&p.age>=16&&p.age<=70&&(p.job>=0||p.publicWork)).length/Math.max(1,G.people.filter(p=>!p.deceased&&p.movedAway!==true&&p.age>=16&&p.age<=70).length);
 const residentHouseholds=G.households.filter(h=>h.people.length>0);
 const hardship=residentHouseholds.filter(h=>h.stress>60||h.cash<150).length/Math.max(1,residentHouseholds.length);
 const danger=(.075+unemployment*.11+hardship*.07)*G.stats.population/300*(1-policePower()*.7)*(1-Math.min(.4,G.policy.outreachBudget/400)*.24);
 if(random()<danger){let b=pick(G.buildings.filter(b=>['home','grocer','bakery','mill','farm','sawmill','quarry','contractor'].includes(b.kind)));
    if(b){let loss=0,hid=-1;const police=closestRoadBuilding(b.x,b.y,'police');const distance=police?roadServiceDistance(b,police):80;const localCoverage=clamp(1-distance/60,0,1)*policePower();
      if(b.kind==='home'){const h=G.households[b.hh];if(h){hid=h.id;loss=Math.min(h.cash,rn(45,340)*(1-localCoverage*.38));h.cash-=loss;h.crimeLoss+=loss;h.security=clamp(h.security-rn(5,14),0,100);h.stress=clamp(h.stress+2,0,100);}}
      else{const f=G.firms[b.firm];if(f){loss=Math.min(f.cash,rn(130,600)*(1-localCoverage*.38));f.cash-=loss;f.theft+=loss}}
      // stolen cash is redistributed among agents; cannot disappear without a counterparty
      const suspects=G.households.filter(h=>h.id!==hid&&h.people.length);
      const offender=suspects.length?pick(suspects):null;if(offender)offender.cash+=loss;else G.region+=loss;
      let item={day:G.day,offender:offender?.id??-1,loss,resolved:false,text:(b.kind==='home'?'Burglary at '+G.households[b.hh].name+' cottage':'Theft at '+G.firms[b.firm].name)+'; reported loss '+money(loss)+'.',type:'bad',bid:b.id,hid};
      G.cases.unshift(item);G.cases.length=Math.min(G.cases.length,100);emergencyDispatch(b,'police');G.cumulative.crime+=1;story(item.text,'bad',b.id,hid);
    }
 }
 if(random()<.025*G.stats.population/300){const b=pick(G.buildings.filter(b=>b.kind!=='road'));if(b){const station=closestRoadBuilding(b.x,b.y,'fire');const distance=station?roadServiceDistance(b,station):80;const localResponse=clamp(1-distance/58,0,1)*defensePower();let damage=rn(1,16)*(1-localResponse*.78);emergencyDispatch(b,'fire');
     b.condition=clamp(b.condition-damage,0,100);G.cumulative.fires++;
     const recovery=Math.max(0,damage)*b.value/2500;let owner=b.kind==='home'?G.households[b.owner]:G.firms[b.firm];
     if(owner&&owner.cash){let paid=Math.min(owner.cash,recovery);owner.cash-=paid;G.region+=paid;b.condition=clamp(b.condition+paid*2500/b.value,0,100)}
     story('A fire damaged '+(types[b.kind]?types[b.kind].n:'property')+'; estimated '+fmt(damage)+' condition points lost.','bad',b.id)
 }}
}
function recompute(){
 let people=G.people.filter(p=>!p.deceased&&p.movedAway!==true).length,working=G.people.filter(p=>!p.deceased&&p.movedAway!==true&&p.age>=16&&p.age<=70),employed=working.filter(p=>p.job>=0||p.publicWork).length,poor=G.households.filter(h=>h.people.length>0&&(h.cash/Math.max(1,h.people.length)<150||h.stress>65)).length;
 const safety=clamp(Math.round(60+policePower()*34+G.policy.outreachBudget/30-poor/Math.max(1,G.households.filter(h=>h.people.length>0).length)*28),0,100);
 const businessCount=G.firms.filter(f=>!f.closed).length;
 const oldStats=G.stats||{};
 G.stats={population:people,employed,workforce:working.length,employment:working.length?Math.round(employed/working.length*100):100,unemployment:working.length?Math.round((working.length-employed)/working.length*100):0,
   hardship:Math.round(poor/Math.max(1,G.households.filter(h=>h.people.length>0).length)*100),safety,preparedness:Math.round(defensePower()*100),businesses:businessCount,
   cash:G.households.reduce((s,h)=>s+h.cash,0),businessCash:G.firms.reduce((s,f)=>s+f.cash,0),dailyCrime:G.cases.filter(c=>c.day>G.day-30).length,
   income:G.households.reduce((s,h)=>s+h.income,0),townBalance:G.treasury+(G.publicReserve||0)-G.debt};
 for(let k of ['health','education','wellbeing','marketConfidence','roadCondition','roadService','militia','realWages','prosperity','avgCash','compliance','propertyCosts','airPollution'])if(oldStats[k]!=null&&Number.isFinite(oldStats[k]))G.stats[k]=oldStats[k];
 G.stats.health=Math.round(G.health??74);G.stats.education=Math.round(G.education??46);if(G.day%10===1||!G.roadMetrics)G.roadMetrics=roadMetrics();G.stats.roadAccess=G.roadMetrics.totalFirms?Math.round(G.roadMetrics.connectedFirms/G.roadMetrics.totalFirms*100):100;
 if(G.stats.wellbeing==null)G.stats.wellbeing=72;if(G.stats.marketConfidence==null)G.stats.marketConfidence=60;
}
// === MARKET CITY: ENDOGENOUS PRIVATE URBAN DEVELOPMENT ===
// Municipal policy affects the expected returns. Construction itself is paid
// by investors or existing firms, not awarded to the player for free.

// SOURCE: 35-goods-accounts.js
function stockTotals(){
 const totals=Object.fromEntries(Object.keys(goods).map(k=>[k,0]));
 for(const f of G.firms)for(const k of Object.keys(goods))totals[k]+=Number(f.stock[k])||0;
 for(const s of G.freight||[])totals[s.good]=(totals[s.good]||0)+s.qty;
 return totals;
}
function ensureGoodsAccounts(){
 if(!G.goodsAccounts){const opening=stockTotals();G.goodsAccounts=Object.fromEntries(Object.keys(goods).map(k=>[k,{opening:opening[k],produced:0,consumed:0,imports:0,exports:0}]));}
 G.goodsPrices=G.goodsPrices||{...goods};
}
function goodsEntry(good,category,qty){if(!(qty>0)||!G.goodsAccounts?.[good])return;G.goodsAccounts[good][category]+=qty;}
function marketPrice(good){return G?.goodsPrices?.[good]||goods[good]||1;}
function goodsBalance(){
 const stocks=stockTotals();
 return Object.entries(G.goodsAccounts||{}).map(([good,a])=>({good,...a,stock:stocks[good],error:stocks[good]-(a.opening+a.produced+a.imports-a.consumed-a.exports),price:marketPrice(good)}));
}
function commodityPriceReview(){
 if(G.day%30!==0)return;
 const stocks=stockTotals(),demand={grain:0,flour:0,food:G.stats.population*1.6,logs:0,timber:0,stone:G.projects.length*4,manufactures:G.stats.population*.12};
 for(const f of G.firms){if(f.closed)continue;const recipe=formulas[f.kind];if(recipe?.inp)demand[recipe.inp]+=(recipe.amount||0)*Math.max(.15,f.workers.length/Math.max(1,f.jobs));}
 for(const k of Object.keys(goods)){const cover=stocks[k]/Math.max(20,demand[k]),scarcity=clamp(1-cover/5,-1,1),target=goods[k]*(1+scarcity*.22)*Math.pow(clamp(G.regionalDemand,.4,1.3),.10);G.goodsPrices[k]=clamp(G.goodsPrices[k]*.88+target*.12,goods[k]*.65,goods[k]*1.55);}
}

// SOURCE: 40-development.js
function cityDemand(){
 const residents=G.people.reduce((n,p)=>n+Number(!p.deceased&&p.movedAway!==true),0);
 const open=G.firms.filter(f=>!f.closed);
 const jobs=open.reduce((n,f)=>n+f.jobs,0);
 const employed=G.people.reduce((n,p)=>n+Number(!p.deceased&&p.movedAway!==true&&p.job>=0),0);
 const jobVacancy=Math.max(0,jobs-employed);
 const homes=G.buildings.reduce((n,b)=>n+(b.kind==='home'?1:b.kind==='apartment'?4:b.kind==='tower'?9:0),0)+(G.projects||[]).filter(p=>p.kind==='home').length;
 const residentHouseholds=G.households.filter(h=>h.people.length>0);
 const viable=residentHouseholds.filter(h=>h.cash>Math.max(180,h.people.length*125)).length;
 const incomes=residentHouseholds.length?viable/residentHouseholds.length:0;
 const hardship=G.stats.hardship||0;
 const demandJobs=clamp(jobVacancy/Math.max(1,jobs),0,1);
 const regulation=G.policy.zoningRestriction/100;
 const confidence=G.stats.marketConfidence||50;
 const targetPop=residents+clamp(jobVacancy*.42,0,45)+Math.max(0,residents*.018);
 const targetHomes=Math.ceil(targetPop/2.2);
 const housingPressure=clamp((targetHomes-homes)/Math.max(1,homes)*100+50+(incomes-.7)*15,0,100);
 const housingDemand=clamp((targetHomes-homes)*6+jobVacancy*.7+(confidence-50)*.32-hardship*.45-regulation*16,0,100);
 const kinds={};
 for(const f of open)kinds[f.kind]=(kinds[f.kind]||0)+1;
 const ratio=(kind,ideal)=>Math.max(0,Math.min(100,(residents/ideal/(kinds[kind]||.55)-1)*75));
 let applicants={
  grocer:ratio('grocer',45),bakery:ratio('bakery',76),farm:ratio('farm',90),
  mill:ratio('mill',130),forestry:ratio('forestry',170),sawmill:ratio('sawmill',190),
  contractor:ratio('contractor',105),quarry:ratio('quarry',135),tavern:ratio('tavern',145),
  fishery:ratio('fishery',245),factory:residents>=190?ratio('factory',280):0,warehouse:residents>=220?ratio('warehouse',290):0,office:residents>=240?ratio('office',310):0,college:residents>=320?ratio('college',600):0
 };
 const foodShort=G.firms.filter(f=>!f.closed&&f.kind==='grocer').some(f=>(f.stock.food||0)<35);
 if(foodShort){applicants.farm+=12;applicants.bakery+=10;applicants.grocer+=5}
 const businessDemand=Math.round(clamp(Math.max(...Object.values(applicants))*.75+(confidence-50)*.25-hardship*.17-G.policy.permitFee*.007-G.policy.businessRegulation*.11,0,100));
 const freeLots=G.buildings.length<T*T?countBuildableLots(15):0;
 return {residents,homes,jobs,jobVacancy,homeDemand:Math.round(housingDemand),housingPressure:Math.round(housingPressure),businessDemand,applicants,freeLots,confidence,hardship,auto:G.autoBuild!==false};
}
function countBuildableLots(radius){
 let n=0;for(let y=5;y<T-5;y++)for(let x=5;x<T-5;x++)if(Math.abs(x-27)+Math.abs(y-27)<radius&&canPlace(x,y))n++;
 return n;
}
function buildableCandidates(focus='housing'){
 const net=graph(),places=[];
 for(let y=5;y<T-5;y++)for(let x=5;x<T-5;x++){
  if(!canPlace(x,y))continue;
  const adjacent=roadOffsets.map(([dx,dy])=>roadId(x+dx,y+dy)).filter(id=>net.parts[id]===net.mainPart);
  if(!adjacent.length)continue;
  let houses=0,work=0,competition=0;
  for(const b of G.buildings){const d=Math.abs(b.x-x)+Math.abs(b.y-y);
   if(d>10)continue;
   if(b.kind==='home')houses+=1/(1+d*.3);
   if(b.firm>=0&&!G.firms[b.firm]?.closed)work+=1/(1+d*.3);
   if(focus==='business'&&b.kind==='grocer')competition+=1/(1+d*.35);
  }
  const edge=Math.abs(x-27)+Math.abs(y-27);
  const score=(focus==='housing'?work*2.2+houses*.65:houses*2.4+work*.75-competition*.15)-edge*.05+random()*1.7;
  places.push({x,y,score});
 }
 places.sort((a,b)=>b.score-a.score);
 return places;
}
function privateContract(cost){return financeConstruction(cost);}
function privatelyBuiltRoads(demand){
 if(G.region<30000||G.policy.zoningRestriction>=95)return false;
 if(demand.residents<145||(demand.homeDemand<12&&demand.businessDemand<20))return false;
 if(demand.freeLots>105&&G.day%120!==0)return false;
 const net=graph(),prospects=[];
 for(const id of net.neighbors.keys()){
  if(net.parts[id]!==net.mainPart)continue;
  const x=id%T,y=id/T|0;
  for(const [dx,dy] of roadOffsets){const xx=x+dx,yy=y+dy;
   if(xx<5||xx>=T-5||yy<5||yy>=T-5||![0,3].includes(cityCell(xx,yy))||G.landUse?.[roadId(xx,yy)]||buildingAt(xx,yy))continue;
   const near=[[-1,0],[1,0],[0,-1],[0,1]].filter(([ddx,ddy])=>cityCell(xx+ddx,yy+ddy)===1).length;
   if(near>2)continue;
   let growth=0,blocked=0;
   for(const b of G.buildings){let d=Math.abs(b.x-xx)+Math.abs(b.y-yy);if(d<=5)growth+=b.kind==='home'?.9:1.6;}
   for(const [ax,ay] of roadOffsets)if(cityCell(xx+ax,yy+ay)===0&&!G.landUse?.[roadId(xx+ax,yy+ay)]&&!nearRoad(xx+ax,yy+ay)&&!buildingAt(xx+ax,yy+ay))blocked++;
   const radial=Math.abs(xx-27)+Math.abs(yy-27);
   if(radial<8||radial>38)continue;
   const score=growth*.24+blocked*2+radial*.055-near*1.1+random()*1.9;
   prospects.push({x:xx,y:yy,dx,dy,score});
  }
 }
 if(!prospects.length)return false;
 prospects.sort((a,b)=>b.score-a.score);
 let chosen=prospects[0],changes=[];
 // Extend a real branch, not a disconnected decorative road.
 for(let k=0;k<Math.min(4,2+(demand.homeDemand>40?2:0));k++){
  let x=chosen.x+chosen.dx*k,y=chosen.y+chosen.dy*k;
  if(x<4||y<4||x>=T-4||y>=T-4||![0,3].includes(cityCell(x,y))||G.landUse?.[roadId(x,y)]||buildingAt(x,y))break;
  changes.push(roadId(x,y));
 }
 if(!changes.length)return false;
 const cost=changes.length*buildCost.road;
 if(G.region<cost+25000)return false;
 for(const id of changes){G.tiles[id]=1;G.privateRoads.push(id);ensureRoadWear();G.roadWear[id]=100;}
 privateContract(cost);
 G.development.roads+=changes.length;G.development.privateSpend=(G.development.privateSpend||0)+cost;
 G.construction+=changes.length;
 invalidateRoads(false);staticDirty=true;dirty=true;
 story('A private land syndicate extended '+changes.length+' road lots to open building plots.','good');
 return true;
}
function startDevelopmentProject(kind,place,value,days,extra={}){
 const target=kind==='firm'?extra.firmKind:kind;
 if(!canPlace(place.x,place.y,true,target))return null;
 const b={id:G.nextId++,kind:'worksite',x:place.x,y:place.y,value,condition:100,owner:-1,firm:-1,hh:-1,developer:true,footprint:footprintFor(place.x,place.y,target)};
 for(const id of b.footprint)if(G.tiles[id]===3)G.tiles[id]=0;
 G.buildings.push(b);
 G.projects.push({id:b.id,kind,remaining:days,duration:days,start:G.day,...extra});
 staticDirty=true;dirty=true;
 G.development.started=(G.development.started||0)+1;
 return b;
}
function completeDevelopmentProjects(){
 if(!G.projects?.length)return;
 let changed=false;
 for(let i=G.projects.length-1;i>=0;i--){
  const p=G.projects[i];if(!constructionWork(p))continue;p.remaining--;
  if(p.remaining>0)continue;
  if(p.kind==='fields'){G.projects.splice(i,1);completeFarmFields(p);changed=true;continue;}
  const b=readBuild(p.id);
  G.projects.splice(i,1);
  if(!b)continue;
  if(p.kind==='public'){b.kind=p.publicKind;b.title={kind:'municipal',id:0};b.owner=-1;story(types[b.kind].n+' opened after publicly financed construction.','good',b.id);
  }else if(p.kind==='home'){
   b.kind='home';b.value=p.value;b.baseValue=p.value;b.developer=true;b.owner=-2;b.title={kind:'investor',id:0};
   const name=pick(surnames),cash=Math.min(G.region,Math.max(700,p.savings));
   G.region-=cash;
   const h={id:G.households.length,name,cash,home:b.id,owner:-1,people:[],income:0,rent:0,food:0,tax:0,incomeTax:0,energyTax:0,utilities:0,travel:0,aid:0,crimeLoss:0,stress:24,security:88,last:[],worklessness:0};
   b.hh=h.id;G.households.push(h);G.homes.push(b.id);
   for(let k=0;k<2;k++){let person={id:G.people.length,name:pick(first)+' '+name,age:Math.floor(rn(20,46)),skill:rn(.36,1),health:rn(65,96),hh:h.id,job:-1,life:rn(45,80),last:[]};G.people.push(person);h.people.push(person.id)}
   G.development.homes++;
   story('Cottage construction finished and the '+name+' household moved in.','good',b.id,h.id);
  }else if(p.kind==='redevelop'){
   completeRedevelopment(b,p);
  }else if(p.kind==='airport'){
   completeAirfield(b,p);
  }else if(p.kind==='firm'){
   b.kind=p.firmKind;b.value=types[b.kind].cost*10;
   const capital=Math.min(p.capital,Math.max(0,G.region-1000));
   const fee=Math.min(G.policy.permitFee,Math.max(0,G.region-capital));
   G.region-=capital+fee;
   const f=createFirm(b.kind,b.x,b.y,true,()=>b);
   f.cash=capital;transferTreasury(fee,'permits');
   if(G.policy.lendingRules<70&&(G.stats.marketConfidence||50)>48&&G.day%3===0){const loan=bankLoan('firm',f.id,Math.round(Math.min(2400,capital*.17)),480);if(loan)f.jobs=Math.min(18,f.jobs+1)}
   G.development.firms++;
   story('New private enterprise completed: '+f.name+' opened its doors.','good',b.id);
  }
  G.construction++;changed=true;
 }
 if(changed){invalidateRoads(false);recompute();assignJobs();staticDirty=true;dirty=true}
}
function privatelyBuiltHome(demand){
 if(demand.homeDemand<9||demand.hardship>57||demand.confidence<22||G.region<35000||demand.residents>=2000||G.policy.zoningRestriction>=94)return false;
 const approval=clamp(1-G.policy.zoningRestriction/125-G.policy.propertyTax/18,0,1);
 if(random()>approval)return false;
 const lots=buildableCandidates('housing');if(!lots.length)return false;
 const place=lots[0],quote=developmentQuote(place,'home',demand),cost=quote.cost;
 if(quote.expected<=0){G.development.lastRejected={day:G.day,reason:'Expected housing yield below funding hurdle',...quote};return false;}
 const savings=clamp(Math.round(rn(1250,3900)),500,4500);
 if(G.region<cost+savings+10000)return false;
 const value=Math.round(38000+demand.housingPressure*240);
 const site=startDevelopmentProject('home',place,value,18+Math.round(rn(0,14)),{value,savings});
 if(!site)return false;privateContract(cost);explainDevelopment(site,quote,'housing');
 G.development.privateSpend=(G.development.privateSpend||0)+cost;
 story('A housing developer broke ground for a privately financed cottage.','good',site.id);
 return true;
}
function privatelyBuiltFirm(demand){
 if(demand.businessDemand<17||demand.hardship>70||G.region<120000||G.policy.permitFee>2800||G.policy.zoningRestriction>=90)return false;
 const capacity=G.people.filter(p=>!p.deceased&&p.movedAway!==true&&p.age>=16&&p.age<=70&&p.job<0).length;
 if(capacity<3&&!(demand.confidence>48&&demand.homeDemand>15&&G.region>250000))return false;
 const ranked=Object.entries(demand.applicants).sort((a,b)=>b[1]-a[1]);
 const approval=clamp(.65+(demand.confidence-50)/160-G.policy.businessRegulation/180-G.policy.profitTax/130,0.07,.95);
 if(random()>approval)return false;
 const candidates=buildableCandidates('business');
 let kind=null,place=null;
 for(const [choice,score] of ranked){
  if(score<13)break;
  const competitors=G.firms.filter(f=>f.kind===choice&&!f.closed&&f.age>45);
  if(competitors.length>=2&&competitors.filter(f=>f.netProfit< -75).length>competitors.length*.55)continue;
  const spot=candidates.find(v=>canPlace(v.x,v.y,true,choice)&&(choice!=='fishery'||[-1,0,1].some(dx=>[-1,0,1].some(dy=>cityCell(v.x+dx,v.y+dy)===2))));
  if(spot){kind=choice;place=spot;break}
 }
 if(!kind||!place)return false;
 const quote=developmentQuote(place,kind,demand);if(quote.expected<=0){G.development.lastRejected={day:G.day,reason:'Expected enterprise yield below funding hurdle',...quote};return false;}
 const capital=11500+Math.round(rn(0,7000));
 const fee=G.policy.permitFee,buildingCost=types[kind].cost;
 if(G.region<capital+fee+buildingCost+25000)return false;
 const site=startDevelopmentProject('firm',place,types[kind].cost*10,24+Math.round(rn(0,20)),{firmKind:kind,capital});
 if(!site)return false;privateContract(buildingCost);explainDevelopment(site,quote,kind);
 G.development.privateSpend=(G.development.privateSpend||0)+buildingCost+capital;
 story('Private investors started building a '+types[kind].n.toLowerCase()+' after evaluating market demand.','good',site.id);
 return true;
}
function stationHubs(){
 const candidates=buildableCandidates('business').filter(c=>canPlace(c.x,c.y,true,'metro_station'));
 return candidates.map(c=>{let residents=0,workplaces=0;
  for(const b of G.buildings){const d=Math.abs(b.x-c.x)+Math.abs(b.y-c.y);if(d<=7){if(b.kind==='home')residents+=8-d;if(b.firm>=0&&!G.firms[b.firm]?.closed)workplaces+=10-d;}}
  return {...c,demand:residents+workplaces*1.35};
 }).sort((a,b)=>b.demand-a.demand);
}
function stationBuilding(place){
 if(!canPlace(place.x,place.y,true,'metro_station'))return null;
 const b={id:G.nextId++,kind:'metro_station',x:place.x,y:place.y,value:180000,condition:100,owner:-1,firm:-1,hh:-1,private:true,footprint:footprintFor(place.x,place.y,'metro_station')};
 G.buildings.push(b);G.metro.stations.push(b.id);G.development.stations++;return b;
}
function connectMetro(a,b,newStations=0){
 const len=Math.abs(a.x-b.x)+Math.abs(a.y-b.y);
 const price=buildCost.metro_station*newStations+len*1100;
 // The two station buildings have already been created before this function is called.
 if(G.metro.cash<price)return false;
 G.metro.cash-=price;
 const share=price*.24;
 const constructors=G.firms.filter(f=>f.kind==='contractor'&&!f.closed);
 if(constructors.length){const c=constructors[G.day%constructors.length];c.cash+=share;c.revenue+=share;G.region+=price-share;}
 else G.region+=price;
 G.metro.lines.push({from:a.id,to:b.id,length:len,built:G.day,readyDay:G.day+85,color:['#e4ba67','#7cb5ba','#b78cb9','#cf887d'][G.metro.lines.length%4]});
 G.metro.invested+=price;G.development.privateSpend=(G.development.privateSpend||0)+price;
 return true;
}
function metroExpansion(demand){
 if(!G.metro||G.policy.zoningRestriction>=92||demand.residents<350||G.region<160000)return false;
 if(demand.confidence<40||demand.hardship>45)return false;
 const hubs=stationHubs();if(hubs.length<2)return false;
 const metro=G.metro;
 // Private shareholders subscribe equity; the franchise pays its construction bills.
 if(!metro.stations.length){
  const a=hubs[0],b=hubs.find(p=>Math.abs(p.x-a.x)+Math.abs(p.y-a.y)>=11&&p.demand>10);
  if(!b)return false;
  const route=Math.abs(a.x-b.x)+Math.abs(a.y-b.y),cost=2*buildCost.metro_station+route*1100;
  if(G.region<cost+100000)return false;
  const shares=cost+36000;
  G.region-=shares;metro.cash+=shares;
  const aa=stationBuilding(a),bb=stationBuilding(b);
  if(!aa||!bb)throw Error('Metro land reservation failed');
  if(!connectMetro(aa,bb,2))throw Error('Underground capital budget mismatch');
  metro.operating=false;G.construction+=2;staticDirty=true;dirty=true;
  story('Private investors opened the Vale Underground: a two-station railway financed from subscribed shares and fares. Inspect the rail network in the map overlays.','good',aa.id);
  return true;
 }
 // Extensions need an observed passenger market and sufficient retained earnings.
 if(demand.residents<540+metro.stations.length*90||metro.cash<70000||metro.stations.length>=8||metro.rides<250)return false;
 const existing=metro.stations.map(id=>readBuild(id)).filter(Boolean);
 const outer=hubs.find(c=>existing.every(s=>Math.abs(s.x-c.x)+Math.abs(s.y-c.y)>=9)&&c.demand>18);
 if(!outer)return false;
 const near=existing.slice().sort((a,b)=>Math.abs(a.x-outer.x)+Math.abs(a.y-outer.y)-Math.abs(b.x-outer.x)-Math.abs(b.y-outer.y))[0];
 const cost=buildCost.metro_station+(Math.abs(near.x-outer.x)+Math.abs(near.y-outer.y))*1100;
 if(metro.cash<cost+18000)return false;
 const station=stationBuilding(outer);
 if(!station)return false;
 if(!connectMetro(near,station,1))throw Error('Underground extension budget mismatch');
 G.construction++;staticDirty=true;dirty=true;
 story('The privately owned Vale Underground extended its railway to a new neighbourhood.','good',station.id);
 return true;
}
function hasMetroCommute(home,work){
 const metro=G?.metro;
 if(!home||!work||!metro?.operating||!metro.lines?.length)return false;
 if(Math.abs(home.x-work.x)+Math.abs(home.y-work.y)<7)return false;
 // Stops within walking distance of the origin and destination, plus connected lines.
 const start=metro.stations.filter(id=>{const b=readBuild(id);return b&&Math.abs(b.x-home.x)+Math.abs(b.y-home.y)<=6;});
 const goal=new Set(metro.stations.filter(id=>{const b=readBuild(id);return b&&Math.abs(b.x-work.x)+Math.abs(b.y-work.y)<=6;}));
 if(!start.length||!goal.size)return false;
 const visited=new Set(start),queue=start.slice();
 for(let i=0;i<queue.length;i++){
  const at=queue[i];if(goal.has(at))return true;
  for(const line of metro.lines){if(line.readyDay>G.day)continue;const next=line.from===at?line.to:line.to===at?line.from:null;
   if(next!=null&&!visited.has(next)){visited.add(next);queue.push(next)}
  }
 }
 return false;
}
function metroOperatingDay(){
 const metro=G?.metro;if(!metro?.stations?.length)return;
 const openLines=metro.lines.filter(line=>!line.readyDay||line.readyDay<=G.day);if(!openLines.length){metro.operating=false;return;}
 const cost=5+metro.stations.length*3+metro.lines.length*5+metro.dailyRides*.025;
 const paid=Math.min(metro.cash,cost);
 metro.cash-=paid;G.region+=paid;metro.expenses+=paid;
 metro.operating=metro.cash>=cost;
 if(metro.revenue-paid<0)metro.daysInDeficit++;
 else metro.daysInDeficit=Math.max(0,metro.daysInDeficit-1);
 if(!metro.operating&&G.day%30===0)story('The private underground suspended trains after its operating reserve ran out.','bad');
 metro.dailyRides=0;
}
function drawMetroOverlay(g,subdued=false){
 if(!G.metro?.lines?.length)return;
 g.save();g.lineWidth=5;g.globalAlpha=subdued?.28:.90;
 for(let i=0;i<G.metro.lines.length;i++){
  const line=G.metro.lines[i],a=readBuild(line.from),b=readBuild(line.to);
  if(!a||!b)continue;
  const p=iso(a.x,a.y),q=iso(b.x,b.y);
  g.strokeStyle='#17232c';g.lineWidth=9;g.beginPath();g.moveTo(p[0],p[1]);g.lineTo(q[0],q[1]);g.stroke();
  g.strokeStyle=line.color;g.lineWidth=4;g.setLineDash([10,5]);g.beginPath();g.moveTo(p[0],p[1]);g.lineTo(q[0],q[1]);g.stroke();g.setLineDash([]);
  if(G.metro.operating&&(!line.readyDay||line.readyDay<=G.day)){
   const phase=(frameClock*.115+i*.21)%2,t=phase<=1?phase:2-phase;
   const xx=p[0]+(q[0]-p[0])*t,yy=p[1]+(q[1]-p[1])*t;
   g.save();g.translate(xx,yy);g.rotate(Math.atan2(q[1]-p[1],q[0]-p[0]));
   g.fillStyle='#f2e8c7';g.strokeStyle='#182c32';g.lineWidth=1.3;
   for(let wagon=-1;wagon<=1;wagon++){g.fillRect(wagon*12-5,-4,10,8);g.strokeRect(wagon*12-5,-4,10,8);
    g.fillStyle=line.color;g.fillRect(wagon*12-3,-3,6,3);g.fillStyle='#f2e8c7';}
   g.restore();
  }
 }
 if(!subdued)for(const id of G.metro.stations){const s=readBuild(id);if(!s)continue;let [x,y]=iso(s.x,s.y);
  g.fillStyle='#17232c';g.beginPath();g.arc(x,y,14,0,Math.PI*2);g.fill();g.fillStyle='#f6d17c';g.beginPath();g.arc(x,y,10,0,Math.PI*2);g.fill();g.fillStyle='#203035';g.font='bold 13px sans-serif';g.textAlign='center';g.fillText('M',x,y+4);
 }
 g.restore();
}
// Regional economy. Decisions are derived from physical land, capital and
// observable demand. The city player sets rules; agents invest their own funds.
function regionalIndustryDay(){
 if(!G)return;
 let factories=0,depots=0;
 for(const f of G.firms){
  if(f.closed)continue;
  if(f.kind==='factory')factories++;
  if(f.kind==='warehouse'){
   depots++;
   const freight=Math.min(G.region,290+Math.min(300,G.firms.filter(v=>!v.closed).length*3));
   G.region-=freight;f.cash+=freight;f.revenue+=freight;
  }else if(f.kind==='office'){
   const services=Math.min(G.region,390+Math.max(0,G.stats.marketConfidence-40)*3);
   G.region-=services;f.cash+=services;f.revenue+=services;
  }else if(f.kind==='college'){
   const students=G.households.filter(h=>h.cash>900&&h.people.some(id=>{const p=G.people[id];return p&&!p.deceased&&p.movedAway!==true&&p.age>=16&&p.age<=28})).slice(0,36);
   for(const h of students){const fee=Math.min(h.cash,8.5);h.cash-=fee;h.educationExpense=(h.educationExpense||0)+fee;f.cash+=fee;f.revenue+=fee;const candidate=h.people.map(id=>G.people[id]).find(p=>p&&!p.deceased&&p.movedAway!==true&&p.age>=16&&p.age<=28);
    if(candidate)candidate.skill=clamp(candidate.skill+.00007,0,1.1);
   }
   const research=Math.min(G.region,200);G.region-=research;f.cash+=research;f.revenue+=research;
   G.education=clamp(G.education+.002,0,100);
  }
 }
 G.stats.airPollution=clamp(factories*6+depots*1.5+(G.airport?.operating?4:0)-G.buildings.filter(b=>b.kind==='park').length*.6,0,100);
 // Pollution affects specific nearby families rather than a free-floating score.
 if(factories&&G.day%10===0){const plants=G.firms.filter(f=>f.kind==='factory'&&!f.closed).map(f=>readBuild(f.building)).filter(Boolean);
  for(const h of G.households){const home=readBuild(h.home);if(!home)continue;
   if(plants.some(b=>Math.abs(b.x-home.x)+Math.abs(b.y-home.y)<=4))h.stress=clamp(h.stress+.18,0,100);
  }
 }
}
function fieldLotsNear(farm,limit=6){
 const site=readBuild(farm.building);if(!site)return [];
 const result=[];
 for(let radius=1;radius<=6;radius++)for(let dy=-radius;dy<=radius;dy++)for(let dx=-radius;dx<=radius;dx++){
  if(Math.abs(dx)+Math.abs(dy)!==radius)continue;
  const x=site.x+dx,y=site.y+dy,id=roadId(x,y);
  if(x<3||y<3||x>=T-3||y>=T-3||G.tiles[id]!==0||G.landUse?.[id]||buildingAt(x,y))continue;
  // Grow a continuous farm belt, not isolated strips inside the central square.
  const civicDistance=Math.abs(x-27)+Math.abs(y-27);
  if(civicDistance<8)continue;
  result.push({id,x,y,score:(civicDistance>17?4:0)+(Math.abs(dx)+Math.abs(dy))*-.22+(G.tiles[roadId(x-1,y)]===3?.3:0)});
 }
 result.sort((a,b)=>b.score-a.score);
 return result.slice(0,limit);
}
function farmDistrictExpansion(demand){
 if(demand.residents<115||G.policy.zoningRestriction>=95||G.region<25000)return false;
 const farms=G.firms.filter(f=>f.kind==='farm'&&!f.closed&&f.cash>300);
 if(!farms.length)return false;
 const shortages=G.firms.filter(f=>f.kind==='mill'&&!f.closed).some(f=>(f.stock.grain||0)<70);
 let chosen=null,lots=[];
 for(const f of farms.sort((a,b)=>(G.fieldCount?.[a.id]||0)-(G.fieldCount?.[b.id]||0))){
  if((G.fieldCount?.[f.id]||0)>=15)continue;
  if(G.projects.some(p=>p.kind==='fields'&&p.firmId===f.id))continue;
  const possible=fieldLotsNear(f,4+Math.round(demand.residents/500));
  if(possible.length>=2){chosen=f;lots=possible;break}
 }
 if(!chosen)return false;
 if(!shortages&&(G.development.fields||0)>demand.residents*.14&&random()<.65)return false;
 const investment=lots.length*480;
 if(G.region<investment+10000)return false;
 G.landUse=G.landUse||{};G.fieldOwner=G.fieldOwner||{};G.projects=G.projects||[];
 for(const item of lots){G.landUse[item.id]=2;G.fieldOwner[item.id]=chosen.id;}
 const id=G.nextId++;
 G.projects.push({id,kind:'fields',firmId:chosen.id,plots:lots.map(v=>v.id),remaining:16+Math.ceil(lots.length/2),start:G.day});
 privateContract(investment);
 G.development.privateSpend=(G.development.privateSpend||0)+investment;
 staticDirty=true;dirty=true;
 story('A farmers’ cooperative cleared and planted '+lots.length+' plots of cropland outside town.','good',chosen.building);
 return true;
}
function completeFarmFields(project){
 G.fieldCount=G.fieldCount||{};
 let planted=0;
 for(const id of project.plots||[]){
  if(G.landUse?.[id]!==2||G.fieldOwner?.[id]!==project.firmId)continue;
  G.landUse[id]=1;planted++;
 }
 G.fieldCount[project.firmId]=(G.fieldCount[project.firmId]||0)+planted;
 G.development.fields=(G.development.fields||0)+planted;
 G.construction+=planted;
 story('Harvest fields established: '+planted+' new plots are producing crops.','good',G.firms[project.firmId]?.building||-1);
 staticDirty=true;dirty=true;
}
function ownerCompensation(building){
 if(building.owner===-2)return 0;
 const seller=G.households[building.owner],price=building.value*1.05,investor=propertyInvestor();
 if(G.region<price)return 0;
 G.region-=price;investor.cash+=price;investor.invested+=price;book('Regional capital',investor.name,price,'Equity subscription for property acquisition',building.id);
 investor.cash-=price;if(seller)seller.cash+=price;else G.region+=price;
 book(investor.name,seller?seller.name+' household':'Regional landowner',price,'Property acquisition with protected tenancy',building.id);
 building.owner=-2;building.title={kind:'investor',id:0};return price;
}
function urbanRedevelopment(demand){
 if(demand.residents<290||demand.confidence<33||demand.hardship>65||G.policy.zoningRestriction>=78)return false;
 if(G.projects.some(p=>p.kind==='redevelop'))return false;
 const taller=demand.residents>=620&&G.policy.zoningRestriction<=53&&demand.housingPressure>=37;
 const target=taller?'tower':'apartment',maxUnits=taller?9:4;
 if(demand.homeDemand<12&&demand.housingPressure<58)return false;
 let candidates=G.buildings.filter(b=>b.kind==='home'||(taller&&b.kind==='apartment'));
 candidates=candidates.filter(b=>!b.redevelopment&&nearRoad(b.x,b.y)&&Math.abs(b.x-27)+Math.abs(b.y-27)<(taller?22:27)&&
  (footprintOf(b).length>=4||canPlace(b.x,b.y,true,target,b)));
 candidates.sort((a,b)=>{
  const av=(Math.abs(a.x-27)+Math.abs(a.y-27))*1.4+(a.kind==='apartment'?2:0)+(a.units?.length||1)*2;
  const bv=(Math.abs(b.x-27)+Math.abs(b.y-27))*1.4+(b.kind==='apartment'?2:0)+(b.units?.length||1)*2;
  return av-bv;
 });
 const b=candidates[0];if(!b)return false;
 const cost=target==='tower'?155000:39000;
 if(G.region<cost+b.value*1.05+80000)return false;
 ownerCompensation(b);
 b.redevelopment={kind:target,started:G.day,remaining:target==='tower'?75:38};
 const occupants=b.units||[b.hh];for(const id of occupants){const h=G.households[id];if(h?.people.length)h.temporaryHousing={project:b.id,since:G.day,provider:'Prepaid regional relocation contract'};}
 if(footprintOf(b).length<4)reserveFootprint(b,target);
 G.projects.push({id:b.id,kind:'redevelop',target,remaining:b.redevelopment.remaining,duration:b.redevelopment.remaining,start:G.day,formerValue:b.value,priorKind:b.kind,units:maxUnits});
 privateContract(cost);
 G.development.privateSpend=(G.development.privateSpend||0)+cost;
 staticDirty=true;dirty=true;
 story('A private developer acquired planning approval to replace '+(b.kind==='apartment'?'an older apartment house':'a cottage')+' with a '+(taller?'residential tower':'four-unit apartment block')+'.','neutral',b.id,b.hh);
 return true;
}
function addHouseholdAt(building,capital=1700){
 if(G.people.filter(p=>!p.deceased&&p.movedAway!==true).length>=2000)return null;
 const cash=Math.min(G.region,capital);if(cash<500)return null;
 G.region-=cash;
 const h={id:G.households.length,name:pick(surnames),cash,home:building.id,owner:-1,people:[],income:0,rent:0,food:0,tax:0,incomeTax:0,energyTax:0,utilities:0,travel:0,aid:0,crimeLoss:0,stress:27,security:86,last:[],worklessness:0};
 G.households.push(h);
 const occupants=Math.min(2,2000-G.people.filter(p=>!p.deceased&&p.movedAway!==true).length);
 for(let j=0;j<occupants;j++){
  const p={id:G.people.length,name:pick(first)+' '+h.name,age:Math.floor(rn(20,54)),skill:rn(.35,1),health:rn(65,97),hh:h.id,job:-1,life:rn(45,80),last:[]};G.people.push(p);h.people.push(p.id);
 }
 return h;
}
function completeRedevelopment(b,p){
 const existing=b.kind==='apartment'?(b.units||[]).slice():(b.hh>=0?[b.hh]:[]);
 for(const id of existing){if(G.households[id])delete G.households[id].temporaryHousing;}
 b.replacedKind=p.priorKind||b.kind;b.kind=p.target;b.owner=-2;b.title={kind:'investor',id:0};b.redevelopment=null;b.lastRedeveloped=G.day;
 b.value=p.target==='tower'?560000:175000;
 b.units=existing;
 for(let k=b.units.length;k<p.units;k++){
  const h=addHouseholdAt(b,1800+Math.round(rn(0,2500)));
  if(!h)break;b.units.push(h.id);
 }
 if(b.units.length)b.hh=b.units[0];
 G.development.redevelopments=(G.development.redevelopments||0)+1;
 if(p.target==='tower')G.development.towers=(G.development.towers||0)+1;
 story('A '+(p.target==='tower'?'high-rise':'mid-rise apartment block')+' opened where older housing once stood. Existing residents retained homes; new families moved in.','good',b.id,b.hh);
}
function airfieldCandidate(){
 const net=graph();const options=[];
 const vectors=[[1,0],[0,1]];
 for(let y=7;y<T-7;y++)for(let x=7;x<T-7;x++){
  if(!canPlace(x,y,true,'airport'))continue;
  const adjoining=roadOffsets.map(([dx,dy])=>roadId(x+dx,y+dy)).find(id=>net.parts[id]===net.mainPart);
  if(adjoining==null)continue;
  const distance=Math.abs(x-27)+Math.abs(y-27);
  if(distance<12||distance>36)continue;
  for(const [dx,dy] of vectors){const runway=[];
   for(let i=2;i<=7;i++)for(let w=0;w<2;w++){
    const xx=x+dx*i+(dy?w:0),yy=y+dy*i+(dx?w:0),id=roadId(xx,yy);
    if(xx<3||yy<3||xx>=T-3||yy>=T-3||![0,3].includes(cityCell(xx,yy))||G.landUse?.[id]||buildingAt(xx,yy)){runway.length=0;break}
    runway.push(id);
   }
   if(runway.length!==12)continue;
   options.push({x,y,runway,score:distance*.22+random()*1.2});
  }
 }
 options.sort((a,b)=>b.score-a.score);
 return options[0];
}
function airfieldInvestment(demand){
 if(G.airport||demand.residents<520||demand.confidence<38||G.policy.zoningRestriction>=72||G.region<850000)return false;
 const site=airfieldCandidate();if(!site)return false;
 const outlay=225000;
 const terminal=startDevelopmentProject('airport',site,450000,120,{runway:site.runway});
 if(!terminal)return false;
 G.airport={building:terminal.id,firm:null,runway:site.runway,operating:false,passengers:0,freight:0,flights:0,initialCost:outlay,started:G.day};
 G.landUse=G.landUse||{};
 for(const id of site.runway)G.landUse[id]=2;
 privateContract(outlay);
 G.development.privateSpend=(G.development.privateSpend||0)+outlay;
 staticDirty=true;dirty=true;
 story('A regional aviation company began constructing an airfield and runway with subscribed private capital.','good',terminal.id);
 return true;
}
function completeAirfield(b,p){
 if(!G.airport||G.airport.building!==b.id)return;
 b.kind='airport';b.value=780000;b.private=true;
 for(const id of p.runway||[])if(G.landUse?.[id]===2)G.landUse[id]=3;
 const capital=Math.min(G.region,140000);G.region-=capital;
 const f=createFirm('airport',b.x,b.y,true,()=>b);
 f.cash=capital;f.wage=36;f.jobs=18;f.kind='airport';
 G.airport.firm=f.id;G.airport.operating=true;
 G.development.airfields=(G.development.airfields||0)+1;
 story('The privately financed regional airfield opened. Tickets, freight and visitors now support its operation.','good',b.id);
}
function airfieldOperatingDay(){
 const a=G.airport;if(!a||a.firm==null)return;
 const f=G.firms[a.firm];if(!f||f.closed){a.operating=false;return}
 const residents=G.people.reduce((n,p)=>n+Number(!p.deceased&&p.movedAway!==true),0);
 const visitors=Math.max(0,Math.min(30,Math.floor(residents/115)+(G.stats.marketConfidence||55)/14));
 const flights=Math.max(1,Math.floor(visitors/3));
 const receipts=Math.min(G.region,visitors*18+flights*42);
 G.region-=receipts;f.cash+=receipts;f.revenue+=receipts;
 const fuel=Math.min(f.cash,flights*25+62);f.cash-=fuel;f.expenses+=fuel;G.region+=fuel;
 a.passengers+=visitors;a.freight+=flights*.4;a.flights+=flights;
 a.operating=f.cash>1000;
 if(!a.operating&&G.day%30===0)story('The airfield faces a cash crisis; scheduled flights are suspended.','bad',a.building);
}
function paintDenseBuilding(g,b,x,y){
 const tower=b.kind==='tower',floors=tower?9:4,width=tower?31:27,h=floors*10;
 const by=y+TH/2+8;
 g.fillStyle='#1b2525aa';g.beginPath();g.ellipse(x+6,by+10,width,11,0,0,Math.PI*2);g.fill();
 g.fillStyle=tower?'#758b93':'#ad9c86';g.fillRect(x-width/2,by-h,width,h);
 g.fillStyle=tower?'#536973':'#846f5e';g.beginPath();g.moveTo(x+width/2,by-h);g.lineTo(x+width/2+15,by-h-7);g.lineTo(x+width/2+15,by-7);g.lineTo(x+width/2,by);g.fill();
 g.fillStyle=tower?'#a3bac0':'#dbcead';g.fillRect(x-width/2-2,by-h-6,width+4,6);
 for(let floor=0;floor<floors;floor++){
  for(let col=0;col<3;col++){
   g.fillStyle=((b.id+floor*3+col)%5===0)?'#e5c67b':tower?'#aec8cc':'#d7c19e';
   g.fillRect(x-width/2+4+col*(width-7)/3,by-h+7+floor*10,Math.max(3,(width-13)/3),5);
  }
 }
 g.fillStyle='#303d3d';g.fillRect(x-4,by-14,8,14);
 if(b.redevelopment){g.strokeStyle='#dcb86e';g.lineWidth=1.5;for(let i=-width/2;i<width/2;i+=12){g.beginPath();g.moveTo(x+i,by);g.lineTo(x+i,by-h+3);g.stroke()}}
}
function paintAirfieldTerminal(g,b,x,y){
 const by=y+TH/2+8;
 g.fillStyle='#26383b';g.fillRect(x-33,by-12,66,17);
 g.fillStyle='#afc5c0';g.fillRect(x-31,by-28,62,18);
 g.fillStyle='#506872';for(let i=-25;i<=23;i+=12)g.fillRect(x+i,by-23,8,10);
 g.fillStyle='#ebd49a';g.fillRect(x-34,by-32,68,5);
 g.fillStyle='#f2e5c4';g.font='bold 10px sans-serif';g.fillText('AIR',x-12,by-15);
 g.fillStyle='#dde8e3';g.beginPath();g.moveTo(x-17,by+2);g.lineTo(x+10,by-1);g.lineTo(x+19,by+3);g.lineTo(x+3,by+5);g.lineTo(x,by+10);g.lineTo(x-4,by+5);g.closePath();g.fill();
}

function autonomousDevelopment(){
 if(!G||!G.development)return;
 const demand=cityDemand();
 G.development.lastReport={day:G.day,homeDemand:demand.homeDemand,businessDemand:demand.businessDemand,freeLots:demand.freeLots,jobVacancy:demand.jobVacancy};
 if(!G.autoBuild)return;
 let built=[];
 if(privatelyBuiltRoads(demand))built.push('roads');
 if(privatelyBuiltHome(demand))built.push('housing');
 if(privatelyBuiltFirm(demand))built.push('business');
 if(metroExpansion(demand))built.push('underground');
 if(farmDistrictExpansion(demand))built.push('fields');
 if(urbanRedevelopment(demand))built.push('redevelopment');
 if(airfieldInvestment(demand))built.push('airfield');
 if(reverseRedevelopment())built.push('downzoning');
 if(built.length){
  G.development.decisions.push({day:G.day,kind:built.join(', '),demand:demand.homeDemand,commercial:demand.businessDemand});
  if(G.development.decisions.length>120)G.development.decisions.shift();
  recompute();assignJobs();
 }
}
function developmentPanel(){
 const d=G.development||{},p=d.lastReport||cityDemand(),m=G.metro||{stations:[],lines:[],cash:0,rides:0};
 const status=G.autoBuild?'Investors respond to demand automatically.':'Private construction paused by player.';
 return `<div class="statgrid">${stat('Housing demand',p.homeDemand+'/100')}${stat('Business demand',p.businessDemand+'/100')}${stat('Private road lots',d.roads||0)}${stat('Projects under construction',G.projects?.length||0)}${stat('Private road tolls',money(d.privateRoadTolls||0))}${stat('Private homes',d.homes||0)}${stat('New enterprises',d.firms||0)}${stat('Underground stations',m.stations.length)}${stat('Subway rides',fmt(m.rides||0))}${stat('Rail operator cash',money(m.cash||0))}${stat('Agricultural district plots',d.fields||0)}${stat('Apartment redevelopments',d.redevelopments||0)}${stat('Residential towers',d.towers||0)}${stat('Private airfields',d.airfields||0)}${stat('Downzoned properties',d.downzonings||0)}${stat('Regional passengers',fmt(G.airport?.passengers||0))}${stat('Industrial employers',G.firms.filter(f=>!f.closed&&['factory','warehouse','office'].includes(f.kind)).length)}</div>`+
 `<p class="desc">${esc(status)} Road developers finance extensions from regional capital; housing developers choose lots near jobs, and merchants enter underserved markets. Underground investors evaluate population and density, then fund stations and tunnels. Farmers acquire field plots and raise grain output; factory owners and freight depots respond to supply and demand; landlords may replace cottages with apartments or towers after assembling a site; and airport investors require a major regional market, a clear runway, and long-term operating capital. The railway pays ongoing costs from fares. Income, profit and property taxes, zoning and business rules influence investment.</p>`+
 `<p class="desc">${m.stations.length?esc('Vale Underground — '+(m.lines?.some(line=>line.readyDay>G.day)?'construction in progress':m.operating?'operating':'service suspended')+' · '+m.lines.length+' line(s) · '+money(m.fare)+' fare · '+money(m.revenue||0)+' lifetime receipts'):'No subway yet. Investors usually require at least 350 residents, sufficient density and financial confidence.'}</p>`;
}


// SOURCE: 42-construction.js
// A day of work requires a crew and materials; elapsed time alone cannot finish a site.
let crewDay=-1,crewsUsed=new Map(),regionalCrews=0;
function constructionWork(project){
 if(project.kind==='fields')return true;
 if(crewDay!==G.day){crewDay=G.day;crewsUsed=new Map();regionalCrews=0;}
 const builders=G.firms.filter(f=>f.kind==='contractor'&&!f.closed&&f.workers.length>=2&&f.cash>50);
 const builder=builders.find(f=>(crewsUsed.get(f.id)||0)<Math.max(1,Math.floor(f.workers.length/2)));
 if(!builder){
  // External crews are part of the already-paid regional construction contract.
  if(!G.policy.imports||regionalCrews>=2){project.stalledDays=(project.stalledDays||0)+1;project.reason='No funded construction crew available';return false;}
  regionalCrews++;project.builder='Regional construction service';project.workedDay=G.day;project.reason='Paid external crew working';return true;
 }
 crewsUsed.set(builder.id,(crewsUsed.get(builder.id)||0)+1);
 const scale=project.kind==='airport'?5:project.target==='tower'?3:project.kind==='redevelop'?2:1;
 const timber=.6*scale,stone=.35*scale;
 if((builder.stock.timber||0)<timber*4)trade(builder,'timber',timber*10-(builder.stock.timber||0));
 if((builder.stock.stone||0)<stone*4)trade(builder,'stone',stone*10-(builder.stock.stone||0));
 project.builder=builder.name;
 if((builder.stock.timber||0)<timber||(builder.stock.stone||0)<stone){project.stalledDays=(project.stalledDays||0)+1;project.reason='Waiting for paid timber or stone deliveries';return false;}
 builder.stock.timber-=timber;builder.stock.stone-=stone;goodsEntry('timber','consumed',timber);goodsEntry('stone','consumed',stone);
 project.workedDay=G.day;project.reason='Crew and materials available';return true;
}
function birthsAndGenerations(){
 if(G.day%90!==0||G.stats.population>=2000)return;
 let count=0;
 for(const h of G.households){
  if(!h.people.length||h.people.length>=6||h.stress>48||G.day-(h.lastBirth||-720)<720)continue;
  const people=h.people.map(id=>G.people[id]).filter(p=>!p.deceased&&!p.movedAway),adults=people.filter(p=>p.age>=20&&p.age<=42);
  if(!adults.length||people.filter(p=>p.age<16).length>=2||!people.some(p=>p.job>=0))continue;
  const savings=h.cash+Object.values(h.deposits||{}).reduce((n,a)=>n+a,0);
  const security=clamp((savings/Math.max(1,h.people.length)-400)/3500,0,1),cost=clamp(1-(G.housingMarket.rentIndex-1)*.5,.35,1.15);
  if(random()>.085*security*cost)continue;
  const id=G.people.length,p={id,name:pick(first)+' '+h.name,age:0,skill:.05,health:94,hh:h.id,job:-1,life:80,last:[]};
  G.people.push(p);h.people.push(id);h.lastBirth=G.day;count++;if(G.stats.population+count>=2000)break;
 }
 if(count)story(count+' '+(count===1?'child was':'children were')+' born in local households. Family finances, housing and confidence influence household formation.','good');
}

// SOURCE: 45-public-services.js
// Councils authorize service budgets; procurement chooses sites and finances works.
function municipalProcurement(){
 if(G.day%30!==0||G.projects.some(p=>p.kind==='public'))return;
 const services=[['school',260,G.policy.educationBudget],['clinic',350,G.policy.healthBudget],['police',400,G.policy.policeBudget],['fire',450,G.policy.defenseBudget]];
 for(const [kind,capacity,budget] of services){
  const count=G.buildings.filter(b=>b.kind===kind).length;
  if(G.stats.population<=count*capacity||budget<60)continue;
  const cost=buildCost[kind],programmes=['policeBudget','defenseBudget','educationBudget','healthBudget','aidBudget','roadBudget'].reduce((n,k)=>n+G.policy[k],0);
  if(G.treasury<cost+programmes*45)continue;
  const candidates=buildableCandidates('housing').filter(p=>canPlace(p.x,p.y,true,kind));
  const site=candidates[0];if(!site)return;
  const b=startDevelopmentProject('public',site,cost*10,45,{publicKind:kind,duration:45});if(!b)return;
  b.footprint=footprintFor(site.x,site.y,kind);b.title={kind:'municipal',id:0};
  const contractors=G.firms.filter(f=>!f.closed&&f.kind==='contractor'),local=contractors.length?cost*.44:0;
  G.treasury-=cost;G.cumulative.spending+=cost;
  if(local){const f=contractors[G.day%contractors.length];f.cash+=local;f.revenue+=local;book('Municipal capital budget',f.name,local,'Public '+types[kind].n+' contract',b.id);}
  G.region+=cost-local;book('Municipal capital budget','Regional suppliers',cost-local,'Public construction materials',b.id);
  story('Funded service expansion: the council commissioned a '+types[kind].n.toLowerCase()+'. The site opens after construction.','good',b.id);return;
 }
}
function householdFormation(){
 if(G.day%90!==0)return;
 const vacant=G.buildings.find(b=>b.kind==='home'&&!b.redevelopment&&(!G.households[b.hh]||G.households[b.hh].people.length===0));if(!vacant)return;
 const young=G.people.find(p=>!p.deceased&&!p.movedAway&&p.age>=20&&p.age<31&&p.job>=0&&G.households[p.hh].people.length>2&&G.households[p.hh].cash>3600);if(!young)return;
 const prior=G.households[young.hh],cash=Math.min(1800,prior.cash*.25),h={...prior,id:G.households.length,name:young.name.split(' ').at(-1),cash,home:vacant.id,owner:-1,people:[young.id],deposits:{},income:0,rent:0,food:0,tax:0,aid:0,stress:25,last:[]};
 prior.cash-=cash;prior.people=prior.people.filter(id=>id!==young.id);young.hh=h.id;G.households.push(h);vacant.hh=h.id;
 book(prior.name+' household',h.name+' household',cash,'Savings divided on household formation',vacant.id);
 story(young.name+' formed a household and rented an existing vacant cottage.','good',vacant.id,h.id);
}

// SOURCE: 50-clock.js
function tick(){if(!G||pendingEvent)return;ensureSystems();G.day++;if(G.day%30===0){G.month++;if(G.month>12){G.month=1;G.year++}};
 freightDay();completeDevelopmentProjects();dailyEconomy();liquidityStress();bankDaily();metroOperatingDay();airfieldOperatingDay();incidents();investigateCases();extendedCivicDay();maintainRoads();if(G.day%30===0&&G.debt>0){const interest=G.debt*.005,paid=Math.min(G.treasury,interest);G.treasury-=paid;G.region+=paid;G.debt+=interest-paid;story('Interest on municipal borrowing: '+money(interest)+'.')}if(G.day%10===0)assignJobs();if(G.day%30===0)privateInvestmentAndHousing();

 if(G.day%30===0){outwardMigration();autonomousDevelopment();}
 if(G.day%45===0&&G.stats.population<2000){let success=G.stats.employment>68&&G.stats.hardship<35;
   if(success&&G.homes.length>0&&random()<.5){let h=pick(G.households);if(h.people.length<4){let p={id:G.people.length,name:pick(first)+' '+h.name,age:Math.round(rn(18,42)),skill:rn(.3,1),health:rn(60,100),hh:h.id,job:-1,life:60,last:[]};G.people.push(p);h.people.push(p.id);story('A newcomer joined the '+h.name+' household.','good',h.home,h.id)}}
 }
 recompute();updateCouncilAndMissions();systemsDay();
 if(G.day%30===0)monthlyReview();
 if(G.day%360===0){yearlyDemographics();electionReview();}
 if(!pendingEvent&&G.day%45===0&&G.day-G.lastEventDay>=37)offerCouncilEvent();
 // Publish and save one canonical end-of-day snapshot after demographic and civic changes.
 recompute();G.stats.approval=Math.round(G.council.approval);G.rngState=rngState;
 if(G.day%10===0)recordObservation();
 G.history.push({day:G.day,employment:G.stats.employment,hardship:G.stats.hardship,safety:G.stats.safety,treasury:Math.round(G.treasury),businesses:G.stats.businesses,deposits:(G.banks||[]).reduce((n,b)=>n+bankDeposits(b.id),0),crime:G.stats.dailyCrime,approval:G.council.approval,education:G.education,health:G.health});if(G.history.length>240)G.history.shift();
 if(G.day%60===0){const signal=marketSignal();if(signal.kind!=='normal'&&signal.title!==G.lastEconomicSignal){story(signal.title+'. '+signal.description,signal.kind==='good'?'good':'bad');G.lastEconomicSignal=signal.title;}}
 if(G.day%(speed>=16?30:5)===0)save();
 if(!simulationBusy&&(speed<16||G.day%5===0))updateHeader();const panelRefresh=speed>=32?30:speed>=8?12:4;if(!simulationBusy&&active&&G.day%panelRefresh===0&&active!=='policies'&&active!=='citizens')renderPanel(active);dirty=true;
}

function save(){if(!G||simulationBusy)return;let payload;try{payload=archivePayload()}catch(e){autoSaveOK=false;return}try{const key='townledger-v6';const prev=localStorage.getItem(key);if(prev){let valid=false;try{const e=JSON.parse(prev);valid=e.checksum===checksum(e.payload)}catch(_){}if(valid){localStorage.removeItem('townledger-village-founder-3');localStorage.setItem(key+'-backup',prev);}}localStorage.setItem(key,JSON.stringify({checksum:checksum(payload),payload}));localStorage.removeItem('townledger-village-founder-3');autoSaveOK=true;}catch(e){autoSaveOK=false;}if(window.indexedDB)writeIndexedDB(payload);}
function load(){try{for(const key of ['townledger-v6','townledger-v6-backup']){try{const e=JSON.parse(localStorage.getItem(key)||'null');if(e&&e.checksum===checksum(e.payload)&&hydrateSave(e.payload))return true;}catch(_){}}let s=localStorage.getItem('townledger-village-founder-3')||localStorage.getItem('townledger-village-civic-2');if(!s)return false;return hydrateSave(s)}catch(e){return false}}
function toast(msg){const el=$('toast');el.textContent=msg;el.style.display='block';clearTimeout(toastTimeout);toastTimeout=setTimeout(()=>el.style.display='none',3300)}

// SOURCE: 60-renderer.js
function updateHeader(){if(!G)return;$('pop').textContent=fmt(G.stats.population);$('funds').textContent=money(G.treasury);$('jobs').textContent=G.stats.employment+'%';$('safety').textContent=G.stats.safety+'/100';$('approval').textContent=Math.round(G.council.approval)+'%';$('date').textContent='YEAR '+G.year+' · MONTH '+G.month+' · DAY '+G.day;$('season').textContent=['SPRING IN THE VALE','SUMMER IN THE VALE','AUTUMN IN THE VALE','WINTER IN THE VALE'][Math.floor((G.month-1)/3)]+(G.weather&&G.weather!=='clear'?' · '+G.weather.toUpperCase():'');$('pause').textContent=paused?'▶':'Ⅱ';if($('liveEconomy')&&(G.day%5===1||G.day<5)){const m=marketSignal();$('liveEconomy').innerHTML=`<b>${esc(m.title)}</b><span>${G.stats.employment}% employed · ${m.m.open} firms · ${m.m.projects} building · ${G.stats.hardship}% hardship</span>`;}$('speed').textContent=speed+'×';if($('effectiveSpeed'))$('effectiveSpeed').textContent=perfStats.effective<speed*.90?'Running '+perfStats.effective.toFixed(0)+'×':'';if($('speedRange'))$('speedRange').value=String(SPEED_PRESETS.indexOf(speed)>=0?SPEED_PRESETS.indexOf(speed):0);$('pauseBanner').style.display=paused?'block':'none'; updateObjectiveMini();}
// ----- Town map renderer. Geometry is cached; only vehicles need a dynamic redraw.
function iso(x,y){return [(x-y)*TW/2+RW/2,(x+y)*TH/2+32]}
function diamond(g,x,y,fill,stroke){let p=iso(x,y);g.beginPath();g.moveTo(p[0],p[1]);g.lineTo(p[0]+TW/2,p[1]+TH/2);g.lineTo(p[0],p[1]+TH);g.lineTo(p[0]-TW/2,p[1]+TH/2);g.closePath();g.fillStyle=fill;g.fill();g.strokeStyle=fill;g.lineWidth=.7;g.stroke();if(stroke){g.strokeStyle=stroke;g.lineWidth=.6;g.stroke()}}
let roadNetwork=null,roadsVersion=0,roadVersionBuilt=-1,roadGraphOwner=null,roadBuildingVersion=-1,traffic=[],trafficClock=0,frameClock=0,renderSprites=[],spritesVersion=-1,vehicleSerial=0;
const roadOffsets=[[-1,0],[1,0],[0,-1],[0,1]];
function ensureRoadWear(){if(!G.roadWear||!Array.isArray(G.roadWear)||G.roadWear.length!==T*T){G.roadWear=new Array(T*T).fill(100)}}
function maintainRoads(){
 ensureRoadWear();
 const net=graph(),privateSet=new Set(G.privateRoads||[]);
 const publicCount=Math.max(1,net.neighbors.size-privateSet.size);
 const publicBudget=clamp(G.policy.roadBudget,0,250)*(G.actualServiceFunding?.roads??1);
 const publicRepair=publicBudget/publicCount*.23;
 // Private lanes are maintained by locally subscribed user charges, not the
 // municipal road grant. If shops cannot pay, pavement gradually deteriorates.
 const commercial=G.firms.filter(f=>!f.closed&&f.cash>2&&net.portals.has(f.building));
 let privateFees=0;
 if(privateSet.size&&commercial.length){
  const due=Math.min(.22,privateSet.size*.13/commercial.length);
  for(const f of commercial){const paid=Math.min(f.cash,due);f.cash-=paid;f.expenses+=paid;G.region+=paid;privateFees+=paid}
 }
 if(G.development)G.development.privateRoadTolls=(G.development.privateRoadTolls||0)+privateFees;
 const privateRepair=privateFees/Math.max(1,privateSet.size)*.85;
 let total=0,n=0;
 for(const id of net.neighbors.keys()){
  const old=G.roadWear[id];
  const repair=privateSet.has(id)?privateRepair:publicRepair;
  G.roadWear[id]=clamp(old-.045-(G.weather==='storm'?.065:0)+repair,25,100);
  total+=G.roadWear[id];n++;
 }
 G.stats.roadCondition=Math.round(total/Math.max(1,n));
 if(G.day%30===0)staticDirty=true;
}
const roadId=(x,y)=>y*T+x;
function invalidateRoads(resetTraffic=true){roadsVersion++;roadNetwork=null;if(resetTraffic){traffic.length=0;trafficClock=0;intersectionGates.clear()}if(G)G.roadMetrics=null;dirty=true;}
function flushRoadBatch(){if(!roadBatchDirty)return;roadBatchDirty=false;invalidateRoads();staticDirty=true;if(G){recompute();updateHeader();save()}}
function graph(){
 if(roadNetwork&&roadVersionBuilt===roadsVersion&&roadGraphOwner===G&&roadBuildingVersion===G.buildings.length)return roadNetwork;
 const neighbors=new Map(),parts=new Int32Array(T*T).fill(-1),portals=new Map(),connected=[];
 for(let i=0;i<G.tiles.length;i++)if(G.tiles[i]===1){
  const x=i%T,y=i/T|0,ns=[];
  for(const [dx,dy] of roadOffsets){const xx=x+dx,yy=y+dy;if(xx>=0&&xx<T&&yy>=0&&yy<T&&G.tiles[roadId(xx,yy)]===1)ns.push(roadId(xx,yy))}
  neighbors.set(i,ns);
 }
 let part=0,maxSize=0,mainPart=-1;
 for(const id of neighbors.keys())if(parts[id]===-1){
  const q=[id];parts[id]=part;for(let k=0;k<q.length;k++)for(const n of neighbors.get(q[k]))if(parts[n]===-1){parts[n]=part;q.push(n)}
  if(q.length>maxSize){maxSize=q.length;mainPart=part}part++;
 }
 const anchor=G.buildings.find(b=>b.kind==='townhall');
 if(anchor){for(const [dx,dy] of roadOffsets){let x=anchor.x+dx,y=anchor.y+dy;if(x>=0&&x<T&&y>=0&&y<T&&parts[roadId(x,y)]>=0){mainPart=parts[roadId(x,y)];break}}}
 for(const b of G.buildings){
  const choices=[];for(const id of footprintOf(b)){const xx=id%T,yy=id/T|0;for(const [dx,dy] of roadOffsets){const ax=xx+dx,ay=yy+dy;if(ax>=0&&ax<T&&ay>=0&&ay<T&&G.tiles[roadId(ax,ay)]===1)choices.push(roadId(ax,ay))}}
  if(choices.length){let entry=choices.find(id=>parts[id]===mainPart)??choices[0];portals.set(b.id,entry);if(parts[entry]===mainPart)connected.push(b)}
 }
 roadNetwork={neighbors,parts,portals,connected,mainPart,partsCount:part,maxSize};roadVersionBuilt=roadsVersion;roadGraphOwner=G;roadBuildingVersion=G.buildings.length;return roadNetwork;
}
function routeBetween(a,b){
 const net=graph(),start=typeof a==='number'?a:net.portals.get(a?.id),finish=typeof b==='number'?b:net.portals.get(b?.id);
 if(start==null||finish==null||net.parts[start]!==net.parts[finish])return [];
 if(start===finish)return [start];
 const prev=new Int32Array(T*T).fill(-1),queue=[start];prev[start]=start;
 for(let i=0;i<queue.length;i++){
  const from=queue[i];for(const n of net.neighbors.get(from)||[]){if(prev[n]!==-1)continue;prev[n]=from;if(n===finish){let path=[n],at=n;while(at!==start){at=prev[at];path.push(at)}return path.reverse()}queue.push(n)}
 }
 return [];
}
function roadMetrics(){
 const net=graph(),firms=G.firms.filter(f=>!f.closed),reachable=firms.filter(f=>{let node=net.portals.get(f.building);return node!=null&&net.parts[node]===net.mainPart}).length;
 const eligible=G.households.filter(h=>{let node=net.portals.get(h.home);return node!=null&&net.parts[node]===net.mainPart}).length;
 let routes=0,length=0;for(let i=0;i<Math.min(10,net.connected.length-1);i++){
  const a=net.connected[i],b=net.connected[(i*7+19)%net.connected.length];if(a===b)continue;let path=routeBetween(a,b);if(path.length>1){routes++;length+=path.length-1}
 }
 return {connectedFirms:reachable,totalFirms:firms.length,connectedHomes:eligible,totalHomes:G.households.length,roadTiles:net.neighbors.size,roadClusters:net.partsCount,averageJourney:routes?Math.round(length/routes):0,quality:Math.round(G.stats.roadCondition??75)};
}
function roadCenter(id){const pos=iso(id%T,id/T|0);return [pos[0],pos[1]+TH/2]}
function roadDistance(a,b){
 if(a==null||b==null)return Infinity;
 if(a===b)return 0;
 const net=graph();if(net.parts[a]!==net.parts[b])return Infinity;
 if(!net.distCache)net.distCache=new Map();
 const key=a<b?a*T*T+b:b*T*T+a;
 if(net.distCache.has(key))return net.distCache.get(key);
 const dist=routeBetween(a,b).length-1;
 if(net.distCache.size>3000)net.distCache.clear();
 net.distCache.set(key,dist);
 return dist;
}
function beginVehicle(source=null,target=null,emergency=false){
 const net=graph();if(net.connected.length<2)return null;
 let from=source||visualPick(net.connected.filter(b=>b.firm>=0&&G.firms[b.firm]&&!G.firms[b.firm].closed));
 if(!from)return null;
 const src=net.portals.get(from.id);if(src==null)return null;if(traffic.some(v=>v.path[v.segment]===src&&v.fraction<.8))return null;
 let destinations=net.connected.filter(b=>b.id!==from.id&&net.parts[net.portals.get(b.id)]===net.parts[src]);
 if(!destinations.length)return null;
 // Goods vehicles favour another business, while smaller cars visit homes and civic premises.
 const commercial=destinations.filter(b=>b.firm>=0),residential=destinations.filter(b=>b.kind==='home');
 let pool=visualRandom()<.58?commercial:residential;
 let to=target||visualPick(pool.length?pool:destinations);
 if(target&&(!net.portals.has(target.id)||net.parts[net.portals.get(target.id)]!==net.parts[src]))return null;
 if(!to||net.parts[net.portals.get(to.id)]!==net.parts[src])to=visualPick(destinations);
 let path=routeBetween(from,to);if(path.length<2)return null;
 const n=traffic.length,color=emergency?'#c24c3e':['#b98051','#e4c58b','#536e7c','#7b8b71','#9b5f54','#c6bd9e'][((from.id*7+n*3)%6)];
 let style=emergency?'emergency':from.kind==='farm'?'tractor':visualRandom()<.28?'pedestrian':visualRandom()<.48?'truck':'car';let v={id:++vehicleSerial,path,segment:0,fraction:0,speed:emergency?4.3:style==='pedestrian'?.53:style==='tractor'?.68:1+visualRandom()*.4,style,color,emergency,wait:0,age:0,from:from.id,to:to.id};traffic.push(v);return v;
}
function roadServiceDistance(site,station){if(!site||!station)return Infinity;const net=graph(),a=net.portals.get(site.id),b=net.portals.get(station.id);if(a==null||b==null||net.parts[a]!==net.parts[b])return Infinity;return roadDistance(a,b);}
function closestRoadBuilding(x,y,kind){const net=graph(),site=buildingAt(x,y);if(!site)return null;let best=null,d=Infinity;for(const b of net.connected){if(kind&&b.kind!==kind)continue;const distance=roadServiceDistance(site,b);if(distance<d){best=b;d=distance}}return best}
function emergencyDispatch(site,kind){if(!site)return;const service=closestRoadBuilding(site.x,site.y,kind);if(service){const v=beginVehicle(service,site,true);if(v){v.speed=5.5;return}}}
let trafficElapsed=0,intersectionGates=new Map();
function trafficUpdate(dt){
 if(paused||pendingEvent||!G)return;
 const target=Math.min(42,Math.round(5+Math.sqrt(G.stats.population)*1.25));
 trafficElapsed+=dt;trafficClock+=dt;
 let tries=0;
 while(trafficClock>.72&&traffic.length<target&&tries++<3){trafficClock-=.72;spawnPurposeTrip()}
 if(traffic.length>=target)trafficClock=Math.min(.72,trafficClock);
 const quality=clamp(.52+(G.stats.roadCondition??75)/130,.45,1.25);
 // Reserve occupied DIRECTED ROAD SEGMENTS rather than whole intersections.
 // A vehicle crossing a junction never blocks everyone who is merely
 // travelling on a different segment through that same road tile.
 const edges=new Map();
 for(const v of traffic){let a=v.path[v.segment],b=v.path[v.segment+1];if(b!=null)edges.set(a+'>'+b,v)}
 const ready=[],approved=new Set(),gateTaken=new Set(),network=graph();
 for(const v of traffic){
   v.age=(v.age||0)+dt;
   const step=Math.min(.34,dt*v.speed*quality);
   v.plannedStep=step;
   if(v.path[v.segment+1]==null){v.finished=true;continue}
   if(v.fraction+step<1){const leader=traffic.filter(c=>c!==v&&c.path[c.segment]===v.path[v.segment]&&c.path[c.segment+1]===v.path[v.segment+1]&&c.fraction>v.fraction).sort((a,b)=>a.fraction-b.fraction)[0];const next=leader?Math.min(v.fraction+step,Math.max(v.fraction,leader.fraction-.26)):v.fraction+step;if(next<=v.fraction+.00001)v.wait=(v.wait||0)+dt;else v.wait=0;v.fraction=next;continue;}
   ready.push(v);
 }
 ready.sort((a,b)=>(b.wait-a.wait)||Number(b.emergency)-Number(a.emergency)||(a.id-b.id));
 for(const v of ready){
   const junction=v.path[v.segment+1],after=v.path[v.segment+2];
   const valence=network.neighbors.get(junction)?.length||0;
   const leader=after==null?null:edges.get(junction+'>'+after);
   const entryBlocked=leader&&leader!==v&&leader.fraction<.45;
   const crossing=valence>=3;
   const last=intersectionGates.get(junction)||-99;
   const signalBlocked=crossing&&(trafficElapsed-last<.16||gateTaken.has(junction));
   if(entryBlocked||signalBlocked){v.fraction=Math.min(.96,v.fraction);v.wait=(v.wait||0)+dt;continue}
   approved.add(v.id);
   if(crossing){gateTaken.add(junction);intersectionGates.set(junction,trafficElapsed)}
 }
 for(const v of ready){
  if(!approved.has(v.id))continue;
  v.segment++;
  v.fraction=clamp(v.fraction+v.plannedStep-1,0,.34);
  v.wait=0;
 }
 // Max-duration safeguard protects against malformed saved routes, not
 // normal congestion. Ordinary traffic should make forward progress.
 for(let i=traffic.length-1;i>=0;i--){const v=traffic[i];if(v.finished||v.segment>=v.path.length-1){
    G.transport.arrived++;
    traffic.splice(i,1);
  }}
 for(const v of traffic)if(v.wait>4&&v.fraction<.001)detour(v);
 if(intersectionGates.size>450){for(const [k,t] of intersectionGates)if(trafficElapsed-t>3)intersectionGates.delete(k)}
 if(traffic.length||G.airport?.operating||G.metro?.operating||G.buildings.some(b=>b.kind==='factory'||b.kind==='mill'||b.kind==='worksite')||overlay==='metro')dirty=true;
}

function vehiclePosition(v){
 const i=v.segment,t=clamp(v.fraction,0,1),t2=t*t,t3=t2*t;
 const a=roadCenter(v.path[Math.max(0,i-1)]),p=roadCenter(v.path[i]);
 const q=roadCenter(v.path[Math.min(v.path.length-1,i+1)]),b=roadCenter(v.path[Math.min(v.path.length-1,i+2)]);
 // Catmull–Rom cornering has continuous position and heading at junctions.
 // With one-tile spacing, rounded turns remain within adjoining road tiles.
 const curve=(k)=>.5*(2*p[k]+(-a[k]+q[k])*t+(2*a[k]-5*p[k]+4*q[k]-b[k])*t2+(-a[k]+3*p[k]-3*q[k]+b[k])*t3);
 const tangent=(k)=>.5*((-a[k]+q[k])+2*(2*a[k]-5*p[k]+4*q[k]-b[k])*t+3*(-a[k]+3*p[k]-3*q[k]+b[k])*t2);
 let x=curve(0),y=curve(1),dx=tangent(0),dy=tangent(1);
 const length=Math.hypot(dx,dy)||1,side=v.style==='pedestrian'?5:2.7;
 return {x:x-dy/length*side,y:y+dx/length*side,dx,dy};
}

// SOURCE: 65-landscape.js
// Original code-native pixel art. One unit = one owned 72 × 36 isometric tile.
// All architectural forms use the same projection, anchor and sunlight direction.
let nightMode=false,displayItems=[],atlas=new Map(),sceneSignature='',lastSceneMonth=0;
const SEASONS=[{grass:['#8f9b69','#929f6d','#96a36f','#9ba773','#9da875'],dark:'#788b58',leaf:['#536c41','#69844a','#809650'],water:'#6b9895'},
 {grass:['#82915a','#86965d','#8b9962','#909d64','#929d67'],dark:'#6b7f48',leaf:['#405f3e','#597642','#768e49'],water:'#648f8b'},
 {grass:['#a4a070','#a7a272','#aba676','#ada877','#b0a97b'],dark:'#8c905d',leaf:['#885e40','#b28144','#ceab5a'],water:'#759593'},
 {grass:['#d4d8cc','#d8dbd0','#dce0d4','#dfe2d9','#e1e4db'],dark:'#c0cdc2',leaf:['#627a6b','#8c9e88','#c9d4c3'],water:'#86a5a6'}];
function seasonPalette(){return SEASONS[Math.floor((G.month-1)/3)%4];}
function visualPick(a){return a[Math.floor(visualRandom()*a.length)];}
function point(u,v,z=0){return [Math.round((u-v)*36),Math.round((u+v)*18-z)];}
function polygon(g,points,color,stroke=null){g.fillStyle=color;g.beginPath();points.forEach((p,i)=>i?g.lineTo(...p):g.moveTo(...p));g.closePath();g.fill();if(stroke){g.strokeStyle=stroke;g.lineWidth=1;g.stroke();}}
function segment(g,a,b,color,width=1){g.strokeStyle=color;g.lineWidth=width;g.beginPath();g.moveTo(...a);g.lineTo(...b);g.stroke();}
function tone(c,m){const rgb=c.slice(1).match(/../g).map(x=>Math.max(0,Math.min(255,Math.round(parseInt(x,16)*m))));return '#'+rgb.map(x=>x.toString(16).padStart(2,'0')).join('');}
function slab(g,u,v,w,d,z,color){polygon(g,[point(u,v,z),point(u+w,v,z),point(u+w,v+d,z),point(u,v+d,z)],color);}
function box(g,u,v,w,d,z,h,c,top){
 polygon(g,[point(u+w,v,z),point(u+w,v+d,z),point(u+w,v+d,z+h),point(u+w,v,z+h)],tone(c,.79));
 polygon(g,[point(u,v+d,z),point(u+w,v+d,z),point(u+w,v+d,z+h),point(u,v+d,z+h)],c);
 slab(g,u,v,w,d,z+h,top||tone(c,1.12));
 segment(g,point(u,v+d,z),point(u+w,v+d,z),tone(c,.64));
}
function windowPane(g,u,v,z,side,lit=false,w=.115,h=7){
 const du=side==='front'?w:0,dv=side==='side'?w:0;
 const p=[point(u,v,z),point(u+du,v+dv,z),point(u+du,v+dv,z+h),point(u,v,z+h)];
 polygon(g,p,'#e2d1ac');
 const inset=.018;polygon(g,[point(u+du*.15,v+dv*.15,z+1),point(u+du*.85,v+dv*.85,z+1),point(u+du*.85,v+dv*.85,z+h-1),point(u+du*.15,v+dv*.15,z+h-1)],lit?'#efc676':'#6b8782');
 segment(g,point(u+du*.5,v+dv*.5,z+1),point(u+du*.5,v+dv*.5,z+h-1),'#c7c3aa');
}
function door(g,u,v,z=0,w=.15){polygon(g,[point(u,v,z),point(u+w,v,z),point(u+w,v,z+13),point(u,v,z+13)],'#574c3d');const p=point(u+w*.8,v,z+6);g.fillStyle='#d5b46e';g.fillRect(p[0],p[1],1,2);}
function gable(g,u,v,w,d,z,rise,color){
 const ridge=v+d/2;
 polygon(g,[point(u-.04,v-.04,z),point(u+w+.04,v-.04,z),point(u+w+.04,ridge,z+rise),point(u-.04,ridge,z+rise)],tone(color,.83));
 polygon(g,[point(u-.04,ridge,z+rise),point(u+w+.04,ridge,z+rise),point(u+w+.04,v+d+.05,z),point(u-.04,v+d+.05,z)],color);
 polygon(g,[point(u+w,v,z),point(u+w,v+d,z),point(u+w,ridge,z+rise)],tone(color,.66));
 for(let t=.2;t<1;t+=.2)segment(g,point(u-.02,ridge+(d/2+.04)*t,z+rise*(1-t)),point(u+w+.04,ridge+(d/2+.04)*t,z+rise*(1-t)),tone(color,.91));
 segment(g,point(u-.05,ridge,z+rise),point(u+w+.05,ridge,z+rise),tone(color,1.28),1.3);
}
function chimney(g,u,v,z){box(g,u,v,.075,.09,z,11,'#aa856b','#cbb698');}
function tree(g,u,v,id,scale=1){
 const p=point(u,v),s=seasonPalette(),r=hash(id);g.save();g.translate(...p);g.scale(scale,scale);
 polygon(g,[[-2,2],[15,5],[23,1],[6,-2]],'#56654938');
 g.fillStyle='#6a5842';g.fillRect(-2,-18,4,22);g.fillStyle='#8f7655';g.fillRect(-1,-18,1,22);
 if(r%4===0){for(let j=0;j<4;j++){polygon(g,[[0,-53+j*9],[-15+j,-27+j*8],[15-j,-27+j*8]],s.leaf[j%3]);segment(g,[-8+j,-30+j*8],[0,-45+j*9],tone(s.leaf[1],1.12));}}
 else{const crowns=[[-6,-31,12], [5,-36,12],[-10,-23,11],[7,-24,13],[0,-19,11]];for(let k=0;k<crowns.length;k++){let [x,y,n]=crowns[k];polygon(g,[[x-n,y-4],[x-n+4,y-10],[x+2,y-12],[x+n,y-5],[x+n-1,y+4],[x+4,y+9],[x-n+3,y+6]],s.leaf[k%3]);}
  g.fillStyle=tone(s.leaf[2],1.08);for(let i=0;i<13;i++){let n=hash(r+i*713);g.fillRect((n%21)-10,-41+(n>>>9)%21,3,2);}}
 if(G.month>=10){g.fillStyle='#edf0e6';for(let j=0;j<4;j++)g.fillRect(-10+j*6,-35+(j%2)*5,9,2);}g.restore();
}
function architecture(g,b,w,d){
 const id=b.id,kind=b.redevelopment?'worksite':b.kind,v=id%8,winter=G.month>=10,occupied=(b.hh>=0&&G.households[b.hh]?.people.length)||b.units?.some(id=>G.households[id]?.people.length),closed=b.firm>=0&&G.firms[b.firm]?.closed;
 const stone=['#c9baa0','#c6b79b','#b9b9a0','#d2c3a7'],roofs=['#865b48','#687574','#8c6954','#586f68','#a27853','#69767e','#78655b','#937663'];
 const wall=closed?'#9d9a85':stone[id%4],roof=winter?'#c4cfc1':roofs[id%8],lit=nightMode&&!!occupied;
 const bw=w*.73,bd=d*.70,u=-bw/2,vv=-bd/2;
 slab(g,-w/2+.03,-d/2+.03,w-.06,d-.06,0,kind==='farm'?'#a49b71':'#aaad8c');
 // Garden and footpath are contained by the legal parcel, never painted on roads.
 slab(g,-.07,bd/2,.14,Math.max(.04,(d-bd)/2),1,'#bfb69c');
 if(kind==='home'){
  const heights=[22,28,20,32,21,26,19,24],H=heights[id%8];
  const wide=id%8===2?bw*.95:id%8===3?bw*.67:bw*.85,deep=id%8===5?bd*.7:bd*.9;
  const a=-wide/2,c=-deep/2;
  box(g,a,c,wide,deep,1,H,wall);
  if(id%8===3){box(g,a,c,wide,deep,H+1,8,wall);gable(g,a,c,wide,deep,H+9,10,roof);}
  else if(id%8===4){slab(g,a-.04,c-.04,wide+.08,deep+.08,H+2,tone(roof,.8));box(g,a+.05,c+.05,wide-.10,deep-.10,H+2,6,roof);slab(g,a+.04,c+.04,wide-.08,deep-.08,H+9,tone(roof,1.15));}
  else gable(g,a,c,wide,deep,H+1,id%8===2?8:14,roof);
  for(let i=0;i<2;i++){windowPane(g,a+.07+i*wide*.5,c+deep+.01,H>25?16:10,'front',lit||id%11===0,.12,7);windowPane(g,a+wide+.01,c+.07+i*deep*.45,10,'side',lit,.12,7);}
  door(g,-.05,c+deep+.02,1,.12);
  if(id%8===1||id%8===5){box(g,a-.07,c+deep-.10,wide*.45,.24,0,12,tone(wall,.96));gable(g,a-.07,c+deep-.10,wide*.45,.24,12,6,roof);windowPane(g,a-.02,c+deep+.15,4,'front',lit,.12,5);}
  if(id%8===6){slab(g,a-.04,c+deep,wide+.08,.13,14,roof);for(const k of [0,.85])segment(g,point(a+k*wide,c+deep+.1,0),point(a+k*wide,c+deep+.1,14),'#927d59',1);}
  if(id%8===7){for(let f=5;f<H;f+=7)segment(g,point(a,c+deep+.01,f),point(a+wide,c+deep+.01,f),'#9c8d72');}
  chimney(g,a+.10,c+.05,H+8);
  if(id%3===0){for(let t=0;t<5;t++){const p=point(-.43+t*.14,.43);g.fillStyle='#d9c9a5';g.fillRect(p[0],p[1]-7,2,7);}segment(g,point(-.43,.43,3),point(.34,.43,3),'#cfbd96');}
  if(id%3===1){for(let j=0;j<5;j++){const p=point(-.40+j*.065,.27);g.fillStyle=['#c2a45f','#bf8072','#d6cba3'][j%3];g.fillRect(p[0],p[1]-2,2,2);}}
  if(id%5===0)tree(g,-.37,-.36,id,.32);
 }else if(kind==='apartment'||kind==='tower'||kind==='office'){
  const floors=kind==='tower'?11:kind==='office'?5:4,H=floors*12;
  box(g,u,vv,bw,bd,0,H,kind==='tower'?'#aaa995':'#bfac91');
  for(let f=0;f<floors;f++){segment(g,point(u,vv+bd,12*f),point(u+bw,vv+bd,12*f),'#9c927e');for(let i=0;i<4;i++){windowPane(g,u+.08+i*bw*.23,vv+bd+.01,4+f*12,'front',nightMode&&(id+i+f)%3!==0,.16,6);windowPane(g,u+bw+.01,vv+.10+i*bd*.22,4+f*12,'side',nightMode&&(id+f)%4===0,.15,6);}}
  slab(g,u-.03,vv-.03,bw+.06,bd+.06,H+2,'#5c716d');box(g,u+.1,vv+.12,bw*.45,bd*.4,H+2,6,'#8a9587');door(g,-.08,vv+bd+.01,0,.16);
 }else if(kind==='farm'){
  box(g,-.6,-.58,.89,.90,0,31,'#a56f52');gable(g,-.6,-.58,.89,.90,31,21,winter?'#d6d9ca':'#665e54');
  polygon(g,[point(-.38,.33,0),point(.04,.33,0),point(.04,.33,22),point(-.38,.33,22)],'#654f3e');
  segment(g,point(-.38,.34,1),point(.04,.34,22),'#c5b18b',2);segment(g,point(.04,.34,1),point(-.38,.34,22),'#c5b18b',2);
  box(g,.34,-.62,.27,.31,0,43,'#b7b5a0','#dfd4b9');gable(g,.34,-.62,.27,.31,43,9,'#7b8276');
  for(let j=0;j<4;j++)slab(g,.32,-.08+j*.18,.40,.07,1,j%2?'#6e8250':'#b5a05d');
  for(let j=0;j<8;j++){const p=point(-.86+j*.23,.87);segment(g,[p[0],p[1]],[p[0],p[1]-7],'#a28c66',2);}segment(g,point(-.86,.87,4),point(.80,.87,4),'#c6b48b');
 }else if(kind==='worksite'||b.redevelopment){
  slab(g,u,vv,bw,bd,0,'#b8a582');const proj=G.projects.find(p=>p.id===b.id),progress=proj?1-proj.remaining/Math.max(1,proj.duration||G.day-proj.start+proj.remaining):.2;
  const h=progress<.3?3:progress<.7?18:30;box(g,u+.05,vv+.05,bw-.1,bd-.1,0,h,'#bba98a');
  for(let i=0;i<4;i++){const x=u+i*bw/3;segment(g,point(x,vv+bd,0),point(x,vv+bd,h+8),'#927d58',2);}segment(g,point(u,vv+bd,h+5),point(u+bw,vv+bd,h+5),'#d8bd83',2);
  segment(g,point(.28,-.15,0),point(.28,-.15,69),'#bf9e5a',2);segment(g,point(-.35,-.15,66),point(.72,-.15,66),'#d1b16a',2);segment(g,point(.61,-.15,66),point(.61,-.15,40),'#5a6250');
 }else if(kind==='park'||kind==='square'){
  slab(g,-.42,-.42,.84,.84,1,kind==='square'?'#c4bba1':'#79925e');
  if(kind==='square'){box(g,-.12,-.12,.24,.24,2,4,'#b2b59e','#82a4a0');box(g,-.025,-.025,.05,.05,7,13,'#c8c7ad');}
  else{tree(g,-.17,-.17,id,.60);slab(g,-.42,.16,.84,.11,1,'#c9bb93');}
  box(g,.14,.29,.28,.08,2,3,'#8a7351');
 }else if(kind==='factory'||kind==='warehouse'||kind==='sawmill'){
  box(g,u,vv,bw,bd,0,30,'#a99d83');
  for(let j=0;j<3;j++)gable(g,u+j*bw/3,vv,bw/3,bd,31,kind==='factory'?13:6,roof);
  for(let i=0;i<4;i++)windowPane(g,u+.08+i*bw*.22,vv+bd+.01,15,'front',nightMode&&!closed,.19,7);
  box(g,u+.06,vv+.03,.13,.15,27,kind==='factory'?49:26,'#8e7e68');
  box(g,u+bw+.06,vv+.30,.26,.27,0,8,'#b39c73');
  door(g,u+bw*.4,vv+bd+.02,0,.25);
 }else if(kind==='metro_station'){
  slab(g,-.84,-.83,1.68,1.66,1,'#b9b49c');box(g,-.63,-.50,1.06,.70,0,23,'#beb79c');gable(g,-.63,-.50,1.06,.70,23,13,roof);
  for(let j=0;j<4;j++)windowPane(g,-.5+j*.24,.21,7,'front',nightMode,.16,9);
  box(g,.49,-.49,.20,.20,0,17,'#5c766e');const p=point(.50,-.48,21);g.fillStyle='#efdfb4';g.font='bold 7px serif';g.fillText('M',p[0],p[1]);
  slab(g,-.54,.40,.8,.28,1,'#65756d');for(let k=0;k<5;k++)segment(g,point(-.54,.40+k*.05,1),point(.26,.40+k*.05,1),'#aaa88f');
 }else if(kind==='airport'){
  box(g,-.72,-.65,1.2,.65,0,20,'#c2baa0');slab(g,-.76,-.69,1.28,.73,22,roof);for(let j=0;j<5;j++)windowPane(g,-.6+j*.2,.01,7,'front',nightMode,.15,9);
  box(g,.5,-.62,.23,.23,0,48,'#aaa894');box(g,.43,-.69,.37,.37,48,10,'#779795');slab(g,.39,-.73,.45,.45,60,'#5f7470');
 }else if(kind==='quarry'){
  slab(g,-.38,-.38,.76,.76,1,'#a4aa95');slab(g,-.29,-.29,.58,.58,2,'#8e9685');slab(g,-.17,-.16,.34,.33,3,'#727e73');box(g,.1,-.4,.2,.17,0,14,'#b8ad86');
 }else if(kind==='forestry'){
  box(g,-.24,-.24,.48,.48,0,15,'#a58c65');gable(g,-.24,-.24,.48,.48,15,8,roof);tree(g,-.35,-.34,id,.45);for(let j=0;j<4;j++)box(g,-.37+j*.17,.32,.13,.10,0,4,'#b2a078');
 }else{
  const civic=['townhall','school','clinic','courthouse','college','bank'].includes(kind),H=civic?32:25;
  box(g,u,vv,bw,bd,0,H,kind==='fire'?'#b4836a':wall);gable(g,u,vv,bw,bd,H+1,civic?13:10,roof);
  const rows=civic?2:1;for(let row=0;row<rows;row++)for(let j=0;j<3;j++){windowPane(g,u+.05+j*bw*.30,vv+bd+.01,5+row*15,'front',nightMode&&!closed,.12,7);}
  for(let j=0;j<2;j++)windowPane(g,u+bw+.01,vv+.1+j*bd*.45,12,'side',nightMode&&!closed,.13,7);
  door(g,-.07,vv+bd+.02,0,.14);
  if(kind==='townhall'||kind==='courthouse'){box(g,-.1,-.12,.20,.22,H+4,20,'#c5b799');gable(g,-.1,-.12,.20,.22,H+24,11,'#5d776e');const p=point(.03,.11,H+15);g.fillStyle='#e6d7b1';g.fillRect(p[0]-3,p[1]-3,6,6);segment(g,[p[0],p[1]],[p[0],p[1]-2],'#49584e');}
  if(kind==='grocer'||kind==='bakery'||kind==='tavern'){
   for(let j=0;j<6;j++)slab(g,u+j*bw/6,vv+bd,bw/6,.17,16,j%2?'#e5d8b2':kind==='grocer'?'#637d65':kind==='tavern'?'#9d7751':'#a5725a');
   const p=point(.04,vv+bd+.03,23);g.fillStyle='#544e3e';g.font='5px monospace';g.textAlign='center';g.fillText(kind==='grocer'?'MARKET':kind==='bakery'?'BAKERY':'THE VALE',p[0],p[1]);
   box(g,u-.03,vv+bd+.18,.18,.12,0,7,'#9e8662');
  }
  if(kind==='mill'){chimney(g,u+.04,vv+.05,H+8);box(g,u+bw+.02,vv+.05,.12,.15,5,23,'#8f8b70');}
  if(kind==='fire'){polygon(g,[point(-.2,vv+bd+.01,0),point(.2,vv+bd+.01,0),point(.2,vv+bd+.01,19),point(-.2,vv+bd+.01,19)],'#725749');}
  if(kind==='clinic'){const p=point(0,vv+bd+.03,H-5);g.fillStyle='#a86e55';g.fillRect(p[0]-3,p[1]-1,7,2);g.fillRect(p[0],p[1]-4,2,8);}
 }
 // Visual decline is tied to property condition and business closure.
 if(closed||b.condition<45){for(let j=0;j<5;j++){const p=point((hash(id+j)%50)/100-.25,.34);g.fillStyle='#6c7853';g.fillRect(p[0],p[1]-3,2,4);}const p=point(0,bd/2+.02,10);g.fillStyle='#a5906d';g.fillRect(p[0]-5,p[1],10,3);}
}
function spriteFor(item){
 const season=Math.floor((G.month-1)/3),b=item.b,variant=b?(b.kind==='home'?b.id%120:b.id%24):0;
 const key=item.kind==='tree'?`tree:${season}:${item.id%11}`:`${b.kind}:${variant}:${item.w}:${item.d}:${season}:${nightMode}:${b.condition<45}:${b.firm>=0&&G.firms[b.firm]?.closed}:${b.redevelopment?'renewal':''}:${b.kind==='worksite'||b.redevelopment?Math.floor(4*(1-(G.projects.find(p=>p.id===b.id)?.remaining||0)/Math.max(1,G.projects.find(p=>p.id===b.id)?.duration||30))):0}`;
 if(atlas.has(key))return atlas.get(key);
 const c=document.createElement('canvas');c.width=256;c.height=320;const g=c.getContext('2d');g.translate(128,240);
 if(item.kind==='tree')tree(g,0,0,item.id%11,.83);else{polygon(g,[point(-item.w*.4,-item.d*.4),point(item.w*.6,-item.d*.4),point(item.w*.9,item.d*.3),point(0,item.d*.7)],'#48523f30');architecture(g,b.kind==='worksite'||b.redevelopment?b:{...b,id:variant},item.w,item.d);}
 atlas.set(key,c);if(atlas.size>600){const oldest=atlas.keys().next().value;atlas.delete(oldest);}return c;
}
function prepareScene(){
 displayItems=[];const occupied=new Set(G.buildings.flatMap(b=>footprintOf(b)));
 for(let y=0;y<T;y++)for(let x=0;x<T;x++){const id=roadId(x,y);if(G.tiles[id]===3&&!occupied.has(id)&&hash(id+G.worldSeed)%4!==0){const [px,py]=iso(x,y);displayItems.push({kind:'tree',id,x:px,y:py+18,w:1,d:1});}}
 for(const b of G.buildings){const fp=footprintOf(b),xs=fp.map(id=>id%T),ys=fp.map(id=>id/T|0),w=Math.max(...xs)-Math.min(...xs)+1,d=Math.max(...ys)-Math.min(...ys)+1;const [x,y]=iso(b.x+(w-1)/2,b.y+(d-1)/2);displayItems.push({kind:'building',id:b.id,b,x,y:y+18,w,d});}
 displayItems.sort((a,b)=>a.y-b.y||a.id-b.id);sceneSignature=G.buildings.length+':'+G.month+':'+G.construction;
}
function drawStatic(){
 const s=seasonPalette(),net=graph();bg.setTransform(1,0,0,1,0,0);bg.fillStyle='#5d7967';bg.fillRect(0,0,RW,RH);
 const occupied=new Set(G.buildings.flatMap(b=>footprintOf(b)));
 for(let y=0;y<T;y++)for(let x=0;x<T;x++){
  const id=roadId(x,y),type=G.tiles[id],h=hash(id+G.worldSeed),p=iso(x,y),lu=G.landUse?.[id];
  diamond(bg,x,y,type===2?s.water:type===1?'#b3b09a':lu===1?(G.month>=10?'#c8cbb5':G.month>=7?'#b4a36d':'#99a06a'):lu===2?'#aa9b7b':lu===3?'#7b827a':s.grass[(Math.floor(Math.sin(x*.18+y*.11)*1.4+Math.cos(y*.22)*.8)+7)%5]);
  if(type===2){bg.fillStyle='#b5cdc0';if(h%3===0)bg.fillRect(p[0]-12+(h%17),p[1]+16,9,1);if(x<T-1&&G.tiles[id+1]!==2){segment(bg,[p[0]+35,p[1]+18],[p[0],p[1]+35],'#bdbaa0',3);}}
  else if(type!==1&&!occupied.has(id)&&!lu){for(let j=0;j<3;j++){let k=hash(h+j*37);bg.fillStyle=j===0?s.dark:tone(s.grass[2],1.04);bg.fillRect(p[0]-15+(k%30),p[1]+9+((k>>>8)%16),2+(k%3),1);}if(h%37===0&&G.month<10){bg.fillStyle=G.month<4?'#e2d5ad':'#c9b486';bg.fillRect(p[0]+5,p[1]+21,2,2);}}
  if(lu===1){for(let j=-2;j<=2;j++){segment(bg,[p[0]-19+j*4,p[1]+17+j*2],[p[0]+9+j*4,p[1]+31+j*2],G.month>=10?'#acb59b':G.month>=7?'#dbc48a':'#677e4e',2);}}
  if(lu===3){segment(bg,[p[0]-25,p[1]+6],[p[0]+25,p[1]+31],'#aeb6a7',1);segment(bg,[p[0]-20,p[1]+12],[p[0]+20,p[1]+32],'#d7d6bc',1);}
 }
 // Connected strokes make continuous lanes and junctions instead of road diamonds.
 for(const [id,links] of net.neighbors){const a=roadCenter(id);for(const n of links){if(n<id)continue;const q=roadCenter(n);segment(bg,a,q,'#92988a',25);segment(bg,a,q,'#7d877c',21);segment(bg,a,q,'#858d80',17);if(links.length<=2){bg.setLineDash([3,7]);segment(bg,a,q,'#c8c5a8',1);bg.setLineDash([]);}}}
 for(const [id,links] of net.neighbors){if(links.length>2){const a=roadCenter(id);bg.fillStyle='#858d80';bg.beginPath();bg.ellipse(...a,13,7,0,0,Math.PI*2);bg.fill();}}
 prepareScene();staticDirty=false;lastSceneMonth=G.month;
}
function fit(){const bounds=cv.getBoundingClientRect();dpr=Math.min(window.devicePixelRatio||1,1.5);cw=Math.max(1,bounds.width);ch=Math.max(1,bounds.height);cv.width=Math.round(cw*dpr);cv.height=Math.round(ch*dpr);dirty=true;}
function transform(){ctx.setTransform(dpr,0,0,dpr,0,0);ctx.translate(cw/2,ch/2);ctx.scale(cam.zoom,cam.zoom);ctx.translate(-cam.x,-cam.y);}
function vehiclePaint(g,v,p,clock){
 if(v.style==='pedestrian'){const step=Math.floor(clock*6+v.id)%2,x=Math.round(p.x),y=Math.round(p.y);g.fillStyle='#40544844';g.fillRect(x-2,y+1,5,2);g.fillStyle='#dfba91';g.fillRect(x-1,y-9,3,3);g.fillStyle=v.color;g.fillRect(x-2,y-6,4,5);g.fillStyle='#4d5548';g.fillRect(x-2+step,y-1,1,3);g.fillRect(x+1-step,y,1,2);return;}
 g.save();g.translate(Math.round(p.x),Math.round(p.y));const u=p.dx>=0?.19:-.19,vv=p.dy>=0?.10:-.10;polygon(g,[[-10,3],[3,8],[12,3],[-2,-2]],'#354a4244');
 const color=v.style==='truck'?'#b9b499':v.color;box(g,-.19,-.12,.38,.24,1,v.style==='truck'?8:5,color);box(g,-.08,-.10,.17,.20,6,4,'#7e9e9b','#c2c4ad');
 g.fillStyle='#4c554c';g.fillRect(-8,2,3,3);g.fillRect(5,3,3,3);g.fillStyle='#e1c78e';g.fillRect(p.dx>0?7:-10,0,2,2);g.restore();
}
function atmosphere(g,sx,sy,ww,hh){
 const active=G.weather==='rain'||G.weather==='storm'||G.month>=10;
 if(active)for(let j=0;j<70;j++){const h=hash(j+G.worldSeed),x=sx+(h%1000)/1000*ww,y=sy+(((h>>>10)%1000)/1000*hh+frameClock*(G.month>=10?12:120))%hh;g.strokeStyle=G.month>=10?'#f8f7e399':'#dce3cf66';g.lineWidth=1;g.beginPath();g.moveTo(x,y);g.lineTo(x+(G.month>=10?1:4),y+(G.month>=10?1:9));g.stroke();}
 for(const item of displayItems){if(item.kind!=='building'||item.x<sx-100||item.x>sx+ww+100||item.y<sy-100||item.y>sy+hh+130)continue;const b=item.b;if(b.firm<0||G.firms[b.firm]?.closed||!G.firms[b.firm]?.workers.length||!['factory','mill','bakery','sawmill'].includes(b.kind))continue;for(let j=0;j<3;j++){const t=(frameClock*.30+j*.40+b.id*.13)%1;g.fillStyle=`rgba(224,221,195,${.30*(1-t)})`;g.fillRect(Math.round(item.x-12+t*17),Math.round(item.y-48-t*24),3+Math.floor(t*6),3+Math.floor(t*5));}}
}
function draw(){
 if(!G||!dirty)return;dirty=false;if(staticDirty||lastSceneMonth!==G.month)drawStatic();
 ctx.setTransform(1,0,0,1,0,0);ctx.fillStyle='#6d8774';ctx.fillRect(0,0,cv.width,cv.height);
 const sx=cam.x-cw/(2*cam.zoom),sy=cam.y-ch/(2*cam.zoom),ww=cw/cam.zoom,hh=ch/cam.zoom;
 ctx.setTransform(dpr,0,0,dpr,0,0);ctx.imageSmoothingEnabled=false;ctx.drawImage(bitmap,sx,sy,ww,hh,0,0,cw,ch);transform();ctx.imageSmoothingEnabled=false;
 const visible=(x,y,m=120)=>x>=sx-m&&x<=sx+ww+m&&y>=sy-m&&y<=sy+hh+m;
 const items=displayItems.filter(a=>visible(a.x,a.y,200));for(const v of traffic){const p=vehiclePosition(v);if(visible(p.x,p.y,15))items.push({kind:'vehicle',v,...p});}items.sort((a,b)=>a.y-b.y);
 for(const item of items){if(item.kind==='vehicle'){vehiclePaint(ctx,item.v,item,frameClock);continue;}const spr=spriteFor(item);ctx.drawImage(spr,Math.round(item.x-128),Math.round(item.y-240));}
 atmosphere(ctx,sx,sy,ww,hh);
 if(G.airport?.operating&&G.airport.runway?.length>1){const a=roadCenter(G.airport.runway[0]),b=roadCenter(G.airport.runway.at(-1)),phase=(frameClock/22)%1;if(phase<.8){const t=phase/.8,x=a[0]+(b[0]-a[0])*t,y=a[1]+(b[1]-a[1])*t-Math.max(0,t-.6)*170;polygon(ctx,[[x-15,y],[x,y-3],[x+18,y],[x,y+3]],'#e6dfc2');polygon(ctx,[[x-2,y-17],[x+4,y],[x-2,y+17],[x-6,y]],'#b5c1af');}}
 if(overlay==='metro')drawMetroOverlay(ctx);
 if(overlay==='roads'||overlay==='business'||overlay==='hardship'||overlay==='crime'||overlay==='land')for(const item of displayItems){if(item.kind!=='building'||!visible(item.x,item.y))continue;const b=item.b,f=G.firms[b.firm],h=G.households[b.hh],net=graph();let color=overlay==='roads'?(net.portals.has(b.id)?'#9ecb95':'#bb7760'):overlay==='business'?(f?(f.closed?'#b66856':f.profit>0?'#a1c67d':'#d6b46c'):null):overlay==='hardship'?(h?(h.stress>50?'#b96c56':'#a9ca87'):null):overlay==='land'?(b.value>90000?'#c38864':b.value>45000?'#d0b776':'#9fc087'):null;if(!color)continue;ctx.globalAlpha=.7;diamond(ctx,b.x,b.y,color);ctx.globalAlpha=1;}
 if(selected?.id){const b=readBuild(selected.id);if(b){const p=iso(b.x,b.y);ctx.strokeStyle='#f4e2a5';ctx.lineWidth=2;ctx.beginPath();ctx.ellipse(p[0],p[1]+18,32,16,0,0,Math.PI*2);ctx.stroke();}}
 if(buildMode&&pointer.hover){const {x,y}=pointer.hover;if(x>=0&&x<T&&y>=0&&y<T){const valid=buildMode==='road'?cityCell(x,y)===0&&!buildingAt(x,y):buildMode==='repair'?cityCell(x,y)===1:canPlace(x,y,true,buildMode);ctx.globalAlpha=.60;for(const id of footprintFor(x,y,buildMode))diamond(ctx,id%T,id/T|0,valid?'#c8dea4':'#c48069');ctx.globalAlpha=1;}}
 if(nightMode){ctx.setTransform(dpr,0,0,dpr,0,0);ctx.fillStyle='#233c6460';ctx.fillRect(0,0,cw,ch);transform();for(const item of displayItems){if(item.kind!=='building'||!visible(item.x,item.y)||item.b.kind==='worksite')continue;const b=item.b;if(b.firm>=0&&G.firms[b.firm]?.closed)continue;const glow=ctx.createRadialGradient(item.x,item.y-12,1,item.x,item.y-12,28);glow.addColorStop(0,'#eac57a36');glow.addColorStop(1,'#eac57a00');ctx.fillStyle=glow;ctx.fillRect(item.x-28,item.y-40,56,56);}}
}

// SOURCE: 67-transport.js
function restoreTransport(){
 const state=G.trafficState;visualState=G.visualState||918273;
 traffic=[];trafficClock=0;intersectionGates.clear();
 if(state){traffic=(state.vehicles||[]).filter(v=>Array.isArray(v.path)&&v.path.length>=2&&v.path.every(n=>Number.isInteger(n)&&G.tiles[n]===1)&&Number.isInteger(v.segment)&&v.segment>=0&&v.segment<v.path.length-1&&Number.isFinite(v.fraction)&&v.fraction>=0&&v.fraction<1).slice(0,80).map(v=>({...v,path:v.path.slice()}));frameClock=Number(state.clock)||0;trafficElapsed=Number(state.elapsed)||0;vehicleSerial=Number(state.serial)||0;intersectionGates=new Map((state.gates||[]).filter(a=>Array.isArray(a)&&a.length===2));}
}
function pendingGoods(firm,good){return (G.freight||[]).filter(s=>s.to===firm.id&&s.good===good).reduce((n,s)=>n+s.qty,0);}
function dispatchGoods(seller,buyer,good,qty,path){
 G.freight=G.freight||[];G.nextFreight=(G.nextFreight||0)+1;
 const duration=Math.max(1,Math.ceil((path.length-1)/15));
 G.freight.push({id:G.nextFreight,from:seller.id,to:buyer.id,good,qty,path,remaining:duration,duration,started:G.day,delayed:0});
}
function freightDay(){
 if(!G.freight?.length)return;
 const keep=[];
 for(const s of G.freight){const from=G.firms[s.from],to=G.firms[s.to];if(!from||!to){throw Error('Shipment has an invalid owner');}
  const route=routeBetween(readBuild(from.building),readBuild(to.building));
  if(route.length<1){s.delayed++;keep.push(s);G.transport.delayed++;continue;}
  s.path=route;s.remaining--;
  if(s.remaining>0)keep.push(s);else{to.stock[s.good]=(to.stock[s.good]||0)+s.qty;G.transport.arrived++;}
 }
 G.freight=keep;
}
function spawnPurposeTrip(){
 if(!G)return null;
 // Trips are samples of actual commuter assignments or paid in-flight cargo.
 const freights=G.freight||[];if(freights.length&&vehicleSerial%3===0){const s=freights[vehicleSerial%freights.length],f=G.firms[s.from],t=G.firms[s.to];const v=beginVehicle(readBuild(f.building),readBuild(t.building));if(v){v.style='truck';v.reason=s.qty.toFixed(0)+' '+s.good+' → '+t.name;v.shipment=s.id;return v;}}
 const employed=G.people.filter(p=>!p.deceased&&!p.movedAway&&p.job>=0);if(!employed.length)return null;
 const p=employed[hash(vehicleSerial+G.day)%employed.length],h=G.households[p.hh],f=G.firms[p.job];
 const home=readBuild(h.home),work=readBuild(f.building);if(!home||!work||f.closed)return null;
 const v=beginVehicle(home,work);if(v){v.style=(p.id%3===0)?'pedestrian':'car';v.person=p.id;v.reason=p.name+' commuting to '+f.name;}return v;
}
function detour(v){
 const start=v.path[v.segment],goal=v.path.at(-1),net=graph();
 const queue=[start],parent=new Map([[start,-1]]),busy=new Set(traffic.filter(c=>c!==v&&c.wait>2).map(c=>c.path[c.segment]+'>'+c.path[c.segment+1]));
 for(let i=0;i<queue.length&&i<3200;i++){const at=queue[i];if(at===goal)break;for(const n of net.neighbors.get(at)||[]){if(parent.has(n)||busy.has(at+'>'+n))continue;parent.set(n,at);queue.push(n);}}
 if(!parent.has(goal))return false;
 const path=[];for(let at=goal;at!==-1;at=parent.get(at))path.push(at);path.reverse();
 if(path.length<2||path[1]===v.path[v.segment+1])return false;
 // Replanning happens only at a tile center, preserving continuous position.
 if(v.fraction>.001)return false;
 v.path=path;v.segment=0;v.wait=0;v.rerouted=(v.rerouted||0)+1;return true;
}

// SOURCE: 70-interaction.js
const pointer={down:false,startX:0,startY:0,px:0,py:0,moved:false,pinch:0,buildTrail:0,hover:null};
function toWorld(x,y){const wx=(x-cw/2)/cam.zoom+cam.x,wy=(y-ch/2)/cam.zoom+cam.y;
 let r=(wx-RW/2)/(TW/2),s=(wy-32-TH/2)/(TH/2);return [Math.floor((s+r)/2+.5),Math.floor((s-r)/2+.5)]}
function onTap(sx,sy){if(!G)return;const r=cv.getBoundingClientRect();const [x,y]=toWorld(sx-r.left,sy-r.top);if(x<0||x>=T||y<0||y>=T)return;
 if(buildMode){construct(buildMode,x,y);return}
 const mx=(sx-r.left-cw/2)/cam.zoom+cam.x,my=(sy-r.top-ch/2)/cam.zoom+cam.y;
 let b=buildingAt(x,y);if(!b){const hit=G.buildings.filter(v=>{const pos=iso(v.x,v.y);return Math.abs(mx-pos[0])<20&&my>=pos[1]-38&&my<=pos[1]+33}).sort((a,b)=>iso(b.x,b.y)[1]-iso(a.x,a.y)[1]);b=hit[0]}
 if(b){selected={id:b.id};openPanel('inspect')}else{selected=null;toast('Unoccupied land. Private investors assess access, demand and expected returns.')}
 dirty=true;
}
cv.addEventListener('pointerdown',e=>{if(pointer.down){pointer.moved=true;return;}pointer.activeId=e.pointerId;roadPainted.clear();pointer.lastRoad=buildMode==='road'?toWorld(e.clientX-cv.getBoundingClientRect().left,e.clientY-cv.getBoundingClientRect().top):null;pointer.down=true;pointer.startX=pointer.px=e.clientX;pointer.startY=pointer.py=e.clientY;pointer.moved=false;try{cv.setPointerCapture(e.pointerId)}catch(err){} });
cv.addEventListener('pointermove',e=>{if(!pointer.down||pointer.activeId!==e.pointerId||touches.size>1)return;let dx=e.clientX-pointer.px,dy=e.clientY-pointer.py;if(Math.abs(e.clientX-pointer.startX)>7||Math.abs(e.clientY-pointer.startY)>7)pointer.moved=true;
 if(buildMode==='road'){let br=cv.getBoundingClientRect(),pt=toWorld(e.clientX-br.left,e.clientY-br.top);let prev=pointer.lastRoad||pt;let dxg=pt[0]-prev[0],dyg=pt[1]-prev[1],steps=Math.max(Math.abs(dxg),Math.abs(dyg),1);for(let k=0;k<=steps;k++){let ax=Math.round(prev[0]+dxg*k/steps),ay=Math.round(prev[1]+dyg*k/steps),key=ax+'/'+ay;if(!roadPainted.has(key)){roadPainted.add(key);construct('road',ax,ay,true)}}pointer.lastRoad=pt}else{cam.x-=dx/cam.zoom;cam.y-=dy/cam.zoom;cam.x=clamp(cam.x,0,RW);cam.y=clamp(cam.y,0,RH)}pointer.px=e.clientX;pointer.py=e.clientY;let rect=cv.getBoundingClientRect(),tile=toWorld(e.clientX-rect.left,e.clientY-rect.top);pointer.hover={x:tile[0],y:tile[1]};dirty=true});
cv.addEventListener('pointerup',e=>{if(pointer.activeId!==e.pointerId)return;if(pointer.down&&!pointer.moved)onTap(e.clientX,e.clientY);flushRoadBatch();pointer.down=false;pointer.activeId=null;pointer.lastRoad=null;roadPainted.clear()});
window.addEventListener('keydown',e=>{if(e.key==='Escape'&&buildMode){buildMode='';pointer.hover=null;dirty=true;$('placementHint').style.display='none';$('hint').textContent='DRAG TO PAN · TAP TO INSPECT';toast('Construction tool closed')}});cv.addEventListener('pointercancel',()=>{flushRoadBatch();pointer.down=false;pointer.activeId=null;pointer.lastRoad=null;roadPainted.clear()});cv.addEventListener('pointerleave',()=>{pointer.hover=null;dirty=true});
cv.addEventListener('wheel',e=>{e.preventDefault();cam.zoom=clamp(cam.zoom*(e.deltaY<0?1.12:.89),.26,1.7);dirty=true},{passive:false});
let touches=new Map();cv.addEventListener('touchstart',e=>{touches=new Map([...e.touches].map(t=>[t.identifier,{x:t.clientX,y:t.clientY}]));if(touches.size===2){pointer.moved=true;const a=[...touches.values()];pointer.pinch=Math.hypot(a[0].x-a[1].x,a[0].y-a[1].y)}},{passive:true});
cv.addEventListener('touchmove',e=>{touches=new Map([...e.touches].map(t=>[t.identifier,{x:t.clientX,y:t.clientY}]));if(touches.size===2){const a=[...touches.values()],d=Math.hypot(a[0].x-a[1].x,a[0].y-a[1].y);if(pointer.pinch>0){cam.zoom=clamp(cam.zoom*d/pointer.pinch,.26,1.7);dirty=true}pointer.pinch=d}},{passive:true});
cv.addEventListener('touchend',e=>{touches=new Map([...e.touches].map(t=>[t.identifier,{x:t.clientX,y:t.clientY}]));pointer.pinch=0});
cv.addEventListener('touchcancel',()=>{touches.clear();pointer.pinch=0;pointer.down=false;pointer.activeId=null;pointer.lastRoad=null;roadPainted.clear();flushRoadBatch();});
function construct(kind,x,y,quiet=false){
 if(kind==='inspect'){buildMode='';const target=buildingAt(x,y);if(target){selected={id:target.id};openPanel('inspect')}else toast('No building is present at this lot.');dirty=true;return}
 if(kind==='repair'){if(x<0||x>=T||y<0||y>=T||cityCell(x,y)!==1){if(!quiet)toast('Select an existing road tile to resurface.');return}ensureRoadWear();if(G.roadWear[roadId(x,y)]>96){if(!quiet)toast('This street is already in excellent condition.');return}if(G.treasury<buildCost.repair){if(!quiet)toast('Insufficient town funds.');return}G.treasury-=buildCost.repair;G.region+=buildCost.repair;G.roadWear[roadId(x,y)]=100;G.construction++;staticDirty=true;dirty=true;updateHeader();if(!quiet)toast('Street resurfaced.');return}
 if(kind==='road'){
   if(x<0||x>=T||y<0||y>=T)return;
   if(cityCell(x,y)!==0||G.landUse?.[roadId(x,y)]||buildingAt(x,y)){if(!quiet)toast('Road requires vacant, unreserved land.');return}
   if(G.treasury<buildCost.road){if(!quiet)toast('Insufficient town funds for this road.');return}
   G.treasury-=buildCost.road;G.region+=buildCost.road;G.tiles[y*T+x]=1;ensureRoadWear();G.roadWear[roadId(x,y)]=100;G.construction++;dirty=true;
   if(quiet){roadBatchDirty=true;return;}invalidateRoads();staticDirty=true;recompute();updateHeader();save();return;
 }
 if(!canPlace(x,y,true,kind)){toast('This project requires a fully vacant footprint with road access.');return}
 if(kind==='fishery'&&!Array.from({length:9},(_,i)=>[x+(i%3)-1,y+Math.floor(i/3)-1]).some(([a,b])=>cityCell(a,b)===2)){toast('A fishery must adjoin the river.');return}
 if(kind==='forestry'&&!Array.from({length:25},(_,i)=>[x+(i%5)-2,y+Math.floor(i/5)-2]).some(([a,b])=>cityCell(a,b)===3)){toast('Forestry operations require nearby woodland.');return}
 const cost=buildCost[kind];if(G.treasury<cost){toast('Town treasury cannot afford '+types[kind].n+' ('+money(cost)+').');return}
 G.treasury-=cost;G.region+=cost;
 if(['grocer','bakery','mill','farm','forestry','sawmill','quarry','contractor','tavern','fishery','factory','warehouse','office','college'].includes(kind)){
   if(G.region<15000){toast('Regional investment capital is exhausted.');G.treasury+=cost;G.region-=cost;return}
   G.region-=12000+G.policy.permitFee;const newFirm=createFirm(kind,x,y);newFirm.cash=12000;transferTreasury(G.policy.permitFee,'permits');assignJobs();story('New local enterprise: '+types[kind].n+' opens on a developed lot.','good');
 }else if(kind==='home'){
   const b={id:G.nextId++,kind,x,y,value:48000,condition:100,owner:-1,firm:-1,hh:-1};G.buildings.push(b);let family={id:G.households.length,name:pick(surnames),cash:rn(900,3000),home:b.id,owner:-1,people:[],income:0,rent:0,food:0,tax:0,aid:0,crimeLoss:0,stress:25,security:85,last:[],worklessness:0};
   G.households.push(family);G.region-=family.cash;G.homes.push(b.id);b.hh=family.id;b.owner=family.id;
   for(let n=0;n<2;n++){let p={id:G.people.length,name:pick(first)+' '+family.name,age:Math.round(rn(19,60)),skill:rn(.3,1),health:rn(65,100),hh:family.id,job:-1,life:65,last:[]};G.people.push(p);family.people.push(p.id)}
   assignJobs();story('A new household settled in the village.','good',b.id,family.id);
 }else G.buildings.push({id:G.nextId++,kind,x,y,value:cost*10,condition:100,owner:-1,firm:-1,hh:-1,footprint:footprintFor(x,y,kind)});
 G.construction++;invalidateRoads();recompute();updateHeader();staticDirty=true;dirty=true;save();toast(types[kind].n+' constructed.');if(active==='construction')renderPanel('construction');
}
function stat(label,value,cls=''){return `<div class="stat"><small>${esc(label)}</small><b class="${cls}">${esc(value)}</b></div>`}
function line(label,value,cls=''){return `<div class="line"><span>${esc(label)}</span><span class="${cls}">${esc(value)}</span></div>`}
function head(s){return `<div class="section">${esc(s)}</div>`}
function chart(field,bad=false){const ar=G.history.slice(-65);if(!ar.length)return '';let vals=ar.map(x=>x[field]),mn=Math.min(...vals),mx=Math.max(...vals),range=Math.max(1,mx-mn);return `<div class="history">${ar.map(x=>`<i class="${bad?'bad':''}" style="height:${Math.max(4,10+90*(x[field]-mn)/range)}%" title="Day ${x.day}: ${fmt(x[field])}"></i>`).join('')}</div><div class="desc">Observations, last ${ar.length} days · range ${fmt(mn)}–${fmt(mx)}.</div>`}
function renderOverview(){const s=G.stats;
 return head('This morning in town')+`<div class="statgrid">${stat('Population',fmt(s.population))}${stat('Employment',s.employment+'%')}${stat('Business doors open',s.businesses+' / '+G.firms.length)}${stat('Households in hardship',s.hardship+'%',s.hardship>30?'negative':'')}</div>`+
 head('Public ledger')+line('Municipal cash',money(G.treasury))+line('Debt',money(G.debt))+line('Outstanding household savings',money(s.cash))+line('Private business capital',money(s.businessCash))+
 head('A village of consequences')+`<p class="desc">Tax and wage decisions affect real household balances. Goods move among farms, mills, bakeries and grocers. Businesses can close, police respond to crime, and the town can face fires. Select any property on the map to inspect its inhabitants or finances.</p>`+
 chart('employment')+head('Latest entries')+G.events.slice(0,8).map(eventHtml).join('');
}
function eventHtml(e){return `<div class="event"><strong>Day ${e.day}</strong> · ${esc(e.text)} ${e.bid>0?`<button class="small" data-inspect="${e.bid}">View</button>`:''}</div>`}
function renderCommunity(){const s=G.stats;
 return head('Community condition')+`<div class="statgrid">${stat('Safety index',s.safety+'/100')}${stat('Crime / last 30 days',fmt(s.dailyCrime))}${stat('Emergency readiness',s.preparedness+'%')}${stat('Households in hardship',s.hardship+'%')}</div>`+
 `<p class="desc">Funding and stations affect response capacity. Hardship, job loss and isolation affect risks. Theft removes real money from victims and transfers it to another local household; incidents are attached to locations.</p>`+
 head('Community expenditure')+line('Policing / day',money(G.policy.policeBudget))+line('Fire & defence / day',money(G.policy.defenseBudget))+line('Housing assistance / day',money(G.policy.aidBudget))+line('Outreach / day',money(G.policy.outreachBudget))+
 head('Local incident register')+(G.cases.length?G.cases.slice(0,15).map(eventHtml).join(''):'<p class="desc">No criminal incidents recorded yet.</p>')+
 head('Safety trend')+chart('safety');
}
function slider(d){let [k,name,lo,hi,step,unit,help]=d,v=G.policy[k];return `<div class="range"><label><b>${esc(name)}</b><span id="show-${k}">${unit==='$'?'$'+fmt(v):fmt(v)+unit}</span></label><input aria-label="${esc(name)}" type="range" min="${lo}" max="${hi}" step="${step}" value="${v}" data-policy="${k}"><div class="desc">${esc(help)}</div></div>`}
function renderPolicies(){return head('A government economics experiment')+`<p class="desc">Move a policy control to enact it immediately. Entries are logged with baseline employment, safety, hardship, cash and business counts. Comparisons are observations, not proof of causation.</p>`+
 defs.map(slider).join('')+head('Trade & exchange')+
 `<div class="line"><span>Allow regional imports</span><button id="tradeToggle" class="small ${G.policy.imports?'on':''}">${G.policy.imports?'ALLOWED':'RESTRICTED'}</button></div><p class="desc">A closed border can interrupt the village supply chain. Tariffs transfer money to the treasury but increase import costs.</p>`;
}
function renderTreasury(){let c=G.cumulative,p=G.policy;
 return head('Municipal accounts')+`<div class="statgrid">${stat('Cash on hand',money(G.treasury),G.treasury<5000?'negative':'')}${stat('Municipal borrowing',money(G.debt))}${stat('Income taxes collected',money(c.incomeTax))}${stat('Business profit taxes',money(c.profitTax))}</div>`+
 head('Receipts since founding')+line('Income tax',money(c.incomeTax))+line('Profit tax',money(c.profitTax))+line('Land and property',money(c.propertyTax))+line('Food sales tax',money(c.foodTax))+line('Business permits',money(c.permits))+line('Import tariffs',money(c.tariffs))+
 head('Expenditure since founding')+line('Public services and subsidies',money(c.spending))+line('Direct housing aid',money(c.welfare))+line('Unpaid principal',money(G.debt))+
 `<div class="btnrow"><button id="borrow">Borrow $5,000</button><button id="repay">Repay $5,000</button></div><p class="desc">Borrowing increases both cash and outstanding debt. Interest accrues each month and is paid to the regional lender. Unfunded public budgets reduce service capacity.</p>`+
 head('Treasury history')+chart('treasury');
}
function renderCitizens(){return head('Village families')+`<p class="desc">Select a household to inspect each resident's name, age, job, savings, food expenses, taxes and hardship.</p>`+
 G.households.filter(h=>h.people.length>0).map(h=>{let b=readBuild(h.home),people=h.people.map(id=>G.people[id]).filter(p=>p&&!p.deceased&&p.movedAway!==true),workers=people.filter(p=>p.job>=0||p.publicWork).length;return `<div class="entry" data-house="${h.id}"><strong>The ${esc(h.name)} household</strong><br><small>${people.length} people · ${workers} employed · Savings ${money(h.cash)} · Stress ${Math.round(h.stress)}/100 · Lot ${b?`${b.x},${b.y}`:'?'}</small></div>`}).join('');
}
function renderBusinesses(){let total=G.firms.filter(f=>!f.closed).length;
 return head('Private enterprises')+`<p class="desc">${total} businesses operate. Wages, input prices, permit fees, sales taxes, production and crime influence their balances. Tap one to inspect.</p>`+
 G.firms.map(f=>`<div class="entry" data-firm="${f.id}"><strong>${esc(f.name)}</strong> <span class="pill">${f.closed?'CLOSED':'OPEN'}</span><br><small>${esc(types[f.kind].n)} · ${f.workers.length}/${f.jobs} staff · ${money(f.cash)} cash · Last profit ${money(f.profit)}</small></div>`).join('');
}
function renderConstruction(){return head('Village planning and private development')+
 '<p class="desc">Choose a building type, then tap a clear roadside plot on the map. Road tiles can be extended over open land. Costs are paid from town funds and recorded as construction purchases. Private enterprises also require regional investment capital.</p>'+
 `<div class="btnrow"><button data-build="" class="${buildMode===''?'on':''}">Inspect</button>${Object.entries(buildCost).map(([key,cost])=>`<button data-build="${key}" class="${buildMode===key?'on':''}">${buildIcons[key]} ${esc(types[key]?types[key].n:'Road')} · ${money(cost)}</button>`).join('')}</div>`+
 head('Physical services')+line('Police stations',G.buildings.filter(b=>b.kind==='police').length)+line('Fire brigades',G.buildings.filter(b=>b.kind==='fire').length)+line('Houses',G.homes.length)+line('Developed lots',G.buildings.length);
}
function renderJournal(){const j=G.journal;
 return head('The policy journal')+`<p class="desc">Every change captures the village's state when enacted. The differences below compare the current village with that baseline. They may reflect other events, time and policy changes.</p>`+
 j.slice().reverse().map(p=>{
 const base=p.baseline||{};const diff=(key,suff='',sign=false)=>{let d=(key==='treasury'?G.treasury:G.stats[key])-(base[key]||0);return (d>=0?'+':'')+fmt(d)+suff};
 return `<div class="entry"><strong>Day ${p.day}: ${esc(p.name)}</strong><p class="desc">${esc(p.message||'')}</p><div class="compact">Since change: employment ${diff('employment',' pts')} · hardship ${diff('hardship',' pts')} · safety ${diff('safety',' pts')} · businesses ${diff('businesses')} · treasury ${diff('treasury')}</div></div>`}).join('');
}
function renderSettings(){return head('Local save and diagnostics')+
 line('App version','5.6.0 · Android adaptation')+line('Engine','Hardware-accelerated WebView Canvas 2D')+line('Residents',G.people.length)+line('Active businesses',G.stats.businesses)+line('Rendered scenery','Retained offscreen map image')+line('Snapshot schedule','Only on daily economy updates')+
 '<p class="desc">This is an offline Android adaptation, not a port of the original Godot/C++ project. Save data resides locally in app storage.</p><div class="btnrow"><button id="saveNow">Save game</button><button id="restart" class="red">Start a new village</button></div>'+
 head('Model limitations')+'<p class="desc">This is an illustrative agent-based economy. Policy outcomes use explicit behavioural rules, not statistically estimated causal effects. A single simulated town cannot establish what real-world policy will do.</p>';
}
function renderInspect(){const b=selected&&readBuild(selected.id);if(!b)return '<p>No property selected.</p>';const loc=`Lot ${b.x}, ${b.y}`;
 let html=head(types[b.kind].n+' · '+loc)+`<div class="statgrid">${stat('Estimated property value',money(b.value))}${stat('Condition',fmt(b.condition)+'/100')}</div>`;
 if(b.kind==='home'){
   const h=G.households[b.hh];if(!h)return html;
   html+=head('The '+h.name+' household')+`<div class="statgrid">${stat('Liquid savings',money(h.cash),h.cash<150?'negative':'')}${stat('Stress',fmt(h.stress)+'/100',h.stress>60?'negative':'')}${stat('Food yesterday',money(h.food))}${stat('Income yesterday',money(h.income))}</div>`+
   line('Rent yesterday',money(h.rent))+line('Income taxes yesterday',money(h.incomeTax??h.tax))+line('Housing assistance yesterday',money(h.aid))+line('Lifetime theft losses',money(h.crimeLoss))+line('Perceived security',fmt(h.security)+'/100')+
   head('People living here')+h.people.map(id=>{const p=G.people[id];if(!p)return '';const f=G.firms[p.job];return `<div class="entry"><strong>${esc(p.name)}</strong><br><small>Age ${p.age} · ${f?esc(f.name):'Not employed'} · Health ${Math.round(p.health)}/100</small></div>`}).join('');
 }else if(b.firm>=0){const f=G.firms[b.firm];if(f){html+=head(f.name)+`<div class="statgrid">${stat('Enterprise cash',money(f.cash))}${stat('Workers',f.workers.length+'/'+f.jobs)}${stat('Revenue yesterday',money(f.revenue))}${stat('Net profit yesterday',money(f.profit),f.profit<0?'negative':'')}</div>`+
 line('Minimum payable wage',money(workerIncome(f))+'/day')+line('Cash stolen since opening',money(f.theft))+line('Business taxes yesterday',money(f.tax))+
 head('Warehouse')+Object.keys(goods).map(k=>line(k,fmt(f.stock[k]||0))).join('')+
 head('Employees')+f.workers.slice(0,20).map(id=>{const p=G.people[id];return p?`<div class="line"><span>${esc(p.name)}</span><span>${esc(G.households[p.hh]?.name||'')}</span></div>`:''}).join('');
 }}else html+='<p class="desc">Public facility. Its physical presence improves village services only when the municipality funds the corresponding budget.</p>';
 html+=`<p class="desc">Ownership and all financial amounts are modelled local accounts, not decorative scores.</p>`;return html;
}
function openPanel(tab){active=tab;$('panel').classList.add('show');$('panelBody').scrollTop=0;$('tabs').querySelectorAll('button').forEach(b=>b.classList.toggle('active',b.dataset.panel===tab));renderPanel(tab)}
function closePanel(){active='';$('panel').classList.remove('show');$('tabs').querySelectorAll('button').forEach(b=>b.classList.remove('active'))}
function economySnapshot(){
 const demand=cityDemand(),activeFirms=G.firms.filter(f=>!f.closed),families=G.households.filter(h=>h.people.some(id=>G.people[id]&&!G.people[id].deceased&&!G.people[id].movedAway));
 const byType={},kindSections={farm:'Agriculture',fishery:'Agriculture',forestry:'Resource extraction',quarry:'Resource extraction',mill:'Manufacturing',sawmill:'Manufacturing',factory:'Manufacturing',bakery:'Food & retail',grocer:'Food & retail',tavern:'Food & retail',warehouse:'Logistics',contractor:'Construction',office:'Services',college:'Services'};
 for(const f of G.firms){const sector=kindSections[f.kind]||'Other services',entry=byType[sector]||(byType[sector]={sector,open:0,closed:0,workers:0,jobs:0,profit:0,sales:0,capital:0,atRisk:0});
  if(f.closed)entry.closed++;else {entry.open++;entry.workers+=f.workers.length;entry.jobs+=f.jobs;entry.profit+=f.profit||0;entry.sales+=f.revenue||0;entry.capital+=f.cash||0;if(f.profit<0&&f.cash<Math.max(2500,f.wage*f.jobs*12))entry.atRisk++;}
 }
 const values=families.map(h=>h.cash/Math.max(1,h.people.length)).sort((a,b)=>a-b),median=values.length?values[Math.floor(values.length/2)]:0;
 const banks=G.banks.filter(b=>!b.closed),deposits=banks.reduce((sum,b)=>sum+bankDeposits(b.id),0),reserves=banks.reduce((sum,b)=>sum+b.cash,0),loans=G.loans.filter(l=>l.status==='active').reduce((sum,l)=>sum+l.balance,0);
 const marketJobs=activeFirms.reduce((sum,f)=>sum+f.jobs,0),working=activeFirms.reduce((sum,f)=>sum+f.workers.length,0);
 const vacantHomes=G.homes.filter(id=>{const b=readBuild(id);return b&&(!G.households[b.hh]||!G.households[b.hh].people.some(pid=>G.people[pid]&&!G.people[pid].movedAway&&!G.people[pid].deceased))}).length;
 return {demand,sectors:Object.values(byType).filter(x=>x.open||x.closed).sort((a,b)=>b.workers-a.workers),families:families.length,median,open:activeFirms.length,closed:G.firms.length-activeFirms.length,atRisk:activeFirms.filter(f=>f.profit<0&&f.cash<Math.max(2500,f.wage*f.jobs*12)).length,banks:banks.length,deposits,reserves,loans,marketJobs,working,vacantHomes,projects:(G.projects||[]).length};
}
function marketSignal(){const m=economySnapshot(),s=G.stats;let title,description,kind;
 if(s.hardship>35){title='Households under pressure';description='High hardship threatens local demand. Consider relief, jobs and essential living costs.';kind='danger';}
 else if(s.employment<65){title='A weak labour market';description='Jobs are scarce. Check business cash flow and the cost of hiring.';kind='danger';}
 else if(m.demand.housingPressure>75){title='Housing market tightening';description='Land values and household crowding favour new homes, if zoning and finance allow.';kind='warn';}
 else if(m.atRisk>=3){title='Firms at risk';description=m.atRisk+' active businesses have losses and thin cash buffers.';kind='warn';}
 else if(s.employment>85&&s.hardship<14){title='Broad-based prosperity';description='Employment is high and most households are meeting their expenses.';kind='good';}
 else {title='The economy is adjusting';description='Follow private construction, credit, employment and household purchasing power.';kind='normal';}
 return {title,description,kind,m};
}
function renderEconomy(){let signal=marketSignal(),m=signal.m,d=m.demand,active=G.firms.filter(f=>!f.closed),jobs=active.reduce((s,f)=>s+f.jobs,0),filled=active.reduce((s,f)=>s+f.workers.length,0);
 const cell=(name,value,detail,cls='')=>`<div class="market-cell ${cls}"><small>${esc(name)}</small><strong>${esc(value)}</strong><span>${esc(detail)}</span></div>`;
 return `<div class="market-status ${signal.kind}"><small>LIVE BOROUGH ECONOMY</small><h3>${esc(signal.title)}</h3><p>${esc(signal.description)}</p></div>`+
 `<div class="market-cells">${cell('Employment',G.stats.employment+'%',G.stats.employed+' residents working')}${cell('Median savings',money(m.median),'per household member')}${cell('Housing pressure',d.housingPressure+'/100',m.vacantHomes+' vacant cottages')}${cell('Private work sites',String(m.projects),'projects underway')}${cell('Businesses',String(m.open),m.closed+' historical closures')}${cell('Banks & credit',String(m.banks),money(m.loans)+' loans outstanding')}</div>`+
 head('Where people earn their living')+`<p class="desc">Actual operating enterprises, employees, sales and daily operating profit. A negative profit reflects losses, not an abstract score.</p>`+
 `<table class="market-table"><thead><tr><th>Industry</th><th>Firms</th><th>Jobs</th><th>Daily profit</th></tr></thead><tbody>`+m.sectors.map(x=>`<tr><td>${esc(x.sector)}${x.atRisk?` <small class="risk-mark">${x.atRisk} at risk</small>`:''}</td><td>${x.open}</td><td>${x.workers}/${x.jobs}</td><td class="${x.profit<0?'negative':'positive'}">${money(x.profit)}</td></tr>`).join('')+'</tbody></table>'+
 head('Private investment, not player placement')+meter('Demand for homes',d.homeDemand,d.homeDemand>65?'#e6a37a':'#9dce9c')+meter('Demand for commerce',d.businessDemand,'#adc7a9')+strip('Job openings',d.jobVacancy)+strip('Residential capacity',d.homes+' housing units')+strip('Next private sites',m.projects+' projects in construction')+strip('Regional exports & investment',money(G.region))+
 head('Banks, loans and savings')+strip('Household and company deposits',money(m.deposits))+strip('Cash reserves at local banks',money(m.reserves))+strip('Loans still being repaid',money(m.loans))+strip('Banks in operation',m.banks)+
 head('What should the government do?')+`<div class="council-card"><p class="desc">You do not control private developers, firms or banks. Adjust a few policy rates, funding priorities or municipal borrowing and let the market respond. Watch outcomes over months and years, not just individual days.</p><div class="btnrow"><button id="marketPolicy">Review policy rates</button><button id="marketFamilies">Inspect households</button><button id="marketCompanies">Inspect firms</button></div></div>`+
 head('Employment history')+miniChart('employment')+head('Private enterprise count')+miniChart('businesses')+head('Households under pressure')+miniChart('hardship')+head('Recent economic developments')+headlineList(8);
}
const names={economy:'The Living Economy',banking:'Banks & Credit',overview:'Town Hall',agenda:'Council Agenda',community:'Civic Services',policies:'Economic Policy',treasury:'The Public Purse',citizens:'Our Residents',businesses:'Local Enterprise',construction:'Works & Planning',journal:'Public Record',settings:'Game Options',inspect:'Property Inspector'};
function renderPanel(tab){if(!G)return;const sc=$('panelBody');const y=sc.scrollTop;let contents='';
 try{contents=({overview:renderOverviewFull,economy:renderEconomy,agenda:renderAgenda,community:renderCommunityFull,policies:renderPoliciesFull,treasury:renderTreasuryFull,banking:financePanel,citizens:renderCitizensFull,businesses:renderBusinessesFull,construction:renderConstructionFull,journal:renderJournalFull,settings:renderSettingsFull,inspect:renderInspectFull}[tab]||renderOverview)()}
 catch(e){contents='<div class="event">Panel error: '+esc(e.message)+'</div>';console.error(e)}
 $('panelTitle').textContent=names[tab]||'TownLedger';sc.innerHTML=contents;sc.scrollTop=y;
}
function journalPolicy(k,old,nv){const base={...G.stats,treasury:G.treasury};G.journal.push({day:G.day,name:defs.find(d=>d[0]===k)?.[1]||k,message:`Policy revised from ${fmt(old)} to ${fmt(nv)}.`,baseline:base});if(G.journal.length>100)G.journal.shift();story('Council revised '+(defs.find(d=>d[0]===k)?.[1]||k)+'.','neutral')}
$('tabs').addEventListener('click',e=>{const b=e.target.closest('button[data-panel]');if(!b)return;const p=b.dataset.panel;if(p===active)closePanel();else openPanel(p)});
$('panelClose').onclick=closePanel;
$('panelBody').addEventListener('input',e=>{if(e.target.id==='searchPeople'){citizenQuery=e.target.value;return;}const input=e.target.closest('[data-policy]');if(!input)return;let k=input.dataset.policy,value=+input.value;const d=defs.find(d=>d[0]===k);draftPolicy[k]=value;const el=$('show-'+k);if(el)el.textContent=d[5]==='$'?money(value):fmt(value)+d[5];const button=$('enactPolicy');if(button)button.disabled=false;const summ=$('draftSummary');if(summ)summ.textContent=Object.keys(draftPolicy).filter(k=>draftPolicy[k]!==G.policy[k]).map(k=>defs.find(d=>d[0]===k)?.[1]+': '+fmt(G.policy[k])+' → '+fmt(draftPolicy[k])).join(' · ')});
$('panelBody').addEventListener('change',e=>{if(e.target.id==='searchPeople'){renderPanel('citizens');return;}const input=e.target.closest('[data-policy]');if(!input)return;draftPolicy[input.dataset.policy]=+input.value;const b=$('enactPolicy');if(b)b.disabled=false});
$('panelBody').addEventListener('click',e=>{const b=e.target.closest('button,[data-house],[data-firm],[data-inspect],[data-ambition]');if(!b)return;
 if(b.dataset.build!==undefined){flushRoadBatch();buildMode=b.dataset.build;$('hint').textContent=buildMode?'TAP A CLEAR ROADSIDE PLOT · '+(buildMode==='road'?'DRAG TO PAINT ROADS':'DRAG TO PAN'):'DRAG TO PAN · TAP TO INSPECT';$('placementHint').style.display=buildMode?'block':'none';$('placementHint').textContent=buildMode?'PLACING '+(types[buildMode]?.n||'ROADS').toUpperCase()+' · COST '+money(buildCost[buildMode]):'';closePanel();toast(buildMode?'Tap the map to build '+(types[buildMode]?.n||'road')+'.':'Inspection mode enabled');return}
 if(b.dataset.house!==undefined){const h=G.households[+b.dataset.house];if(h){const house=readBuild(h.home);if(!house){toast('This household no longer has an address in town.');return}selected={id:h.home};openPanel('inspect');const p=iso(house.x,house.y);cam.x=p[0];cam.y=p[1];dirty=true}return}
 if(b.dataset.firm!==undefined){const f=G.firms[+b.dataset.firm];if(f){const house=readBuild(f.building);if(!house){toast('This company no longer has premises in town.');return}selected={id:f.building};openPanel('inspect');const p=iso(house.x,house.y);cam.x=p[0];cam.y=p[1];dirty=true}return}
 if(b.dataset.inspect!==undefined){selected={id:+b.dataset.inspect};openPanel('inspect');const house=readBuild(selected.id);if(house){const p=iso(house.x,house.y);cam.x=p[0];cam.y=p[1];dirty=true}return}
 if(b.id==='enactPolicy'){enactPolicyPackage();return}
 if(b.id==='resetPolicy'){draftPolicy={};renderPanel('policies');return}
 if(b.dataset.cabinet){const packageRates={
 enterprise:{incomeTax:10,profitTax:7,permitFee:0,zoningRestriction:10,businessRegulation:20},
 housing:{zoningRestriction:0,propertyTax:1,transitBudget:90,permitFee:35},
 services:{incomeTax:19,profitTax:22,healthBudget:190,educationBudget:200,aidBudget:160,roadBudget:140},
 austerity:{incomeTax:14,profitTax:14,healthBudget:75,educationBudget:75,policeBudget:110,defenseBudget:80,aidBudget:55,roadBudget:80}
 };const rates=packageRates[b.dataset.cabinet];if(rates){for(const [k,v] of Object.entries(rates)){const d=defs.find(d=>d[0]===k);if(d)draftPolicy[k]=clamp(v,d[2],d[3]);}renderPanel('policies');toast('Policy proposal drafted. Review and enact it to apply.');}return}
 if(b.id==='marketPolicy'){openPanel('policies');return}
 if(b.id==='marketFamilies'){openPanel('citizens');return}
 if(b.id==='marketCompanies'){openPanel('businesses');return}
 if(b.id==='jumpAgenda'){openPanel('agenda');return}
 if(b.id==='jumpJournal'){openPanel('journal');return}
 if(b.id==='closeInspect'){closePanel();return}
 if(b.id==='convene'){if(G.day-G.lastEventDay>=12){offerCouncilEvent(true)}return}
 if(b.dataset.inbox!==undefined){reviewCouncilInbox(+b.dataset.inbox);return}
 if(b.dataset.ambition){G.ambition=b.dataset.ambition;updateHeader();renderPanel('agenda');save();return}
 if(b.dataset.filterPeople){filterPeople=b.dataset.filterPeople;renderPanel('citizens');return}
 if(b.dataset.filterFirms){filterFirms=b.dataset.filterFirms;renderPanel('businesses');return}
 if(b.dataset.buildCategory){constructionCategory=b.dataset.buildCategory;renderPanel('construction');return}
 if(b.id==='focusBad'){const poor=G.households.filter(h=>h.people.length>0&&readBuild(h.home)).sort((a,b)=>a.cash/Math.max(1,a.people.length)-b.cash/Math.max(1,b.people.length))[0];if(poor&&readBuild(poor.home)){selected={id:poor.home};openPanel('inspect')}return}
 if(b.id==='saveNow'){save();toast(autoSaveOK?'Village saved on this device.':'Save requested; use export backup if storage is unavailable.')}
 if(b.id==='restart'){showCustomEvent('TOWN ARCHIVE','Found another town?','Starting a new village will overwrite your most recent local autosave. Export a backup before proceeding.',[
  {title:'Keep the present village',desc:'Return to your existing town.',apply:()=>{}},
  {title:'Start a fresh village',desc:'Discard the current local save and return to the founding menu.',apply:()=>{start(true);closePanel();toast('A new village has been founded.')}}
 ]);return}
 if(b.id==='backupSave'){exportSave();return}
 if(b.id==='importSave'){importSave();return}
 if(b.id==='tutorial'){ $('helpDialog').style.display='flex';return}
 if(b.id==='toggleDevelopment'){G.autoBuild=!G.autoBuild;save();renderPanel(active);toast(G.autoBuild?'Private investment resumed.':'New private construction paused.');return;}
 if(b.id==='overlayMetro'){overlay=overlay==='metro'?'none':'metro';dirty=true;renderPanel(active);return;}
 if(b.id==='overlayR'){overlay=overlay==='roads'?'none':'roads';dirty=true;renderPanel(active);return}
 if(b.id==='overlayC'){overlay=overlay==='crime'?'none':'crime';dirty=true;renderPanel(active);return}
 if(b.id==='overlayH'){overlay=overlay==='hardship'?'none':'hardship';dirty=true;renderPanel(active);return}
 if(b.id==='overlayB'){overlay=overlay==='business'?'none':'business';dirty=true;renderPanel(active);return}
 if(b.id==='tradeToggle'){let prev=G.policy.imports;G.policy.imports=!prev;journalPolicy('Regional imports',prev,G.policy.imports);save();renderPanel(active)}
 if(b.id==='soundToggle'){soundEnabled=!soundEnabled;try{localStorage.setItem('townledger-audio',soundEnabled?'on':'off')}catch(e){};refreshAmbience();renderPanel('settings');return}
 if(b.id==='borrow'){let limit=Math.max(25000,G.stats.population*350);if(G.debt+5000>limit||G.region<5000){toast('Regional lender declined: the credit limit or available funds have been reached.');return;}G.debt+=5000;G.treasury+=5000;G.region-=5000;story('Council borrowed $5,000 from the regional lender.');recompute();updateHeader();save();renderPanel(active)}
 if(b.id==='repay'){let v=Math.min(5000,G.debt,G.treasury);G.debt-=v;G.treasury-=v;G.region+=v;recompute();updateHeader();save();renderPanel(active)}
});
$('zoomIn').onclick=()=>{cam.zoom=clamp(cam.zoom*1.22,.26,1.7);dirty=true};$('zoomOut').onclick=()=>{cam.zoom=clamp(cam.zoom/1.22,.26,1.7);dirty=true};$('center').onclick=()=>{cam.x=RW/2;cam.y=RH/2;cam.zoom=.95;dirty=true};$('overlayToggle').onclick=()=>{overlay=overlay==='none'?'roads':overlay==='roads'?'metro':overlay==='metro'?'hardship':overlay==='hardship'?'crime':overlay==='crime'?'business':'none';dirty=true;toast('Map overlay: '+overlay)};
$('pause').onclick=()=>{paused=!paused;updateHeader();if(paused)save()};const SPEED_PRESETS=[1,2,4,8,16,32,64];
$('speed').onclick=()=>{const index=SPEED_PRESETS.indexOf(speed);speed=SPEED_PRESETS[(index+1)%SPEED_PRESETS.length];G.speed=speed;updateHeader()};
$('speedRange').addEventListener('input',e=>{speed=SPEED_PRESETS[+e.target.value]||1;if(G)G.speed=speed;updateHeader();});
$('speedRange').addEventListener('change',()=>{if(G)save();});
function start(newVillage){if(newVillage){seed(Number($('townSeed')?.value)||42)}else if(!load())seed();cam={x:RW/2,y:RH/2,zoom:.95};invalidateRoads();buildMode='';selected=null;overlay='none';paused=false;speed=SPEED_PRESETS.includes(G.speed)?G.speed:1;acc=0;$('welcome').style.display='none';dirty=true;staticDirty=true;updateHeader();openPanel('overview');}
$('newTown').onclick=()=>{start(true);refreshAmbience()};$('continue').onclick=()=>{start(false);refreshAmbience()};
try{if(localStorage.getItem('townledger-v6')||localStorage.getItem('townledger-v6-backup')||localStorage.getItem('townledger-village-founder-3')||localStorage.getItem('townledger-village-civic-2'))$('continue').style.display='block'}catch(e){}
window.addEventListener('resize',fit);fit();
let last=performance.now(),acc=0,lastMapDraw=0;
function frame(now){
 const raw=Math.max(0,(now-last)/1000);last=now;
 if(G&&!paused&&!pendingEvent&&!document.hidden){
  const dt=Math.min(raw,.25),mean=perfStats.ticks.length?perfStats.ticks.reduce((a,b)=>a+b,0)/perfStats.ticks.length:1;
  const sustainable=Math.max(1,1.65*260/Math.max(.1,mean));
  const admission=Math.min(speed,sustainable);acc+=dt*admission;
  const end=performance.now()+5;let completed=0;
  while(acc>=1.65&&(!completed||performance.now()<end)&&!pendingEvent){const t=performance.now();tick();perfStats.ticks.push(performance.now()-t);if(perfStats.ticks.length>180)perfStats.ticks.shift();acc-=1.65;completed++;}
  perfStats.days+=completed;perfStats.elapsed+=dt;perfStats.backlog=acc/1.65;
  perfStats.effective=Math.min(speed,admission);frameClock+=dt;trafficUpdate(dt);dirty=true;
 }else if(document.hidden){last=now;}
 if(G&&dirty&&now-lastMapDraw>=16){const t=performance.now();draw();perfStats.frames.push(performance.now()-t);if(perfStats.frames.length>600)perfStats.frames.shift();lastMapDraw=now;}
 requestAnimationFrame(frame);
}requestAnimationFrame(frame);
window.addEventListener('beforeunload',()=>save());document.addEventListener('visibilitychange',()=>{if(document.hidden){save();last=performance.now();if(ambient)ambient.pause()}else refreshAmbience()});
window.addEventListener('error',e=>{console.error(e.error||e.message);toast('Runtime issue: '+(e.message||'Unknown'))});

// SOURCE: 80-civic.js
// --- Founder's Edition: long-form borough strategy systems and reporting. ---
const AMBITIONS=[
 {id:'resilient_banks',title:'A resilient banking centre',description:'Keep three solvent banks operating, fewer than two business loan defaults, and 75% employment for 50 days.',days:50,goal:g=>g.banks?.filter(b=>!b.closed&&bankEquity(b)>0).length>=3&&g.finance.businessDefaults<2&&g.stats.employment>=75,progress:g=>Math.min(1,(g.banks?.filter(b=>!b.closed).length||0)/3*.6+g.stats.employment/75*.4),reward:6500},
 {id:'balanced',title:'Keep the books',description:'Maintain $60,000 in municipal cash, no debt, and 65% employment for 25 days.',days:25,goal:g=>g.treasury>=60000&&g.debt===0&&g.stats.employment>=65,progress:g=>Math.min(1,(g.treasury/60000)*.65+(g.stats.employment/65)*.35),reward:3500},
 {id:'safe',title:'A safe place to live',description:'Maintain a safety index of 88, with no more than two crimes in 30 days, for 20 days.',days:20,goal:g=>g.stats.safety>=88&&g.stats.dailyCrime<=2,progress:g=>Math.min(1,g.stats.safety/88),reward:3200},
 {id:'market',title:'A thriving market town',description:'Support at least 25 trading businesses and employment above 80% for 25 days.',days:25,goal:g=>g.stats.businesses>=25&&g.stats.employment>=80,progress:g=>Math.min(1,g.stats.businesses/25),reward:5000},
 {id:'families',title:'A town for families',description:'Reduce household hardship under 9% while retaining at least 70 homes for 20 days.',days:20,goal:g=>g.stats.hardship<=9&&g.homes.length>=70,progress:g=>Math.min(1,.5*(1-g.stats.hardship/100)+.5*g.homes.length/70),reward:4800},
 {id:'education',title:'A learned community',description:'Raise schooling to 70 and public health to 80, then sustain both for 20 days.',days:20,goal:g=>g.education>=70&&g.health>=80,progress:g=>Math.min(1,(g.education/70+g.health/80)/2),reward:4200},
 {id:'liberty',title:'A leaner tax regime',description:'Maintain income tax at 5% or less, employment at 75%+, and a $25,000 reserve for 25 days.',days:25,goal:g=>g.policy.incomeTax<=5&&g.stats.employment>=75&&g.treasury>=25000,progress:g=>Math.min(1,.5*g.stats.employment/75+.5*g.treasury/25000),reward:4000},
 {id:'resilience',title:'Ready for hard times',description:'Raise emergency readiness to 80+, fund a second fire brigade, and sustain it 20 days.',days:20,goal:g=>g.stats.preparedness>=80&&g.buildings.filter(b=>b.kind==='fire').length>=2,progress:g=>Math.min(1,g.stats.preparedness/80),reward:4000},
 {id:'boom',title:'An ambitious borough',description:'Bring 300 residents into the town without losing employment below 70% for 25 days.',days:25,goal:g=>g.people.length>=300&&g.stats.employment>=70,progress:g=>Math.min(1,g.people.length/300),reward:6500},
 {id:'reputation',title:'An enduring mandate',description:'Earn 78% council approval, with a safety index of 75, for 30 days.',days:30,goal:g=>g.council.approval>=78&&g.stats.safety>=75,progress:g=>Math.min(1,g.council.approval/78),reward:5000}
];
const COUNCIL_EVENTS=[
 {title:'A petition from the shopkeepers',type:'COMMERCE & TRADE',text:'Local merchants say rising delivery expenses are eating their margins. They ask for temporary help, while residents want prices kept down.',choices:[
  {title:'Finance a local delivery cooperative',desc:'Pay $2,200. Deliver working capital to nearby firms.',cost:2200,apply:()=>{let list=G.firms.filter(f=>!f.closed);let n=Math.min(8,list.length);for(let f of list.slice(0,n))f.cash+=2200/n;G.council.factions.merchants+=4;}},
  {title:'Simplify commercial licences',desc:'Reduce the permit fee by $200; sacrifice possible permit revenue.',apply:()=>{G.policy.permitFee=Math.max(0,G.policy.permitFee-200);G.council.factions.merchants+=3}},
  {title:'Leave prices and freight to the market',desc:'No expenditure. Merchants remain responsible for their costs.',apply:()=>{G.council.factions.merchants-=2}}
 ]},
 {title:'The bridge needs repairs',type:'PUBLIC WORKS',text:'The stone bridge carrying traffic to the northern quarter has begun to crack. Engineers advise action before winter.',choices:[
  {title:'Repair it properly',desc:'Pay $3,000. Better trade access and road reliability.',cost:3000,apply:()=>{G.policy.roadBudget=Math.min(250,G.policy.roadBudget+10);G.council.factions.public+=3}},
  {title:'Authorize urgent patchwork',desc:'Pay $900. A partial, temporary improvement.',cost:900,apply:()=>{G.council.factions.public+=1}},
  {title:'Postpone repairs',desc:'No cost now. Residents question council priorities.',apply:()=>{G.council.factions.public-=5;G.unrest+=2}}
 ]},
 {title:'Families facing eviction',type:'HOUSING & WELFARE',text:'A local charity reports several working households have fallen behind on rent. It asks the council to contribute to an emergency relief fund.',choices:[
  {title:'Fund a relief programme',desc:'Transfer $2,400 directly to the poorest households.',cost:2400,apply:()=>{let h=G.households.slice().sort((a,b)=>a.cash-b.cash).slice(0,12);for(let p of h){p.cash+=200;p.stress=Math.max(0,p.stress-5);}G.council.factions.workers+=4}},
  {title:'Make relief conditional on training',desc:'Spend $1,300 on work placement and training.',cost:1300,apply:()=>{G.education+=2;G.council.factions.workers+=2}},
  {title:'Refer households to private charity',desc:'No budget impact. Increased dissatisfaction among poorer households.',apply:()=>{G.council.factions.workers-=4}}
 ]},
 {title:'A merchant wants to expand',type:'PRIVATE INVESTMENT',text:'A local trader has identified a vacant premises. They can open another shop if planning permission and capital are secured.',choices:[
  {title:'Offer a development grant',desc:'Pay $2,000 in startup capital and promote private entry.',cost:2000,apply:()=>{let f=G.firms.filter(f=>f.closed)[0];if(f){f.closed=false;f.cash+=5500;f.strain=0;assignJobs();}else{let f=pick(G.firms);if(f)f.cash+=2000;}G.council.factions.merchants+=3}},
  {title:'Waive the entry fee for a year',desc:'Reduce new-entry permit charges to $0.',apply:()=>{G.policy.permitFee=0;G.council.factions.merchants+=3}},
  {title:'Decline special favours',desc:'The standard planning and licensing system remains in force.',apply:()=>{G.council.factions.merchants-=1}}
 ]},
 {title:'Illness spreads at the school',type:'PUBLIC HEALTH',text:'A seasonal respiratory illness is circulating. The clinic says it can reduce disruption if a temporary programme is funded.',choices:[
  {title:'Provide treatment and preventive supplies',desc:'Spend $1,800. Improves town health and reduces household stress.',cost:1800,apply:()=>{G.health=Math.min(100,G.health+5);for(const h of G.households)h.stress=Math.max(0,h.stress-.6)}},
  {title:'Ask employers to adopt voluntary precautions',desc:'No direct cost. Modest public health gains.',apply:()=>{G.health=Math.min(100,G.health+1)}},
  {title:'Take no action',desc:'The illness is allowed to run its course.',apply:()=>{G.health=Math.max(20,G.health-3);G.council.factions.public-=2}}
 ]},
 {title:'The industrial safety dispute',type:'WORKING CONDITIONS',text:'Workers at the sawmill say basic precautions have been neglected. Employers warn that more inspection rules will raise costs.',choices:[
  {title:'Increase workplace inspections',desc:'Raise business regulation by 15 points.',apply:()=>{G.policy.businessRegulation=Math.min(100,G.policy.businessRegulation+15);G.council.factions.workers+=3;G.council.factions.merchants-=2}},
  {title:'Co-finance safety improvements',desc:'Spend $1,500 on protective equipment for firms.',cost:1500,apply:()=>{G.health+=2;G.council.factions.workers+=2;G.council.factions.merchants+=2}},
  {title:'Leave the matter to individual employers',desc:'No spending or new regulatory obligations.',apply:()=>{G.council.factions.workers-=3;G.council.factions.merchants+=2}}
 ]},
 {title:'A dry summer threatens the farms',type:'AGRICULTURE',text:'Farmers report that irrigation ditches are running low. Crop yields and exports may decline unless the borough acts.',choices:[
  {title:'Build emergency irrigation channels',desc:'Spend $2,800; support farm production capacity.',cost:2800,apply:()=>{G.firms.filter(f=>f.kind==='farm'&&!f.closed).forEach(f=>{f.stock.grain+=80;f.cash+=150;});G.council.factions.merchants+=2}},
  {title:'Provide a small farmer loan',desc:'Advance $1,000 to local farms.',cost:1000,apply:()=>{G.firms.filter(f=>f.kind==='farm'&&!f.closed).slice(0,5).forEach(f=>f.cash+=200)}},
  {title:'Allow farms to adapt privately',desc:'No expense, but traders face reduced near-term output.',apply:()=>{G.firms.filter(f=>f.kind==='farm'&&!f.closed).forEach(f=>f.stock.grain=Math.max(0,f.stock.grain-50))}}
 ]},
 {title:'The night watch requests support',type:'CRIME & SECURITY',text:'The constabulary reports a rise in burglary attempts in outlying lanes. Officers request more staff and lighting.',choices:[
  {title:'Raise daily patrol funding',desc:'Increase constabulary expenditure by $40 per day.',apply:()=>{G.policy.policeBudget=Math.min(800,G.policy.policeBudget+40);G.council.factions.public+=2}},
  {title:'Fund a one-time neighbourhood programme',desc:'Spend $1,300; support vulnerable households.',cost:1300,apply:()=>{G.households.filter(h=>h.security<65).forEach(h=>h.security+=8);G.council.factions.public+=2}},
  {title:'Maintain the existing patrols',desc:'No new expense.',apply:()=>{G.council.factions.public-=1}}
 ]},
 {title:'A new regional trade agreement',type:'COMMERCE & TRADE',text:'Regional merchants offer stable supplies of grain and timber. In return, they request lower import charges.',choices:[
  {title:'Sign a free-trade agreement',desc:'Remove import tariffs and allow unrestricted regional trade.',apply:()=>{G.policy.importTariff=0;G.policy.imports=true;G.council.factions.merchants+=4}},
  {title:'Negotiate a lower tariff',desc:'Cut the current tariff rate in half.',apply:()=>{G.policy.importTariff=Math.floor(G.policy.importTariff/2);G.council.factions.merchants+=2}},
  {title:'Keep the present trading arrangements',desc:'No immediate policy change.',apply:()=>{}}
 ]},
 {title:'Flooding on the low road',type:'CIVIL DEFENCE',text:'Heavy rain has washed out culverts on the east side. Some properties face water damage if repairs are delayed.',choices:[
  {title:'Mobilize the fire brigade and volunteers',desc:'Spend $2,700. Protect homes and restore access.',cost:2700,apply:()=>{G.crisesHandled++;G.council.factions.public+=3}},
  {title:'Organize local volunteer crews',desc:'Spend $650. Partial protection.',cost:650,apply:()=>{G.crisesHandled++;G.health=Math.max(0,G.health-1)}},
  {title:'Leave residents to arrange private repairs',desc:'No municipal expense; some households suffer damage.',apply:()=>{G.households.slice(0,8).forEach(h=>{let p=Math.min(h.cash,170);h.cash-=p;G.region+=p;h.stress+=3;});G.council.factions.public-=3}}
 ]},
 {title:'The apprentices ask for a school',type:'EDUCATION & EMPLOYMENT',text:'Young workers say the town needs formal training if local firms are to compete with regional employers.',choices:[
  {title:'Establish an apprenticeship fund',desc:'Spend $1,600, increasing vocational skill.',cost:1600,apply:()=>{G.education=Math.min(100,G.education+5);G.council.factions.workers+=3}},
  {title:'Ask businesses to organize training',desc:'No municipal expenditure. Small productivity improvement.',apply:()=>{G.education=Math.min(100,G.education+1);G.council.factions.merchants+=2}},
  {title:'Maintain current schooling',desc:'No change.',apply:()=>{G.council.factions.workers-=1}}
 ]},
 {title:'Council must address the deficit',type:'THE PUBLIC PURSE',text:'The treasurer warns that current services may become unaffordable if reserves continue to decline.',choices:[
  {title:'Reduce non-essential daily programmes',desc:'Cut administrative, outreach and road spending.',apply:()=>{G.policy.outreachBudget=Math.max(0,G.policy.outreachBudget-20);G.policy.roadBudget=Math.max(0,G.policy.roadBudget-10);G.policy.educationBudget=Math.max(0,G.policy.educationBudget-20);G.council.factions.public-=3}},
  {title:'Increase the income-tax rate',desc:'Raise income tax by 3 percentage points.',apply:()=>{G.policy.incomeTax=Math.min(40,G.policy.incomeTax+3);G.council.factions.workers-=3}},
  {title:'Raise an emergency municipal loan',desc:'Borrow $7,000 with interest due.',apply:()=>{G.debt+=7000;G.treasury+=7000;G.region-=7000}}
 ]}
];
// Additional town stories: each decision affects actual funds, people, local firms or policy rules.
COUNCIL_EVENTS.push(
 {title:'The bakers face a flour shortage',type:'FOOD SUPPLY',text:'The local bakery guild cannot obtain sufficient flour at current prices. Families are already paying more for basic bread.',choices:[
  {title:'Buy emergency supplies',desc:'Pay $1,800 to restock bakeries and reduce immediate shortages.',cost:1800,apply:()=>{G.firms.filter(f=>f.kind==='bakery'&&!f.closed).slice(0,4).forEach(f=>{f.stock.flour=(f.stock.flour||0)+120;f.cash+=150;});G.council.factions.workers+=2}},
  {title:'Ease grain import duties',desc:'Remove import tariffs to lower suppliers’ input costs.',apply:()=>{G.policy.importTariff=0;G.policy.imports=true;G.council.factions.merchants+=2}},
  {title:'Keep the market free of intervention',desc:'No public expense; food prices may remain elevated.',apply:()=>{G.council.factions.workers-=2}}
 ]},
 {title:'Petition for fair wages',type:'WORK & INCOME',text:'A group of poorly paid employees wants the council to mandate higher wages. Shopkeepers say their margins are already thin.',choices:[
  {title:'Raise the daily wage floor by $5',desc:'Employers must meet a higher payroll; workers may gain more income.',apply:()=>{G.policy.minWage=Math.min(90,G.policy.minWage+5);G.council.factions.workers+=3;G.council.factions.merchants-=2}},
  {title:'Subsidize employment instead',desc:'Pay employers an extra $2 per working resident each day.',apply:()=>{G.policy.employmentSubsidy=Math.min(15,G.policy.employmentSubsidy+2);G.council.factions.merchants+=2;G.council.factions.workers+=2}},
  {title:'Keep wages privately negotiated',desc:'Make no new employment rule.',apply:()=>{G.council.factions.workers-=2}}
 ]},
 {title:'The housing shortage petition',type:'HOUSING & PLANNING',text:'Young households say they cannot find affordable houses near the square. Established property owners oppose building on the village outskirts.',choices:[
  {title:'Open new residential land',desc:'Reduce zoning restrictions by 20 points to allow private housebuilding.',apply:()=>{G.policy.zoningRestriction=Math.max(0,G.policy.zoningRestriction-20);G.council.factions.homeowners-=2;G.council.factions.workers+=3}},
  {title:'Finance new municipal cottages',desc:'Pay $3,000 into a housing programme for families in hardship.',cost:3000,apply:()=>{G.households.slice().sort((a,b)=>a.cash-b.cash).slice(0,10).forEach(h=>{h.cash+=300;h.stress=clamp(h.stress-5,0,100)});G.council.factions.workers+=3}},
  {title:'Preserve the current neighbourhood plans',desc:'Leave building restrictions in place.',apply:()=>{G.council.factions.homeowners+=2;G.council.factions.workers-=2}}
 ]},
 {title:'A theft at the market square',type:'LAW & ORDER',text:'Several stallholders report stolen cash, and residents accuse the watch of ignoring repeated warnings.',choices:[
  {title:'Fund a targeted investigation',desc:'Spend $1,400 on detectives and restitution for the affected traders.',cost:1400,apply:()=>{G.firms.filter(f=>!f.closed).slice(0,7).forEach(f=>f.cash+=200);G.council.factions.public+=3}},
  {title:'Build a stronger night watch',desc:'Raise ongoing police funding by $30 per day.',apply:()=>{G.policy.policeBudget=Math.min(800,G.policy.policeBudget+30);G.council.factions.public+=2}},
  {title:'Ask stallholders to hire their own guards',desc:'No public expense; private traders bear the burden.',apply:()=>{G.council.factions.merchants-=2}}
 ]},
 {title:'Refugees from the flooded valley',type:'MIGRATION & COMMUNITY',text:'Families displaced by a flood in a neighbouring district are asking to settle in the town. The school and grocers expect extra demand.',choices:[
  {title:'Open a municipal resettlement fund',desc:'Spend $2,000 supporting the lowest-cash families and social integration.',cost:2000,apply:()=>{G.households.slice().sort((a,b)=>a.cash-b.cash).slice(0,10).forEach(h=>{h.cash+=200;h.stress=clamp(h.stress-2,0,100)});G.council.factions.public+=3}},
  {title:'Allow private sponsors to assist arrivals',desc:'No municipal funding; remove some housing restrictions.',apply:()=>{G.policy.zoningRestriction=Math.max(0,G.policy.zoningRestriction-10);G.council.factions.merchants+=2}},
  {title:'Defer new settlement until homes are built',desc:'No immediate housing pressure or public spending.',apply:()=>{G.council.factions.public-=2}}
 ]},
 {title:'An old mine could reopen',type:'JOBS & NATURAL RESOURCES',text:'A regional operator wants to restart an abandoned quarry. It could create jobs, but nearby residents worry about dust and road wear.',choices:[
  {title:'Offer a conditional investment grant',desc:'Pay $1,600 to boost the quarry’s capital and maintain safety standards.',cost:1600,apply:()=>{const f=G.firms.find(f=>f.kind==='quarry');if(f){f.cash+=1600;f.strain=Math.max(0,f.strain-10);if(f.closed){f.closed=false;assignJobs()}}G.council.factions.merchants+=2}},
  {title:'Permit reopening under stricter safeguards',desc:'Raise inspection standards by 10 points.',apply:()=>{G.policy.businessRegulation=Math.min(100,G.policy.businessRegulation+10);G.council.factions.homeowners+=3}},
  {title:'Do not subsidize a private enterprise',desc:'No public expenditure or special permission.',apply:()=>{G.council.factions.merchants-=1}}
 ]},
 {title:'The volunteer brigade wants equipment',type:'CIVIL DEFENCE',text:'The local volunteer corps warns that the next major storm could overwhelm the existing fire brigade.',choices:[
  {title:'Buy new equipment',desc:'Spend $2,100 on storm preparedness and local protective supplies.',cost:2100,apply:()=>{G.policy.defenseBudget=Math.min(800,G.policy.defenseBudget+20);G.crisesHandled++;G.council.factions.public+=3}},
  {title:'Expand volunteer training',desc:'Increase volunteer funding by $35 per day.',apply:()=>{G.policy.militiaBudget=Math.min(400,G.policy.militiaBudget+35);G.council.factions.public+=2}},
  {title:'Rely on mutual aid from neighbouring towns',desc:'No extra town spending; coverage remains uncertain.',apply:()=>{G.council.factions.public-=2}}
 ]},
 {title:'The grocers dispute inspection fees',type:'SMALL BUSINESS',text:'Several family-owned shops are paying more for paperwork and inspections than expected. Residents also want food safety enforced.',choices:[
  {title:'Simplify the inspection rules',desc:'Lower business regulation by 15 points, reducing operating compliance costs.',apply:()=>{G.policy.businessRegulation=Math.max(0,G.policy.businessRegulation-15);G.council.factions.merchants+=4}},
  {title:'Help small shops modernize',desc:'Spend $1,800 on better storage equipment and food safety.',cost:1800,apply:()=>{G.firms.filter(f=>f.kind==='grocer'&&!f.closed).slice(0,6).forEach(f=>{f.cash+=300;f.stock.food=(f.stock.food||0)+20});G.council.factions.public+=2}},
  {title:'Keep current safeguards and fees',desc:'No change to local regulatory standards.',apply:()=>{G.council.factions.public+=1;G.council.factions.merchants-=2}}
 ]}
);


function setupScenario(){
 if(chosenScenario==='hardtimes'){
   G.region+=G.treasury-16000;G.treasury=16000;G.debt=9000;G.treasury+=9000;G.region-=9000;for(const f of G.firms.filter(f=>f.kind==='farm'||f.kind==='sawmill')){let old=f.cash;f.cash*=.22;G.region+=old-f.cash;f.strain=34;}for(const h of G.households.slice(0,26)){let old=h.cash;h.cash*=.15;G.region+=old-h.cash;h.stress+=25}G.policy.incomeTax=19;G.policy.profitTax=26;G.policy.zoningRestriction=55;G.regionalDemand=.55;G.council.approval=41;G.council.factions.workers=39;G.scenario='hardtimes';story('The borough faces layoffs, debt and a strained treasury.','bad');
 }else if(chosenScenario==='frontier'){
   G.region+=G.treasury-43000;G.treasury=43000;G.policy.incomeTax=6;G.policy.profitTax=7;G.policy.policeBudget=90;G.policy.defenseBudget=60;G.policy.educationBudget=40;G.policy.healthBudget=35;G.policy.aidBudget=40;G.scenario='frontier';
   for(const f of G.firms.slice(10)){f.closed=true;for(let id of f.workers)if(G.people[id])G.people[id].job=-1;f.workers=[];}G.council.approval=69;story('A small frontier council inherits open land and a lean budget.','neutral');
 }else if(chosenScenario==='industrial'){
   G.region+=G.treasury-68000;G.treasury=68000;G.policy.profitTax=5;G.policy.incomeTax=15;G.policy.permitFee=0;G.policy.businessRegulation=40;G.policy.minWage=34;G.policy.educationBudget=130;G.scenario='industrial';
   for(const f of G.firms){f.cash+=2500;G.region-=2500}G.council.approval=58;story('Industrial investment is rising, but employers and workers disagree over wages and regulation.','neutral');
 }else{G.scenario='settlement';story('The council inherits a promising community and a difficult balancing act.','good');}
 recompute();
}
function fundLocalService(amount){let paid=Math.min(G.treasury,amount);G.treasury-=paid;G.cumulative.spending+=paid;let staff=paid*.42;let recipients=G.households.filter(h=>h.people.some(id=>!G.people[id]?.deceased&&G.people[id]?.movedAway!==true&&G.people[id]?.job===-1));if(!recipients.length)recipients=G.households;const n=Math.min(recipients.length,Math.max(1,Math.floor(paid/22)));if(n)for(let i=0;i<n;i++){let h=recipients[(i*13+G.day)%recipients.length];h.cash+=staff/n;h.income+=staff/n}G.region+=paid-staff;return amount>0?paid/amount:0}
function extendedCivicDay(){
 let P=G.policy;
 let clinic=G.buildings.filter(b=>b.kind==='clinic').length,parks=G.buildings.filter(b=>b.kind==='park'||b.kind==='square').length,schools=G.buildings.filter(b=>b.kind==='school').length,watch=G.buildings.filter(b=>b.kind==='watchtower').length;
 const healthRatio=fundLocalService(P.healthBudget||0)*Math.min(1,clinic*350/Math.max(1,G.stats.population)),schoolRatio=fundLocalService(P.educationBudget||0)*Math.min(1,schools*260/Math.max(1,G.stats.population)),roadRatio=fundLocalService(P.roadBudget||0),militiaRatio=fundLocalService(P.militiaBudget||0),transitRatio=fundLocalService(P.transitBudget||0);
 G.actualServiceFunding=Object.assign(G.actualServiceFunding||{},{roads:roadRatio,health:healthRatio,school:schoolRatio,militia:militiaRatio,transit:transitRatio});
 G.health=clamp(G.health+(.021*(clinic+healthRatio*2)-.037- (G.stats.hardship||0)*.0002),25,99);
 G.education=clamp(G.education+.02*(schoolRatio*2)*(1+schools*.2)-.009,15,99);
 G.stats.health=Math.round(G.health);G.stats.education=Math.round(G.education);
 if(G.day%3===0&&schoolRatio>.4){let p=pick(G.people.filter(p=>!p.deceased&&p.movedAway!==true));if(p){p.skill=clamp(p.skill+.018*schoolRatio,0,1.3)}}
 if(G.day%6===0){let p=pick(G.people.filter(p=>!p.deceased&&p.movedAway!==true));if(p){p.health=clamp(p.health+(healthRatio>.5?1.3:-.3)+rn(-.5,.5),10,100);if(p.health<25){const h=G.households[p.hh];if(h)h.stress=clamp(h.stress+1,0,100)}}}
 if(G.day%8===0&&parks>0){let h=pick(G.households);if(h)h.stress=clamp(h.stress-1.5,0,100)}
 const warmth=G.weather==='storm'?-.4:0;
 G.stats.wellbeing=Math.round(clamp(82-G.households.reduce((s,h)=>s+h.stress,0)/Math.max(1,G.households.length)*.46+parks*.5+G.health*.08+warmth,0,100));
 G.stats.avgCash=G.stats.cash/Math.max(1,G.households.length);
 G.stats.compliance=P.businessRegulation;
 G.stats.marketConfidence=Math.round(clamp(77-G.stats.unemployment*.5-G.stats.hardship*.48-P.profitTax*.23-P.permitFee*.005+Math.max(0,15-P.importTariff)*.12+parks*.3+(G.regionalDemand-1)*20,5,99));
 G.stats.propertyCosts=(2.15+P.zoningRestriction*.035);
 G.stats.realWages=Math.round(G.households.reduce((s,h)=>s+h.income-h.tax-h.rent-h.food,0)/Math.max(1,G.stats.population)*10)/10;
 G.stats.prosperity=Math.round(clamp(G.stats.employment*.5+G.stats.marketConfidence*.3+G.stats.wellbeing*.2,0,100));
 G.stats.roadService=Math.round(clamp((G.stats.roadCondition??75)*.65+roadRatio*23+transitRatio*12,0,100));
 G.stats.militia=Math.round(clamp(25+militiaRatio*40+(G.policy.militiaBudget||0)/30+watch*12,0,100));
}
function updateCouncilAndMissions(){
 const C=G.council,P=G.policy,s=G.stats;
 if(G.day%4===0){
  const worker=clamp(20+s.employment*.45-s.hardship*.75+Math.min(P.aidBudget,250)*.024-P.foodTax*.60-P.incomeTax*.30+s.wellbeing*.06,5,98);
  const merchant=clamp(36+s.marketConfidence*.22+s.employment*.20-P.profitTax*.40-P.businessRegulation*.12-P.permitFee*.008,5,98);
  const homeowner=clamp(38+s.safety*.30+s.employment*.10-P.propertyTax*6-P.zoningRestriction*.12+Math.min(16,s.wellbeing*.08),5,98);
  const publicv=clamp(17+s.safety*.40+s.wellbeing*.30+s.health*.1-Math.min(25,Math.max(0,G.debt-G.treasury)/4500),5,98);
  for(const [k,v] of Object.entries({workers:worker,merchants:merchant,homeowners:homeowner,public:publicv}))C.factions[k]=clamp(C.factions[k]*.88+v*.12,0,100);
  const avg=.31*C.factions.workers+.25*C.factions.merchants+.2*C.factions.homeowners+.24*C.factions.public;
  C.approval=clamp(C.approval*.85+avg*.15,5,97);
 }
 G.stats.approval=Math.round(C.approval);
 for(const m of AMBITIONS){if(G.achievements.includes(m.id))continue;let n=G.ambitionDays[m.id]||0;G.ambitionDays[m.id]=m.goal(G)?n+1:0;
  if(G.ambitionDays[m.id]>=m.days){G.achievements.push(m.id);let bonus=Math.min(m.reward,G.region*.5);G.treasury+=bonus;G.region-=bonus;G.council.approval=clamp(G.council.approval+3,0,100);story('AMBITION ACHIEVED: '+m.title+'. Regional development grant '+money(bonus)+'.','good');if(speed<=8)toast('Ambition complete: '+m.title+'!');save();}}
}
function privateInvestmentAndHousing(){
 // Expansion is paid for out of retained earnings. Jobs and wages respond to profits.
 let vacancies=G.people.filter(p=>!p.deceased&&p.movedAway!==true&&p.age>=16&&p.age<=70&&p.job<0).length;
 for(const f of G.firms){if(f.closed)continue;
  if(f.profit< -28&&f.cash<4800&&f.workers.length>2&&f.jobs>3){
    const released=f.workers.pop();if(G.people[released])G.people[released].job=-1;
    f.jobs=Math.max(3,f.jobs-1);f.strain=Math.max(0,f.strain-2);
    if(G.day%90===0)story(f.name+' reduced payroll after weak sales instead of immediately closing.','neutral',f.building);
  }
  if(f.cash>17000&&f.profit>55&&f.jobs<14&&vacancies>0&&random()<.18){f.cash-=1800;G.region+=1800;f.jobs++;vacancies--;story(f.name+' reinvested in equipment and advertised a new job.','good',f.building)}
  if(f.profit>90&&f.cash>19000&&random()<.2)f.wage=Math.min(90,f.wage+.65);
  if(f.kind==='grocer'){let inventory=f.stock.food||0;let drift=inventory<20?.13:inventory>220?-.10:0;f.price=clamp(f.price+drift,marketPrice('food')*1.2+f.wage*f.workers.length/Math.max(40,G.stats.population*1.6/Math.max(1,G.firms.filter(s=>s.kind==='grocer'&&!s.closed).length)),12.5)}
 }
 let pressure=G.stats.population/Math.max(1,G.homes.length*2.5);
 for(const b of G.buildings){if(b.kind!=='home')continue;const P=G.policy;
  let delta=clamp((pressure-1)*.007+P.zoningRestriction*.00007-P.propertyTax*.0004,-.02,.018);
  b.value=clamp(b.value*(1+delta),15000,220000);
  let owner=G.households[b.owner];if(owner&&owner.cash>3000&&b.condition<85&&random()<.18){let cost=Math.min(owner.cash*.04,650);owner.cash-=cost;G.region+=cost;b.condition=clamp(b.condition+cost/90,0,100)}
 }
 assignJobs();
}
function monthlyReview(){
 // External demand periodically contracts. Recovery is gradual; policy affects resilience through firm cash, taxes and trade.
 G.regionalDemand=clamp((G.regionalDemand||1)*.90+0.10+rn(-.035,.035),.42,1.22);
 if(G.day%180===0&&random()<.33){G.regionalDemand=clamp(G.regionalDemand-rn(.17,.34),.42,1.22);story('Regional buyers cut orders. Local mills, farms and shops brace for a trade slowdown.','bad');}
 const seasonal=G.month>=10||G.month<=2?['clear','clear','rain','storm']:G.month>=6&&G.month<=8?['clear','clear','clear','drought','rain']:['clear','clear','rain','rain','storm'];
 G.weather=pick(seasonal);refreshAmbience();staticDirty=true;if(G.weather==='storm')story('Heavy rain and high winds are expected; fire and civil defence are on alert.','neutral');if(G.weather==='drought')story('A dry spell threatens harvest yields and local food output.','bad');
 if(random()<.22*(1-G.stats.militia/115)){let f=pick(G.firms.filter(f=>!f.closed&&f.cash>100));if(f){let stolen=Math.min(f.cash,rn(100,650));f.cash-=stolen;f.theft+=stolen;G.region+=stolen;G.council.factions.public=clamp(G.council.factions.public-2,0,100);story('A bandit raid targeted '+f.name+'; '+money(stolen)+' was stolen.','bad',f.building);}}
 let r={...G.stats,day:G.day,cash:G.treasury};G.lastMonth=r;
 if(G.treasury<5000){story('Treasurer warns: the council has less than $5,000 of uncommitted funds.','bad');}
 else if(G.stats.unemployment>30){story('Joblessness is above 30%; families are requesting employment assistance.','bad');}
 else if(G.stats.hardship<6&&G.stats.employment>75){story('The borough records a month of relatively steady work and low hardship.','good');}
 if(G.month===12)story('Year-end statements have been filed at the town hall.','neutral');
}
function electionReview(){
 G.council.elections++;let approved=G.council.approval>=50;const stamp='Year '+G.year+' election: '+(approved?'Council retains public confidence':'Council loses majority support')+' ('+Math.round(G.council.approval)+'% approval).';story(stamp,approved?'good':'bad');G.journal.push({day:G.day,name:'Municipal election',message:stamp,baseline:{...G.stats,treasury:G.treasury}});
 // Elections enter the permanent journal without interrupting unattended simulation.
 if(active==='agenda'||active==='journal')renderPanel(active);
}
function offerCouncilEvent(interrupt=false){
 // Ordinary correspondence belongs in the agenda, not in a blocking modal.
 // It is deliberately safe at 64×: the simulation never waits for a reply.
 let recent=G.recentCouncilEvents||[],pool=COUNCIL_EVENTS.filter(e=>!recent.includes(e.title));
 if(!pool.length)pool=COUNCIL_EVENTS;
 let event=pick(pool);G.recentCouncilEvents=recent.concat(event.title).slice(-6);G.lastEventDay=G.day;
 if(interrupt){showCustomEvent(event.type,event.title,event.text,event.choices);return;}
 G.councilInbox=Array.isArray(G.councilInbox)?G.councilInbox:[];
 G.councilInbox.unshift({title:event.title,day:G.day});
 G.councilInbox=G.councilInbox.slice(0,7);
 story('A council petition is waiting: '+event.title+'. Review it in the Agenda when convenient.','neutral');
}
function reviewCouncilInbox(index){
 const inbox=G.councilInbox||[],entry=inbox[index];if(!entry)return;
 const found=COUNCIL_EVENTS.find(e=>e.title===entry.title);
 inbox.splice(index,1);
 if(found)showCustomEvent(found.type,found.title,found.text,found.choices);
 else story('An archived council petition is no longer actionable.','neutral');
 save();if(active==='agenda')renderPanel('agenda');
}

function showCustomEvent(type,title,text,choices){pendingEvent={type,title,text,choices};
 $('eventEyebrow').textContent=type;$('eventTitle').textContent=title;$('eventText').textContent=text;
 $('eventChoices').innerHTML=choices.map((c,i)=>`<button data-event-choice="${i}" ${c.cost&&G.treasury<c.cost?'disabled':''}><strong>${esc(c.title)}</strong><small>${esc(c.desc||'')}${c.cost?' · Cost: '+money(c.cost):''}</small></button>`).join('');
 $('eventDialog').style.display='flex';
}
$('eventChoices').addEventListener('click',e=>{
 const b=e.target.closest('button[data-event-choice]');if(!b||!pendingEvent)return;
 const evt=pendingEvent,c=evt.choices[+b.dataset.eventChoice];if(!c)return;
 if(evt.type==='TOWN ARCHIVE'){pendingEvent=null;$('eventDialog').style.display='none';c.apply();return;}
 const goodsBefore=stockTotals();const fundsBefore=totalMoney();if(c.cost){if(G.treasury<c.cost)return;G.treasury-=c.cost;G.region+=c.cost;G.cumulative.spending+=c.cost;}
 try{c.apply()}catch(ex){console.error('Council decision',ex)}
 const goodsAfter=stockTotals();for(const k of Object.keys(goods)){const delta=goodsAfter[k]-goodsBefore[k];goodsEntry(k,delta>=0?'imports':'consumed',Math.abs(delta));}
 const regionalFunding=totalMoney()-fundsBefore;G.region-=regionalFunding;if(Math.abs(regionalFunding)>.001)book(regionalFunding>0?'Regional capital':'Council settlement',regionalFunding>0?'Council decision beneficiaries':'Regional capital',Math.abs(regionalFunding),'Explicit council programme settlement');
 G.journal.push({day:G.day,name:evt.title,message:c.title+'. '+(c.desc||''),baseline:{...G.stats,treasury:G.treasury}});
 story('COUNCIL DECISION: '+c.title+' — '+evt.title,'neutral');pendingEvent=null;$('eventDialog').style.display='none';recompute();updateHeader();if(active)renderPanel(active);save();dirty=true;
});
function totalMoney(){return G.treasury+G.region+(G.investors||[]).reduce((n,a)=>n+a.cash,0)+(G.metro?.cash||0)+(G.banks||[]).reduce((n,b)=>n+b.cash,0)+G.households.reduce((n,h)=>n+h.cash,0)+G.firms.reduce((n,f)=>n+f.cash,0)}
function investigateCases(){if(G.day%5!==0)return;const power=policePower();for(const item of G.cases.slice(0,30)){if(item.resolved||item.offender==null||item.loss<=0||G.day-item.day<3)continue;let age=G.day-item.day;if(age>50){item.resolved='cold';continue;}if(random()<(.025+power*.14)){let offender=G.households[item.offender];let victim=item.hid>=0?G.households[item.hid]:(G.firms[readBuild(item.bid)?.firm]);if(offender&&victim){let recovered=Math.min(offender.cash,item.loss*(.30+power*.45));if(recovered>0){offender.cash-=recovered;victim.cash+=recovered;}item.recovered=Math.round(recovered);item.resolved=true;story('Constabulary concluded an investigation; '+money(recovered)+' was recovered for the victim.','good',item.bid,item.hid);}}}}
function yearlyDemographics(){
 let deaths=0;
 for(const p of G.people){
  if(p.deceased||p.movedAway)continue;p.age++;
  if(p.age>85&&(p.age>95||random()<.17)){
   p.deceased=true;p.job=-1;
   const h=G.households[p.hh];if(h)h.people=h.people.filter(id=>id!==p.id);
   for(const f of G.firms)f.workers=f.workers.filter(id=>id!==p.id);
   deaths++;
  }
 }
 if(deaths)story(deaths+' elderly residents passed away this year. Their families will remember them.','neutral');
 // Vacant homes can receive a new household from outside town. Do not clone
 // an existing resident into two household rosters, and keep external cash balanced.
 for(const h of G.households){
  if(h.people.length||!readBuild(h.home)||G.stats.population>=2000||G.region<1000||cityDemand().housingPressure<48)continue;
  const building=readBuild(h.home),newHousehold=addHouseholdAt(building,900);
  if(newHousehold){if(building.hh===h.id)building.hh=newHousehold.id;if(Array.isArray(building.units))building.units=building.units.map(id=>id===h.id?newHousehold.id:id);h.home=-1;story('A newcomer household rented an empty home; the former estate retains its balances and title.','neutral',building.id,newHousehold.id);}

 }
 assignJobs();
}

function updateObjectiveMini(){if(!G)return;let m=AMBITIONS.find(m=>m.id===G.ambition)||AMBITIONS[0],days=G.ambitionDays[m.id]||0,p=m.progress(G);
 if(G.achievements.includes(m.id))p=1;else if(m.goal(G))p=Math.min(1,days/m.days);
 $('objectiveName').textContent=m.title;$('objectiveProgress').style.width=(100*clamp(p,0,1))+'%';
 const h=G.events[0];if(h){$('headline').textContent=h.text;}
 if(G.roadMetrics&&G.roadMetrics.connectedFirms<G.roadMetrics.totalFirms){$('headline').textContent='Road access warning: '+(G.roadMetrics.totalFirms-G.roadMetrics.connectedFirms)+' local businesses are cut off from town freight.';}
}

// SOURCE: 90-archive-panels.js
function hydrateSave(raw){
 const previousTown=G;
 try{const data=typeof raw==='string'?JSON.parse(raw):raw;
  if(!data||![2,3].includes(data.version)||!Array.isArray(data.tiles)||data.tiles.length!==T*T||!Array.isArray(data.firms)||!Array.isArray(data.people)||!Array.isArray(data.buildings)||!Array.isArray(data.households)||!data.policy||!Number.isFinite(data.treasury)||data.tiles.some(t=>!Number.isInteger(t)||t<0||t>3)||!Number.isFinite(data.region)||data.region<0||data.households.length>3000||data.people.length>8000||data.firms.length>3000)return false;
  if(data.schema!=null&&(!Number.isInteger(data.schema)||data.schema>4))return false;
  if(data.investors&&(!Array.isArray(data.investors)||data.investors.length!==1||data.investors.some(a=>!Number.isFinite(a.cash)||a.cash<0)))return false;
  if(data.freight&&(!Array.isArray(data.freight)||data.freight.length>10000||data.freight.some(s=>!Number.isInteger(s.from)||!data.firms[s.from]||!Number.isInteger(s.to)||!data.firms[s.to]||!Object.hasOwn(goods,s.good)||!Number.isFinite(s.qty)||s.qty<=0||!Number.isFinite(s.remaining))))return false;
  // Reject structurally broken saves before they can replace the running town.
  // These checks also protect long-playing towns from partial imports and invalid IDs.
  if(!Array.isArray(data.homes)||!Array.isArray(data.projects??[])||
     !data.buildings.every(b=>b&&Number.isInteger(b.id)&&b.id>0&&types[b.kind]&&Number.isInteger(b.x)&&Number.isInteger(b.y)&&b.x>=0&&b.x<T&&b.y>=0&&b.y<T&&Number.isFinite(b.value)&&Number.isFinite(b.condition))||
     !data.people.every((p,i)=>p&&p.id===i&&Number.isInteger(p.hh)&&p.hh>=0&&p.hh<data.households.length&&Number.isFinite(p.age))||
     !data.households.every((h,i)=>h.id===i&&h.people.every(id=>Number.isInteger(id)&&id>=0&&id<data.people.length))||
     !data.firms.every((f,i)=>f.id===i&&Number.isInteger(f.building)&&Number.isFinite(f.jobs)&&f.workers.every(id=>Number.isInteger(id)&&id>=0&&id<data.people.length)))return false;
  const addressSet=new Set(),idSet=new Set(),memberSet=new Set();
  for(const b of data.buildings){const cells=Array.isArray(b.footprint)&&b.footprint.length?b.footprint:[b.y*T+b.x];
   if(cells.length>36||new Set(cells).size!==cells.length||!cells.includes(b.y*T+b.x))return false;
   for(const plot of cells){if(!Number.isInteger(plot)||plot<0||plot>=T*T||addressSet.has(plot)||data.tiles[plot]===1||data.tiles[plot]===2||data.landUse?.[plot])return false;addressSet.add(plot);}
   if(idSet.has(b.id))return false;idSet.add(b.id);
  }
  for(const h of data.households)for(const id of h.people){if(memberSet.has(id)||data.people[id].hh!==h.id||data.people[id].deceased||data.people[id].movedAway)return false;memberSet.add(id)}
  data.version=3;data.policy={...defaults,...data.policy};
  data.banks=Array.isArray(data.banks)?data.banks.filter(b=>b&&Number.isInteger(b.id)&&b.id>=0&&b.id<12&&Number.isFinite(b.cash)&&b.cash>=0&&Number.isFinite(b.depositAPY)&&Number.isFinite(b.loanAPY)).slice(0,12):[];
  data.loans=Array.isArray(data.loans)?data.loans.filter(l=>l&&Number.isInteger(l.id)&&Number.isFinite(l.balance)&&l.balance>=0&&['active','repaid','default'].includes(l.status)).slice(0,10000):[];
  if(new Set(data.banks.map(b=>b.id)).size!==data.banks.length||data.banks.some((b,i)=>b.id!==i))return false;
  const loanIDs=new Set();for(const l of data.loans){if(loanIDs.has(l.id)||!['household','firm'].includes(l.ownerType)||!Number.isInteger(l.ownerId)||!Number.isInteger(l.bankId)||!Number.isFinite(l.rate)||l.rate<0||l.balance<0)return false;loanIDs.add(l.id);if(l.ownerType==='household'&&!data.households[l.ownerId]||l.ownerType==='firm'&&!data.firms[l.ownerId]||l.bankId>=data.banks.length)return false;}
  data.nextLoanId=Math.max(Number.isSafeInteger(data.nextLoanId)?data.nextLoanId:0,...data.loans.map(l=>l.id),0);
  data.finance={failures:0,businessDefaults:0,householdDefaults:0,creditIssued:0,depositLosses:0,insuredPayouts:0,foreclosures:0,downzonings:0,insolvencies:0,bankRuns:0,...(data.finance||{})};data.council=data.council||{approval:60,elections:0,factions:{workers:60,merchants:60,homeowners:60,public:60}};
  data.council.factions=data.council.factions||{workers:60,merchants:60,homeowners:60,public:60};data.achievements=data.achievements||[];data.ambition=data.ambition||'balanced';data.ambitionDays=data.ambitionDays||{};data.lastMonth=data.lastMonth||{};data.crisesHandled=data.crisesHandled||0;data.policyOutcomes=data.policyOutcomes||[];data.construction=data.construction||0;data.worldSeed=data.worldSeed||101;data.weather=data.weather||'clear';data.education=data.education||46;data.health=data.health||74;data.lastEventDay=data.lastEventDay||1;data.regionalDemand=data.regionalDemand||1;data.recentCouncilEvents=data.recentCouncilEvents||[];data.unrest=data.unrest||0;data.scenario=data.scenario||'settlement';data.stats=data.stats||{};data.history=data.history||[];data.journal=data.journal||[];data.events=data.events||[];data.cases=data.cases||[];data.cumulative={incomeTax:0,profitTax:0,propertyTax:0,foodTax:0,utilityTax:0,commercialRate:0,permits:0,tariffs:0,spending:0,crime:0,fires:0,welfare:0,...data.cumulative};
  data.debt=Number.isFinite(data.debt)?Math.max(0,data.debt):0;data.publicReserve=Number.isFinite(data.publicReserve)?Math.max(0,data.publicReserve):0;
  data.projects=Array.isArray(data.projects)?data.projects.filter(p=>p&&Number.isInteger(p.id)&&Number.isFinite(p.remaining)&&p.remaining>0).slice(0,1000):[];
  data.metro=data.metro||{cash:0,stations:[],lines:[],fare:2.75,rides:0,revenue:0,expenses:0,dailyRides:0,daysInDeficit:0,operating:false,invested:0};
  data.development=data.development||{homes:0,firms:0,roads:0,stations:0,lastReport:null,decisions:[]};data.privateRoads=Array.isArray(data.privateRoads)?data.privateRoads.filter(id=>Number.isInteger(id)&&id>=0&&id<T*T&&data.tiles[id]===1):[];
  data.autoBuild=data.autoBuild!==false;data.landUse=(data.landUse&&typeof data.landUse==='object'&&!Array.isArray(data.landUse))?data.landUse:{};data.fieldOwner=(data.fieldOwner&&typeof data.fieldOwner==='object'&&!Array.isArray(data.fieldOwner))?data.fieldOwner:{};data.fieldCount={};for(const [id,code] of Object.entries(data.landUse)){if(!/^\d+$/.test(id)||+id>=T*T||![1,2,3].includes(code)||data.tiles[+id]!==0){delete data.landUse[id];delete data.fieldOwner[id];continue}if(code===1){const owner=data.fieldOwner[id];if(!Number.isInteger(owner)||!data.firms[owner]||data.firms[owner].kind!=='farm'){delete data.landUse[id];delete data.fieldOwner[id]}else data.fieldCount[owner]=(data.fieldCount[owner]||0)+1;}}data.airport=data.airport&&Number.isInteger(data.airport.building)&&Array.isArray(data.airport.runway)?data.airport:null;data.development={fields:0,redevelopments:0,towers:0,airfields:0,...data.development};
  if(!Number.isFinite(data.metro.cash)||data.metro.cash<0||!Array.isArray(data.metro.lines)||!Array.isArray(data.metro.stations)||data.metro.stations.length>120||data.metro.lines.length>120)return false;
  for(const d of defs){const k=d[0],v=Number(data.policy[k]);data.policy[k]=clamp(Number.isFinite(v)?v:defaults[k],d[2],d[3]);}
  data.policy.imports=data.policy.imports!==false;
  if(data.households.some(h=>!h||!Array.isArray(h.people)||!Number.isFinite(h.cash)||h.cash<0)||data.firms.some(f=>!f||!Array.isArray(f.workers)||!Number.isFinite(f.cash)||f.cash<0))return false;
  const workerIDs=new Set();for(const f of data.firms){for(const id of f.workers){if(workerIDs.has(id)||!data.people[id]||data.people[id].deceased||data.people[id].movedAway||data.people[id].job!==f.id)return false;workerIDs.add(id)}}
  G=data;crewDay=-1;crewsUsed=new Map();regionalCrews=0;ensureSystems();rngState=Number.isInteger(G.rngState)?G.rngState:G.scenarioSeed;ensureFinance();if(!G.banks.length)seedBanks();draftPolicy={};roadBatchDirty=false;invalidateRoads();cacheBuildingsFor=null;recompute();G.stats.approval=Math.round(G.council.approval);G.stats.health=Math.round(G.health);G.stats.education=Math.round(G.education);G.stats.marketConfidence=G.stats.marketConfidence||55;G.stats.wellbeing=G.stats.wellbeing||70;restoreTransport();staticDirty=true;dirty=true;updateHeader();return true;
 }catch(e){G=previousTown;invalidateRoads();cacheBuildingsFor=null;staticDirty=true;dirty=true;console.error('Invalid save',e);return false}
}
function writeIndexedDB(text){
 try{const req=indexedDB.open('townledger-save',1);req.onupgradeneeded=()=>{if(!req.result.objectStoreNames.contains('saves'))req.result.createObjectStore('saves')};req.onsuccess=()=>{try{const db=req.result;const tx=db.transaction('saves','readwrite');tx.objectStore('saves').put(text,'latest');tx.oncomplete=()=>db.close()}catch(e){}}}catch(e){}
}
function discoverIndexedDB(){try{const req=indexedDB.open('townledger-save',1);req.onupgradeneeded=()=>{if(!req.result.objectStoreNames.contains('saves'))req.result.createObjectStore('saves')};req.onsuccess=()=>{try{const db=req.result,tx=db.transaction('saves');const r=tx.objectStore('saves').get('latest');r.onsuccess=()=>{if(r.result){window.__idbSave=r.result;$('continue').style.display='block'}};tx.oncomplete=()=>db.close()}catch(e){}}}catch(e){}}
discoverIndexedDB();
function exportSave(){
 const text=archivePayload();const dialog=$('helpDialog');dialog.querySelector('.paper').innerHTML=`<h2>YOUR TOWN ARCHIVE</h2><p>Copy this backup into a text file. Paste it here later to restore the village, even after reinstalling.</p><textarea id="saveText" style="display:block;width:100%;height:145px;background:#f7efd9;color:#183425;font:11px monospace;touch-action:pan-y;border:1px solid #8a8c6c;padding:9px"></textarea><button id="copySave" class="menu-primary">SELECT AND COPY</button><button id="archiveClose">CLOSE</button>`;dialog.style.display='flex';$('saveText').value=text;$('copySave').onclick=()=>{$('saveText').focus();$('saveText').select();try{document.execCommand('copy')}catch(e){};toast('Backup text selected for copying.')};$('archiveClose').onclick=()=>{dialog.style.display='none';restoreHelpMarkup()};
}
function importSave(){const dialog=$('helpDialog');dialog.querySelector('.paper').innerHTML=`<h2>RESTORE A TOWN</h2><p>Paste a TownLedger backup below. Your current game will be replaced after validation.</p><textarea id="importText" style="display:block;width:100%;height:145px;background:#f7efd9;color:#183425;font:11px monospace;touch-action:pan-y;border:1px solid #8a8c6c;padding:9px"></textarea><button id="restoreGo" class="menu-primary">RESTORE THIS TOWN</button><button id="restoreCancel">CANCEL</button>`;dialog.style.display='flex';$('restoreGo').onclick=()=>{if(hydrateSave($('importText').value)){cam={x:RW/2,y:RH/2,zoom:.68};save();dialog.style.display='none';restoreHelpMarkup();toast('Town archive restored.');renderPanel('overview')}else toast('The backup is invalid or incompatible.')};$('restoreCancel').onclick=()=>{dialog.style.display='none';restoreHelpMarkup()};}
const originalHelp=$('helpDialog').querySelector('.paper').innerHTML;
function restoreHelpMarkup(){$('helpDialog').querySelector('.paper').innerHTML=originalHelp;$('helpClose').onclick=()=>{$('helpDialog').style.display='none'}}
$('helpClose').onclick=()=>{$('helpDialog').style.display='none'};$('howTo').onclick=()=>{$('helpDialog').style.display='flex'};
$('scenarioPicker').addEventListener('click',e=>{let b=e.target.closest('[data-scenario]');if(!b)return;chosenScenario=b.dataset.scenario;document.querySelectorAll('[data-scenario]').forEach(v=>v.classList.toggle('chosen',v===b))});

// Override continue to support the IndexedDB fallback when localStorage is inaccessible.
$('continue').onclick=()=>{if(!load()&&window.__idbSave){if(!hydrateSave(window.__idbSave))seed()}else if(!G)seed();$('welcome').style.display='none';dirty=true;staticDirty=true;updateHeader();openPanel('overview')};
function tip(s){return `<p class="desc">${esc(s)}</p>`}
function strip(label,value){return `<div class="line"><span>${esc(label)}</span><span>${esc(String(value))}</span></div>`}
function meter(label,value,color='#d5b779'){return `<div class="line"><span>${esc(label)}</span><span><b>${Math.round(value)}%</b></span></div><div class="progress"><i style="width:${clamp(value,0,100)}%;background:${color}"></i></div>`}
function greeting(){return G.month<4?'A quiet spring morning in the Vale':G.month<7?'High summer and hard work':G.month<10?'Harvest season in the borough':'Winter settles on the cobbled lanes'}
function miniChart(k,height=130){let ar=(G.history||[]).slice(-120);if(ar.length<2)return tip('The figures will appear as the town develops.');let vals=ar.map(o=>Number(o[k])||0),lo=Math.min(...vals),hi=Math.max(...vals),span=Math.max(1,hi-lo);let points=vals.map((v,i)=>`${(i/(vals.length-1)*330).toFixed(1)},${(height-20-(v-lo)/span*(height-35)).toFixed(1)}`).join(' ');return `<svg class="chart-lines" viewBox="0 0 330 ${height}" preserveAspectRatio="none"><path d="M0 ${height-20}H330 M0 ${height/2}H330 M0 18H330" stroke="#627563" stroke-width=".6" fill="none"/><polyline points="${points}" fill="none" stroke="#e8c887" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg><div class="desc">Past ${ar.length} days · low ${fmt(lo)} · high ${fmt(hi)} · latest ${fmt(vals[vals.length-1])}</div>`}
function headlineList(count=7){let ev=G.events.slice(0,count);return ev.map(e=>`<div class="event" style="border-left-color:${e.type==='bad'?'#e99a80':e.type==='good'?'#9fd4ab':'#c0ab7e'}"><strong>DAY ${e.day}</strong><div>${esc(e.text)}</div>${e.bid>0?`<button class="small" data-inspect="${e.bid}">Visit location</button>`:''}</div>`).join('')}
function currentAmbition(){return AMBITIONS.find(m=>m.id===G.ambition)||AMBITIONS[0]}
function ambitionCard(m,compact=false){let achieved=G.achievements.includes(m.id),days=G.ambitionDays[m.id]||0,selected=G.ambition===m.id,progress=achieved?1:m.goal(G)?days/m.days:Math.min(.95,m.progress(G)*.85);return `<div class="mission-item ${selected?'selected':''}" data-ambition="${m.id}"><div style="display:flex;align-items:center;justify-content:space-between;gap:10px"><b>${esc(m.title)}</b><span class="pill">${achieved?'ACHIEVED':selected?'TRACKING':'SELECT'}</span></div>${compact?'':`<small>${esc(m.description)}</small>`}<div class="progress"><i style="width:${Math.round(clamp(progress,0,1)*100)}%"></i></div><small>${achieved?'Completed · grant awarded':(m.goal(G)?days+' / '+m.days+' qualifying days':'Conditions not yet sustained')}${compact?'':' · Development grant '+money(m.reward)}</small></div>`}
function renderOverviewFull(){let s=G.stats,m=currentAmbition(),C=G.council;return `<div class="scenario-badge">${G.scenario==='settlement'?'PROSPEROUS VALE':G.scenario==='hardtimes'?'HARD TIMES':G.scenario==='frontier'?'THE FRONTIER':'FACTORY COUNTRY'} · ${esc(greeting())}</div>`+
 head('The borough at a glance')+`<div class="statgrid">${stat('Residents',fmt(s.population))}${stat('Town treasury',money(G.treasury),G.treasury<5000?'negative':'')}${stat('Residents in work',s.employment+'%',s.employment<60?'negative':'')}${stat('Council trust',Math.round(C.approval)+'%',C.approval<45?'negative':'')}</div>`+
 head('The state of daily life')+meter('Public safety',s.safety,s.safety>80?'#a9d7ad':'#d9ad7b')+meter('Household wellbeing',s.wellbeing||70)+meter('Local business confidence',s.marketConfidence||60)+strip('Households struggling',s.hardship+'%')+strip('Crime reports in last month',s.dailyCrime)+strip('Trading businesses',s.businesses+' / '+G.firms.length)+
 `<div class="council-card"><h3>Current ambition: ${esc(m.title)}</h3><p class="tip">${esc(m.description)}</p>${ambitionCard(m,true)}<div class="btnrow"><button id="jumpAgenda">View council ambitions</button><button id="focusBad">Visit struggling household</button></div></div>`+
 head('A household behind the numbers')+(()=>{let h=G.households.filter(h=>h.people.length>0&&readBuild(h.home)).sort((a,b)=>b.stress-a.stress)[0];if(!h)return '';let net=h.income-h.tax-h.food-h.rent-(h.utilities||0)-(h.travel||0)+h.aid;return `<div class="council-card"><h3>The ${esc(h.name)} family</h3><p class="desc">${h.people.length} residents · ${money(h.cash)} in savings · ${(100-h.stress).toFixed(0)}/100 wellbeing. Yesterday's income ${money(h.income)}, essential spending ${money(h.food+h.rent+(h.utilities||0)+(h.travel||0))}, net household flow ${money(net)}.</p><button data-house="${h.id}">Inspect this family</button></div>`})()+
 ((G.councilInbox||[]).length?`<div class="inbox-notice"><strong>✉ ${(G.councilInbox||[]).length} council letter(s)</strong><button id="jumpAgenda">Review when ready</button></div>`:'')+head('From the town crier')+headlineList(6)+head('Employment trend')+miniChart('employment');}
function renderAgenda(){let C=G.council,days=360-(G.day%360),completed=G.achievements.length;return head('The council chamber')+`<div class="statgrid">${stat('Approval',Math.round(C.approval)+'%',C.approval<45?'negative':'positive')}${stat('Days until election',days)}${stat('Elections held',C.elections)}${stat('Ambitions fulfilled',completed+' / '+AMBITIONS.length)}</div>`+
 tip('Council approval changes in response to employment, household finances, safety, taxation and business conditions. Each constituency weighs these outcomes differently.')+
 head('Four voices of the town')+meter('Working families',C.factions.workers,'#a6c8c1')+meter('Merchants & employers',C.factions.merchants,'#d6b779')+meter('Property owners',C.factions.homeowners,'#d5a17f')+meter('Public services & safety',C.factions.public,'#9acc9a')+
 head('Town ambitions')+tip('Choose one ambition to track. All nine can be completed over a long playthrough. Awards provide small, finite grants from the region rather than creating money.')+AMBITIONS.map(m=>ambitionCard(m)).join('')+
 head('Council correspondence')+tip('Letters, petitions and dilemmas arrive in the inbox without stopping the town. Review them on your own schedule, or let the economy run unattended at any speed.')+
 ((G.councilInbox||[]).length?G.councilInbox.map((item,i)=>`<div class="council-card inbox-letter"><small class="letter-day">RECEIVED DAY ${item.day}</small><h3>${esc(item.title)}</h3><button data-inbox="${i}">Review and decide</button></div>`).join(''):'<p class="desc">No correspondence is waiting. The town continues operating on its own.</p>')+
 `<div class="btnrow"><button id="convene" ${G.day-G.lastEventDay<12?'disabled':''}>Request council meeting</button><button id="jumpJournal">Open policy journal</button></div>`;
}
function renderCommunityFull(){let s=G.stats;return head('Private growth and mobility')+developmentPanel()+head('Banking & enterprise finance')+strip('Competing banks',G.banks.filter(b=>!b.closed).length+' operating')+strip('Outstanding bank credit',money(G.loans.filter(l=>l.status==='active').reduce((n,l)=>n+l.balance,0)))+head('Constabulary & civil defence')+`<div class="statgrid">${stat('Public safety',s.safety+'/100')}${stat('Crime reports · 30 days',s.dailyCrime)}${stat('Emergency readiness',s.preparedness+'%')}${stat('Residents in hardship',s.hardship+'%')}</div>`+
 tip('Incidents affect named residents and firms. Police staffing and funding reduce risk; underfunded emergency services leave properties more exposed to fire and storm damage.')+
 head('People, health and schools')+`<div class="statgrid">${stat('Public health',Math.round(G.health)+'/100')}${stat('Education level',Math.round(G.education)+'/100')}${stat('Wellbeing',s.wellbeing+'/100')}${stat('Community security',s.safety+'/100')}</div>`+
 head('Road network and emergency reach')+strip('Pavement condition',Math.round(G.stats.roadCondition??100)+' / 100')+strip('Main road-network tiles',roadMetrics().maxSize)+strip('Disconnected road clusters',Math.max(0,roadMetrics().roadClusters-1))+strip('Firms connected to town',roadMetrics().connectedFirms+' / '+roadMetrics().totalFirms)+strip('Funded road maintenance',Math.round((G.actualServiceFunding?.roads??1)*100)+'% of budget')+`<div class="btnrow"><button id="overlayR">${overlay==='roads'?'✓ ':''}Road-access map</button></div>`+head('Funded services')+strip('Actual patrol budget paid',Math.round((G.actualServiceFunding?.police??1)*100)+'% of authorized')+strip('Actual fire budget paid',Math.round((G.actualServiceFunding?.fire??1)*100)+'% of authorized')+strip('Constabulary per day',money(G.policy.policeBudget))+strip('Fire & rescue per day',money(G.policy.defenseBudget))+strip('Medical services per day',money(G.policy.healthBudget))+strip('Schools & training per day',money(G.policy.educationBudget))+strip('Civil defence volunteers',money(G.policy.militiaBudget))+strip('Household relief per day',money(G.policy.aidBudget))+strip('Heating assistance',money(G.policy.energyAidBudget||0))+strip('Commuter transit',money(G.policy.transitBudget||0))+
 `<div class="btnrow"><button id="overlayC">${overlay==='crime'?'✓ ':' '}Crime map</button><button id="overlayH">${overlay==='hardship'?'✓ ':' '}Hardship map</button></div>`+
 head('Constabulary incident log')+(G.cases.length?G.cases.slice(0,15).map(eventHtml).join(''):tip('No recorded incidents. This does not mean risk is zero.'))+
 head('Safety across time')+miniChart('safety');}
function renderPoliciesFull(){let sections=[['Taxation','incomeTax','profitTax','propertyTax','commercialRate','foodTax','utilityTax'],['Work and enterprise','minWage','employmentSubsidy','permitFee','businessRegulation','zoningRestriction'],['Government services','policeBudget','defenseBudget','healthBudget','educationBudget','aidBudget','energyAidBudget','outreachBudget','roadBudget','transitBudget','militiaBudget'],['Banking and credit','bankReserve','lendingRules','depositGuarantee','treasuryInvestment'],['Trade and exchange','importTariff']];let changes=Object.keys(draftPolicy).filter(k=>draftPolicy[k]!==G.policy[k]);let projected=defs.filter(d=>changes.includes(d[0])).map(d=>`${d[1]}: ${fmt(G.policy[d[0]])} → ${fmt(draftPolicy[d[0]])}${d[5]==='$'?' dollars':d[5]}`).join('<br>');
 return `<div class="notice-banner" style="background:#3b4b36;border-color:#938459">The market runs itself. You set rules and fiscal priorities. Select a council programme or adjust rates manually, then enact the package and watch the town adapt over time.</div>`+
 `<div class="cabinet-agendas"><button data-cabinet="enterprise"><strong>Make room for enterprise</strong><small>Lower taxes, permits and barriers to development.</small></button><button data-cabinet="housing"><strong>Open the housing market</strong><small>Ease planning rules and improve access.</small></button><button data-cabinet="services"><strong>Invest in families</strong><small>Finance schools, care, relief and roads.</small></button><button data-cabinet="austerity"><strong>Balance the council purse</strong><small>Reduce spending and slow new commitments.</small></button></div>`+
 sections.map((group,index)=>`<details class="policy-group" ${index===0?'open':''}><summary>${esc(group[0])}</summary>`+group.slice(1).map(k=>{let d=defs.find(d=>d[0]===k);if(!d)return '';let [key,name,lo,hi,step,unit,help]=d,v=draftPolicy[key]??G.policy[key];return `<div class="range"><label><b>${esc(name)}</b><span id="show-${key}">${unit==='$'?money(v):fmt(v)+unit}</span></label><input type="range" data-policy="${key}" aria-label="${esc(name)}" min="${lo}" max="${hi}" step="${step}" value="${v}"><p class="desc">${esc(help)}</p></div>`}).join('')+'</details>').join('')+
 `<div class="line"><span>Regional imports</span><button id="tradeToggle" class="small ${G.policy.imports?'on':''}">${G.policy.imports?'ALLOWED':'RESTRICTED'}</button></div>`+
 `<div class="council-card"><h3>Proposed policy package</h3><p class="desc" id="draftSummary">${changes.length?projected:'Move one or more controls to propose changes.'}</p><div class="btnrow"><button id="enactPolicy" class="action-green" ${changes.length?'':'disabled'}>ENACT POLICY CHANGES</button><button id="resetPolicy">Discard changes</button></div></div>`;
}
function enactPolicyPackage(){let changes=Object.keys(draftPolicy).filter(k=>draftPolicy[k]!==G.policy[k]);if(!changes.length){toast('No policy changes have been proposed.');return}
 let before={...G.stats,treasury:G.treasury},names=[];ensureSystems();G.policyExperiments.push({day:G.day,before:G.observations.at(-1)||{...before},changes:changes.map(k=>({key:k,from:G.policy[k],to:draftPolicy[k]})),after:null});G.policyExperiments=G.policyExperiments.slice(-30);
 for(let k of changes){let old=G.policy[k],value=draftPolicy[k],d=defs.find(d=>d[0]===k);if(!d)continue;G.policy[k]=value;names.push(d[1]+': '+fmt(old)+' → '+fmt(value));}
 G.council.approval=clamp(G.council.approval-Math.min(6,changes.length*.7),5,97);G.journal.push({day:G.day,name:'Council policy package',message:names.join(' · '),baseline:before});if(G.journal.length>160)G.journal.shift();story('Council enacted '+changes.length+' economic and civic policy changes.','neutral');draftPolicy={};recompute();save();updateHeader();renderPanel('policies');toast('Policy package enacted. Let time pass to observe the effects.');}
function renderTreasuryFull(){let c=G.cumulative,P=G.policy,s=G.stats;let revenues=['incomeTax','profitTax','propertyTax','foodTax','utilityTax','commercialRate','tariffs','permits'].reduce((n,k)=>n+(c[k]||0),0);let daily=(P.policeBudget+P.defenseBudget+P.healthBudget+P.educationBudget+P.aidBudget+(P.energyAidBudget||0)+P.outreachBudget+P.roadBudget+(P.transitBudget||0)+P.militiaBudget)+(s.employed||0)*P.employmentSubsidy;let avgRev=(revenues/Math.max(1,G.day-1));let forecast=avgRev-daily;
 return head('Public balance sheet')+`<div class="statgrid">${stat('Liquid municipal cash',money(G.treasury),G.treasury<5000?'negative':'')}${stat('Outstanding debt',money(G.debt))}${stat('Receipts since founding',money(revenues))}${stat('Public spending',money(c.spending||0))}</div>`+
 `<div class="council-card"><h3>Budget outlook</h3>${strip('Average daily receipts since founding',money(avgRev))}${strip('Authorized daily programmes',money(daily))}${strip('Indicative daily difference',money(forecast))}<div class="desc">A backward-looking estimate, not a guaranteed forecast. Receipts change with employment, business profitability, imports and other conditions; annual taxes accrue daily.</div></div>`+
 head('Cumulative receipts')+strip('Income tax',money(c.incomeTax||0))+strip('Company profit tax',money(c.profitTax||0))+strip('Annual property tax instalments',money(c.propertyTax||0))+strip('Food sales tax',money(c.foodTax||0))+strip('Domestic energy levy',money(c.utilityTax||0))+strip('Commercial property rates',money(c.commercialRate||0))+strip('Import duties',money(c.tariffs||0))+strip('Business licences',money(c.permits||0))+
 head('Financial instruments')+`<div class="btnrow"><button id="borrow">Issue $5,000 bond</button><button id="repay" ${G.debt<=0?'disabled':''}>Repay up to $5,000</button></div>`+tip('Regional credit is capped at '+money(Math.max(25000,s.population*350))+'. Bonds create matching debt; monthly interest accrues. Private investment is not municipal borrowing.')+
 head('Cash reserve over time')+miniChart('treasury');}
function renderCitizensFull(){let hs=G.households.slice();if(filterPeople==='struggling')hs=hs.filter(h=>h.cash/Math.max(1,h.people.length)<600||h.stress>50);if(filterPeople==='jobless')hs=hs.filter(h=>h.people.every(id=>G.people[id]?.job<0&&!G.people[id]?.publicWork));if(filterPeople==='wealthy')hs.sort((a,b)=>b.cash-a.cash);if(filterPeople==='lowcash')hs.sort((a,b)=>a.cash-b.cash);if(citizenQuery.trim())hs=hs.filter(h=>(h.name+' '+h.people.map(id=>G.people[id]?.name||'').join(' ')).toLowerCase().includes(citizenQuery.trim().toLowerCase()));
 return head('Lives behind the statistics')+tip('Every family has savings, employment, food spending, rent, a home, health and security. Inspect a cottage to see the direct consequences of policy.')+
 `<input id="searchPeople" class="search-field" placeholder="Search a family or resident" value="${esc(citizenQuery)}"><div class="filter-row">${[['all','All'],['struggling','At risk'],['jobless','No job'],['lowcash','Least savings'],['wealthy','Most savings']].map(([k,n])=>`<button class="${filterPeople===k?'on':''}" data-filter-people="${k}">${n}</button>`).join('')}</div>`+
 `<div class="miniNote">Showing ${Math.min(80,hs.length)} of ${hs.length} matching households</div>`+
 hs.slice(0,80).map(h=>{let people=h.people.map(id=>G.people[id]).filter(p=>p&&!p.deceased&&p.movedAway!==true),workers=people.filter(p=>p.job>=0||p.publicWork).length,stress=Math.round(h.stress),net=h.income-h.tax-h.food-h.rent-(h.utilities||0)-(h.travel||0)+h.aid;let note=h.cash<300?'Money is extremely tight':workers===0?'No employed household members':stress>65?'Under severe strain':net<0?'Outgoings exceed earnings':'Finances currently stable';return `<div class="entry" data-house="${h.id}"><div style="display:flex;justify-content:space-between;gap:5px"><strong>The ${esc(h.name)} family</strong><span class="pill">${stress>60?'UNDER PRESSURE':workers?'WORKING':'JOBLESS'}</span></div><small>${people.length} residents · ${workers} employed · Cash ${money(h.cash)} · Daily net ${money(net)}<br>${esc(note)}</small></div>`}).join('')||tip('No households match the current filter.');}
function renderBusinessesFull(){let fs=G.firms.slice();if(filterFirms==='open')fs=fs.filter(f=>!f.closed);if(filterFirms==='closed')fs=fs.filter(f=>f.closed);if(filterFirms==='losing')fs=fs.filter(f=>!f.closed&&f.profit<0);if(filterFirms==='rich')fs.sort((a,b)=>b.cash-a.cash);if(filterFirms==='poor')fs.sort((a,b)=>a.cash-b.cash);
 return head('The commercial high street')+tip('Production follows supply chains: farms supply mills, mills supply bakeries, and bakeries supply grocers. Forests and stone quarries feed construction markets. Firms hire people and make real payments.')+
 `<div class="statgrid">${stat('Enterprises trading',G.stats.businesses)}${stat('Market confidence',G.stats.marketConfidence+'/100')}${stat('Regional demand',Math.round((G.regionalDemand||1)*100)+'/100')}${stat('Businesses on road grid',G.stats.roadAccess+'%')}${stat('Freight fees paid',money(G.cumulative.freight||0))}</div>`+
 `<div class="filter-row">${[['all','All'],['open','Trading'],['closed','Closed'],['losing','Loss-making'],['rich','Most capital'],['poor','Least capital']].map(([k,n])=>`<button class="${filterFirms===k?'on':''}" data-filter-firms="${k}">${n}</button>`).join('')}</div>`+
 fs.slice(0,90).map(f=>`<div class="entry" data-firm="${f.id}"><div style="display:flex;justify-content:space-between;gap:7px"><strong>${esc(f.name)}</strong><span class="pill">${f.closed?'CLOSED':'TRADING'}</span></div><small>${esc(types[f.kind].n)} · ${f.workers.length} / ${f.jobs} jobs · Capital ${money(f.cash)}<br>Revenue ${money(f.revenue)} · Profit ${money(f.profit)} · Tax ${money(f.tax)}</small></div>`).join('');}
function renderConstructionFull(){const cats=[['all','All'],['housing','Housing'],['commerce','Commerce'],['production','Industry'],['services','Civic works']];let groups={housing:['road','home','park','square'],commerce:['grocer','bakery','tavern'],production:['farm','mill','fishery','forestry','sawmill','quarry','contractor'],services:['police','fire','clinic','school','courthouse','watchtower','park','square','road','repair']};let keys=constructionCategory==='all'?Object.keys(buildCost).filter(k=>k!=='metro_station'):groups[constructionCategory]||Object.keys(buildCost).filter(k=>k!=='metro_station');
 return head('Build the borough')+tip('Choose a structure, then tap vacant land beside an existing road. Paint roads by dragging. Industrial and retail firms receive private investment, but council must authorize the site.')+
 `<div class="statgrid">${stat('Buildings in town',G.buildings.length)}${stat('Developed road tiles',G.tiles.filter(t=>t===1).length)}${stat('Road condition',Math.round(G.stats.roadCondition??100)+'%')}${stat('Firms with road access',(roadMetrics().connectedFirms)+' / '+roadMetrics().totalFirms)}${stat('Homes with road access',roadMetrics().connectedHomes+' / '+roadMetrics().totalHomes)}</div>`+
 `<div class="filter-row">${cats.map(([k,n])=>`<button class="${constructionCategory===k?'on':''}" data-build-category="${k}">${n}</button>`).join('')}</div>`+
 `<div class="build-grid"><button data-build="" class="build-item ${buildMode===''?'on':''}"><div class="build-icon">⌖</div><span><strong>INSPECT</strong><small>Return to surveying</small></span></button>${keys.map(k=>`<button data-build="${k}" class="build-item ${buildMode===k?'on':''}" ${G.treasury<buildCost[k]?'disabled':''}><div class="build-icon">${buildIcons[k]}</div><span><strong>${esc(types[k]?.n||'Road')}</strong><small>${money(buildCost[k])} · place on map</small></span></button>`).join('')}</div>`+
 `<div class="council-card"><h3>Private development</h3>${developmentPanel()}<button id="toggleDevelopment" class="small">${G.autoBuild?'PAUSE PRIVATE DEVELOPMENT':'RESUME PRIVATE DEVELOPMENT'}</button><button id="overlayMetro" class="small">${overlay==='metro'?'HIDE':'SHOW'} UNDERGROUND NETWORK</button></div>`+`<div class="council-card"><h3>Road transport</h3><p class="desc">All traffic follows connected streets. Disconnected businesses cannot use local suppliers; deliveries become more expensive with distance and poor maintenance. Roads connect only at shared tile edges.</p><button id="overlayR" class="small">${overlay==='roads'?'✓ ':''}Show road accessibility</button></div>`+`<div class="council-card"><h3>Planning office notes</h3><div class="desc">Building requires unoccupied land touching a road. Parks improve local wellbeing; stations strengthen funded services. New enterprises need workers and customers to survive. Private developers can extend roads, build new homes and open companies without council placement. Construction responds to demand, taxation, local earnings, capital availability and planning restrictions.</div></div>`;
}
function renderJournalFull(){let j=G.journal.slice().reverse();return head('The public record')+tip('Every recorded policy change preserves the indicators at the date of enactment. Comparisons are observational; several causes can change at once.')+
 `<div class="statgrid">${stat('Recorded decisions',j.length)}${stat('Years in office',G.year)}${stat('Crimes reported',G.cumulative.crime)}${stat('Emergency incidents',G.cumulative.fires)}</div>`+
 head('Economic history')+miniChart('employment')+head('Council trust over time')+miniChart('approval')+
 head('Government decisions')+j.slice(0,45).map(p=>{let base=p.baseline||{};let delta=(k)=>{let current=k==='treasury'?G.treasury:G.stats[k],old=base[k]||0,d=(current-old);return (d>=0?'+':'')+fmt(d)};return `<div class="entry"><strong>DAY ${p.day}: ${esc(p.name)}</strong><p class="desc">${esc(p.message||'')}</p><div class="compact">Employment ${delta('employment')} pts &nbsp;·&nbsp; Hardship ${delta('hardship')} pts &nbsp;·&nbsp; Safety ${delta('safety')} pts<br>Businesses ${delta('businesses')} &nbsp;·&nbsp; Treasury ${delta('treasury')}</div></div>`}).join('')+
 head('Recent events')+headlineList(24);}
function renderSettingsFull(){return head('Your game and archive')+strip('Edition',RELEASE.edition+' '+RELEASE.version)+strip('Engine','Offline fixed-step economy + cached pixel canvas')+strip('Living residents',fmt(G.stats.population))+strip('Construction completed',fmt(G.construction))+strip('Town founded',G.scenario)+strip('Automatic saving',autoSaveOK?'Local storage available':'Check backup export')+strip('Simulation speed',speed+'× (1–64×, dynamic workload cap)')+
 `<div class="btnrow"><button id="soundToggle">${soundEnabled?'TURN OFF AMBIENCE & SOUND':'TURN ON AMBIENCE & SOUND'}</button><button id="saveNow" class="action-green">SAVE NOW</button><button id="backupSave">EXPORT BACKUP</button><button id="importSave">RESTORE BACKUP</button><button id="tutorial">GAME MANUAL</button><button id="restart" class="action-red">START NEW TOWN</button></div>`+
 head('Simulation principles')+tip('The economy runs as real linked accounts: wages and purchases move money among firms, families, the town treasury and the external region. Goods have inventory; people have jobs; firms have expenses. Government services spend actual cash and provide observable benefits.')+
 `<div class="notice-banner">Important: This is an experimental, self-contained Android adaptation. Policy coefficients are designed for gameplay, not calibrated forecasts of real municipal outcomes. Retain a text backup if you change devices or uninstall.</div>`;
}
function renderInspectFull(){const b=selected&&readBuild(selected.id);if(!b)return tip('Tap a building on the map.');const h=b.kind==='home'?G.households[b.hh]:null,f=b.firm>=0?G.firms[b.firm]:null;
 let html=`<div class="scenario-badge">PLOT ${b.x} · ${b.y} · ${esc(types[b.kind].n)}</div>`+head('Property report')+`<div class="statgrid">${stat('Estimated property value',money(b.value))}${stat('Physical condition',Math.round(b.condition)+'/100')}${stat('Land footprint',footprintOf(b).length+' plots')}</div>`;
 if(h){let people=h.people.map(id=>G.people[id]).filter(p=>p&&!p.deceased&&p.movedAway!==true),working=people.filter(p=>p.job>=0),net=h.income-h.tax-h.food-h.rent-(h.utilities||0)-(h.travel||0)+h.aid;let note=net<0?'Spending currently exceeds earnings. Low savings could place the family at risk.':h.stress>65?'Members of this household are experiencing substantial hardship.':'This household can presently meet its daily needs.';
 html+=head('The '+h.name+' household')+tip(note)+`<div class="statgrid">${stat('Savings',money(h.cash),h.cash<200?'negative':'')}${stat('Wellbeing',Math.round(100-h.stress)+'/100')}${stat('After-expense daily flow',money(net),net<0?'negative':'positive')}${stat('Family members employed',working.length+'/'+people.length)}</div>`+
 head('Banking & household credit')+strip('Deposits',money(Object.values(h.deposits||{}).reduce((a,v)=>a+v,0)))+strip('Credit standing',Math.round((h.creditScore??.65)*100)+'/100')+strip('Loan balance',money(G.loans.filter(l=>l.ownerType==='household'&&l.ownerId===h.id&&l.status==='active').reduce((a,l)=>a+l.balance,0)))+head('The daily household ledger')+strip('Gross wages',money(h.income))+strip('Income tax paid',money(h.incomeTax??h.tax))+strip('Energy levy',money(h.energyTax||0))+strip('Food basket',money(h.food))+strip('Heating and electricity',money(h.utilities||0))+strip('Travel to work',money(h.travel||0))+strip('Housing payment',money(h.rent))+strip('Public assistance',money(h.aid))+strip('Money taken in burglaries',money(h.crimeLoss))+strip('Perceived security',Math.round(h.security)+'/100')+
 head('People who live here')+people.map(p=>`<div class="entry"><strong>${esc(p.name)}</strong><small>Age ${p.age} · ${p.job>=0?esc(G.firms[p.job]?.name||'Employed'):(p.publicWork?'Municipal day work':'Not employed')}<br>Health ${Math.round(p.health)}/100 · Skill ${Math.round(p.skill*100)}/100</small></div>`).join('');}
 else if(f){html+=head(f.name)+tip(f.closed?'This business is currently closed. New investors may reopen it if conditions permit.':'A private company facing real demand, wages, supply costs, taxes and regulation.')+`<div class="statgrid">${stat('Working capital',money(f.cash),f.cash<600?'negative':'')}${stat('Staff',f.workers.length+'/'+f.jobs)}${stat('Sales today',money(f.revenue))}${stat('Operating profit',money(f.profit),f.profit<0?'negative':'positive')}</div>`+
 head('Business accounts')+strip('Road access',graph().portals.has(b.id)&&graph().parts[graph().portals.get(b.id)]===graph().mainPart?'Connected to high street':'Disconnected · no road freight')+strip('Operating expenses',money(f.expenses))+strip('Profit taxes',money(f.tax))+strip('Profit after tax',money(f.netProfit??f.profit))+strip('Effective daily wage',money(workerIncome(f)))+strip('Cash stolen',money(f.theft))+strip('Days trading',f.age)+
 strip('Outstanding bank debt',money(f.debt||0))+strip('Credit standing',Math.round((f.creditScore??.68)*100)+'/100')+
 head('Inventory available')+Object.keys(goods).map(k=>strip(k,fmt(f.stock[k]||0)+' units')).join('')+
 head('Employees')+f.workers.slice(0,25).map(id=>{let p=G.people[id];return p?`<div class="line"><span>${esc(p.name)}</span><span>${esc(G.households[p.hh]?.name||'')}</span></div>`:''}).join('');}
 else if(b.kind==='apartment'||b.kind==='tower'){let occupants=(b.units||[]).map(id=>G.households[id]).filter(Boolean);html+=head('A rebuilt residential district')+tip('A private developer consolidated a former low-density plot into multi-family homes. Existing residents retained an address and owners received acquisition compensation when applicable.')+strip('Occupied dwellings',occupants.length)+strip('Living residents',occupants.reduce((n,h)=>n+h.people.length,0))+strip('Original building',b.replacedKind||'Cottage')+head('Households')+occupants.slice(0,15).map(h=>`<div class="entry"><strong>The ${esc(h.name)} household</strong><small> · ${h.people.length} residents · Savings ${money(h.cash)}</small></div>`).join('');}
 else if(b.kind==='airport'){html+=head('Private regional airfield')+tip('Airport investment responds to regional activity and requires a large clear runway site, upfront capital, and continuing ticket and freight demand.')+strip('Runway plots',G.airport?.runway?.length||0)+strip('Passengers served',fmt(G.airport?.passengers||0))+strip('Freight tons',fmt(G.airport?.freight||0))+strip('Service',G.airport?.operating?'Operating':'Suspended');}
 else if(b.kind==='worksite'){const p=G.projects?.find(p=>p.id===b.id);html+=head('Private construction')+tip('A contractor is developing this property with private capital. Its residents or business will arrive when construction finishes.')+strip('Planned use',p?.kind==='home'?'Cottage':p?.firmKind||'Business')+strip('Days remaining',p?.remaining??'Unknown');}
 else if(b.kind==='bank'){const bk=G.banks.find(v=>v.id===b.bankId);html+=head('Local banking branch')+tip('A privately capitalized bank competing for deposits and borrowers. Losses reduce capital and can lead to failure.')+(bk?strip('Institution',bk.name)+strip('Cash reserves',money(bk.cash))+strip('Outstanding loans',money(bankLoans(bk.id)))+strip('Customer deposits',money(bankDeposits(bk.id)))+strip('Status',bk.closed?'Receivership':'Open to depositors'):'Branch closed');}
 else if(b.kind==='metro_station'){let metro=G.metro||{};html+=head('Private Underground Railway')+tip('Station owned by the Vale Underground company. Shareholders pay for track and stations; passengers pay fares. The town does not automatically subsidize this operator.')+strip('Service status',metro.operating?'Trains operating':'Suspended')+strip('Network',((metro.stations||[]).length)+' stations · '+((metro.lines||[]).length)+' lines')+strip('Fare',money(metro.fare||0))+strip('Journeys recorded',fmt(metro.rides||0))+strip('Shareholders’ cash',money(metro.cash||0));}
 else{html+=head('Municipal property')+tip('This structure serves the public. The building contributes to service effectiveness when paired with a funded government programme.')+strip('Type',types[b.kind].n)+strip('Town funding','Managed through Policies and Budget');}
 return html+`<div class="btnrow"><button id="closeInspect">BACK TO MAP</button></div>`;
}


// SOURCE: 92-government.js
function observedChart(key,color='#7f9968'){
 const a=G.observations.slice(-72);if(a.length<2)return tip('Observations accumulate every ten days.');
 const values=a.map(x=>Number(x[key])||0),lo=Math.min(...values),hi=Math.max(...values),span=Math.max(.0001,hi-lo);
 const p=values.map((v,i)=>`${(i/(values.length-1)*330).toFixed(2)},${(100-(v-lo)/span*85).toFixed(2)}`).join(' ');
 return `<svg class="chart-lines" viewBox="0 0 330 115" aria-label="${esc(key)} over time"><path d="M0 100H330M0 57H330M0 15H330" stroke="#bac4a3" fill="none"/><polyline points="${p}" fill="none" stroke="${color}" stroke-width="2"/></svg><div class="miniNote">Day ${a[0].day}–${a.at(-1).day} · ${fmt(lo)}–${fmt(hi)}</div>`;
}
function renderEconomicAtlas(){
 ensureSystems();const m=G.housingMarket,active=G.firms.filter(f=>!f.closed),latest=G.observations.at(-1)||{};
 return head('Property & capital')+`<div class="statgrid">${stat('Median home valuation',money(m.medianValue||0))}${stat('Rent index (founding = 1)',fmt(m.rentIndex))}${stat('Unoccupied dwellings',m.vacancy??0)}${stat('Paid construction contracts',money(G.investors[0].spending))}</div>`+
 tip('Valuations respond gradually to rents, access, condition and location. Investors compare operating yields with funding costs. Regional capital is finite; land and construction have recorded counterparties.')+
 head('Housing rents over time')+observedChart('rentIndex')+
 head('A government decision, followed through')+(G.policyExperiments.length?G.policyExperiments.slice(-4).reverse().map(e=>{
 const later=e.after||latest,days=later.day-e.day,before=e.before;
 return `<div class="council-card"><small>ENACTED DAY ${e.day} · ${e.after?'180-DAY REVIEW':Math.max(0,days)+' DAYS OBSERVED'}</small><h3>${esc(e.changes.map(c=>defs.find(d=>d[0]===c.key)?.[1]||c.key).join(', '))}</h3>${e.changes.map(c=>strip(defs.find(d=>d[0]===c.key)?.[1]||c.key,fmt(c.from)+' → '+fmt(c.to))).join('')}${strip('Population',fmt(before.population)+' → '+fmt(later.population))}${strip('Employment',fmt(before.employment)+'% → '+fmt(later.employment)+'%')}${strip('Private construction spending',money(before.privateSpend||0)+' → '+money(later.privateSpend||0))}${strip('Hardship',fmt(before.hardship)+'% → '+fmt(later.hardship)+'%')}<p class="desc">Observed changes include other influences. Compare identical seeded scenarios in the test suite to isolate a policy change.</p></div>`;
 }).join(''):tip('Enact a policy package to begin a before-and-after record. A review is retained after 180 days.'))+
 head('Freight in the real supply chain')+strip('Cargo currently travelling',(G.freight||[]).length+' consignments')+strip('Cargo and sampled trips completed',fmt(G.transport.arrived))+strip('Blocked cargo-days',fmt(G.transport.delayed))+
 (G.freight||[]).slice(0,8).map(s=>`<div class="entry"><strong>${fmt(s.qty)} ${esc(s.good)}</strong><small>${esc(G.firms[s.from]?.name)} → ${esc(G.firms[s.to]?.name)}<br>${s.delayed?'Delayed by access interruption':s.remaining+' day(s) remaining'} · goods remain owned in transit</small></div>`).join('')+
 head('Physical goods & clearing prices')+`<table class="report-table"><tr><td>Commodity</td><td>Inventory incl. cargo</td><td>Unit price</td></tr>${goodsBalance().map(a=>`<tr><td>${esc(a.good)}</td><td>${fmt(a.stock)}</td><td>${money(a.price)}</td></tr>`).join('')}</table>`+tip('Production, transformation, household use, imports, exports and cargo are counted separately. Wholesale prices adjust gradually to inventory coverage and regional demand.')+head('Recent investment accounts')+G.transactions.slice(-18).reverse().map(t=>`<div class="entry"><strong>${money(t.amount)} · ${esc(t.reason)}</strong><small>Day ${t.day} · ${esc(t.from)} → ${esc(t.to)}</small></div>`).join('');
}
const economyOriginal=renderEconomy;
renderEconomy=function(){return economyOriginal()+renderEconomicAtlas();};
const inspectOriginal=renderInspectFull;
renderInspectFull=function(){
 let html=inspectOriginal(),b=selected?.id?readBuild(selected.id):null;if(!b)return html;
 const owner=b.owner>=0?'The '+(G.households[b.owner]?.name||'unknown')+' household':b.owner===-2?G.investors[0].name:'Regional owner / public authority';
 html+=head('Parcel title & investment')+strip('Recorded owner',owner)+strip('Property valuation',money(b.value))+strip('Legal land footprint',footprintOf(b).length+' tiles')+strip('Physical condition',Math.round(b.condition)+' / 100');
 if(b.kind==='worksite'||b.redevelopment){const p=G.projects.find(p=>p.id===b.id);if(p)html+=head('Construction progress')+strip('Responsible builder',p.builder||'Crew assignment pending')+strip('Work days remaining',p.remaining)+strip('Days stalled',p.stalledDays||0)+tip(p.reason||'Construction financed; crew and materials are allocated daily.');}
 if(b.investment){const q=b.investment;html+=strip('Investment approved','Day '+q.day)+strip('Expected operating yield',(q.yield*100).toFixed(1)+'%')+strip('Funding hurdle',(q.hurdle*100).toFixed(1)+'%')+strip('Construction budget',money(q.cost))+strip('Land consideration',money(q.land))+tip('Expected returns are the developer’s estimate at approval; realized returns can differ.');}
 html+=G.transactions.filter(t=>t.entity===b.id).slice(-5).reverse().map(t=>`<div class="entry"><strong>${esc(t.reason)}</strong><small>Day ${t.day} · ${money(t.amount)} · ${esc(t.from)} → ${esc(t.to)}</small></div>`).join('');
 return html;
};
const settingsOriginal=renderSettingsFull;
renderSettingsFull=function(){
 const p=perfStats;
 return `<div class="btnrow"><button id="recoverAutosave">Recover previous autosave</button></div>`+head('Views of the Vale')+`<div class="maptool-row"><button id="nightView">${nightMode?'Morning light':'Evening light'}</button><button data-district="all">Whole borough</button><button data-district="main">Market district</button><button data-district="farms">Farm belt</button><button data-view="land">Land values</button><button data-view="roads">Road access</button></div>`+
 head('Session diagnostics')+strip('Draw CPU median / p95',percentile(p.frames,.5).toFixed(2)+' / '+percentile(p.frames,.95).toFixed(2)+' ms')+strip('Daily simulation median / p95',percentile(p.ticks,.5).toFixed(2)+' / '+percentile(p.ticks,.95).toFixed(2)+' ms')+strip('Requested / admitted speed',speed+'× / '+p.effective.toFixed(1)+'×')+strip('Queued simulation',p.backlog.toFixed(1)+' days')+strip('Largest cash ledger drift',money(G.accounts?.maxError||0))+tip('CPU timings in this session are not device FPS or a thermal measurement. Time control reduces its admitted rate when work cannot fit; it never drops economic days.')+
 settingsOriginal();
};
function navigateDistrict(which){
 const list=which==='farms'?G.buildings.filter(b=>b.kind==='farm'):which==='main'?G.buildings.filter(b=>b.firm>=0&&!['farm','forestry','quarry'].includes(b.kind)):G.buildings;
 if(!list.length)return;const x=list.reduce((n,b)=>n+b.x,0)/list.length,y=list.reduce((n,b)=>n+b.y,0)/list.length,p=iso(x,y);
 cam.x=p[0];cam.y=p[1]+18;cam.zoom=which==='all'?.59:1.35;closePanel();dirty=true;
}
document.addEventListener('click',e=>{
 const b=e.target.closest('button');if(!b||!G)return;
 if(b.id==='recoverAutosave'){try{const e=JSON.parse(localStorage.getItem('townledger-v6-backup'));if(e&&e.checksum===checksum(e.payload)&&hydrateSave(e.payload)){toast('Previous autosave recovered. Export it to keep a separate copy.');renderPanel('settings');}else toast('No valid earlier autosave is available.');}catch(_){toast('No valid earlier autosave is available.');}}
 if(b.id==='nightView'){nightMode=!nightMode;atlas.clear();dirty=true;renderPanel('settings');}
 if(b.dataset.district)navigateDistrict(b.dataset.district);
 if(b.dataset.view){overlay=b.dataset.view;closePanel();dirty=true;toast(overlay==='land'?'Land values: green low · gold middle · copper high':'Road access: green connected · copper disconnected');}
});
// Android uses the system document picker; desktop retains the text archive workflow.
window.__townArchive={
 suspend:()=>{save();},
 export:()=>archivePayload(),
 restore:text=>{const ok=hydrateSave(text);if(ok){save();$('welcome').style.display='none';dirty=true;staticDirty=true;toast('Town restored with its property, bank, cargo and resident records.');}else toast('Archive rejected. The current town is unchanged.');return ok;},
 back:()=>{if($('helpDialog').style.display!=='none'){$('helpDialog').style.display='none';return true;}if(active){closePanel();return true;}return false;}
};
const originalExport=exportSave,originalImport=importSave;
exportSave=function(){if(window.AndroidArchive)window.AndroidArchive.writeBackup(archivePayload());else originalExport();};
importSave=function(){if(window.AndroidArchive)window.AndroidArchive.openBackup();else originalImport();};

if($('townSeed')){try{$('townSeed').value=String(crypto.getRandomValues(new Uint32Array(1))[0]||42);}catch(_){$('townSeed').value=String(Date.now()%4294967295||42);}}

// SOURCE: 95-audio.js
// Licensed synthesized effects from the original TownLedger project, played only after interaction.
let soundEnabled=true;try{soundEnabled=localStorage.getItem('townledger-audio')!=='off'}catch(e){};let ambient=null,ambientFile='';const audioCache={};
function refreshAmbience(){if(!soundEnabled||!G||document.hidden){if(ambient)ambient.pause();return}const name=G.weather==='rain'||G.weather==='storm'?'rain':'village';if(name!==ambientFile){if(ambient)ambient.pause();ambient=new Audio('sound/'+name+'.wav');ambient.loop=true;ambient.volume=.10;ambientFile=name}ambient.play().catch(()=>{})}function playSfx(name){if(!soundEnabled)return;try{let a=audioCache[name];if(!a){a=new Audio('sound/'+name+'.wav');a.volume=.22;audioCache[name]=a}a.pause();a.currentTime=0;a.play().catch(()=>{})}catch(e){}}
document.addEventListener('click',e=>{let b=e.target.closest('button');if(!b)return;let id=b.id;if(id==='newTown'||id==='enactPolicy'||id==='borrow'||id==='repay')playSfx('coin');else if(id==='saveNow')playSfx('save');else if(b.dataset.build!==undefined)playSfx('zone');else if(b.dataset.eventChoice!==undefined)playSfx('coin');else playSfx('click')},{passive:true});

// SOURCE: 99-instrumentation.js
// Read-only / test instrumentation. No remote telemetry is used.
window.__townTest={view:()=>({camera:{...cam},touchCount:touches.size,pointer:{down:pointer.down,moved:pointer.moved,pinch:pointer.pinch}}),goods:()=>goodsBalance(),validate:()=>validateTown(),observations:()=>G.observations,perf:()=>perfStats,capture:(opts={})=>{if(opts.month){G.month=opts.month;staticDirty=true}if(opts.night!==undefined)nightMode=opts.night;if(opts.overlay!==undefined)overlay=opts.overlay;if(opts.zoom)cam.zoom=opts.zoom;if(opts.x)cam.x=opts.x;if(opts.y)cam.y=opts.y;dirty=true;updateHeader();draw();return true;},systems:()=>({housing:G.housingMarket,investors:G.investors,accounts:G.accounts,transactions:G.transactions,experiments:G.policyExperiments}),inbox:()=>G.councilInbox||[],offerPetition:()=>offerCouncilEvent(),reviewPetition:reviewCouncilInbox,finance:()=>({banks:G.banks,loans:G.loans,indicators:G.finance,deposits:G.banks.map(b=>bankDeposits(b.id))}),takeLoan:(kind,id,amount,term)=>bankLoan(kind,id,amount,term),bankFailure:(id)=>liquidateBank(G.banks[id],'Test insolvency'),reverseLand:()=>reverseRedevelopment(),renderBench:(n=100)=>{let t=performance.now();for(let i=0;i<n;i++){dirty=true;draw()}return Math.round((performance.now()-t)/n*100)/100},advanceTraffic:(dt=1)=>{trafficUpdate(dt);return traffic.length},traffic:()=>traffic.map(v=>({id:v.id,route:v.path,position:vehiclePosition(v),segment:v.segment,fraction:v.fraction,wait:v.wait,age:v.age})),road:()=>roadMetrics(),regional:()=>({landUse:G?.landUse,fieldCount:G?.fieldCount,airport:G?.airport,demand:cityDemand(),startFields:()=>farmDistrictExpansion(cityDemand()),startRedevelopment:()=>urbanRedevelopment(cityDemand()),startAirfield:()=>airfieldInvestment(cityDemand()),airfieldCandidate:()=>airfieldCandidate(),firmTypes:G?.firms.reduce((t,f)=>(t[f.kind]=(t[f.kind]||0)+Number(!f.closed),t),{})}),development:()=>({development:G?.development,metro:G?.metro,privateRoads:G?.privateRoads}),autogrow:()=>autonomousDevelopment(),path:(a,b)=>routeBetween(a,b),spawn:()=>beginVehicle(),invalidateRoads:()=>invalidateRoads(),get:()=>({day:G?.day,treasury:G?.treasury,debt:G?.debt,population:G?.stats.population,employment:G?.stats.employment,hardship:G?.stats.hardship,businesses:G?.stats.businesses,approval:G?.council.approval,cases:G?.cases.length,total:G?totalMoney():0,regional:G?.region,hhCash:G?.households.reduce((n,h)=>n+h.cash,0),firmCash:G?.firms.reduce((n,f)=>n+f.cash,0),events:G?.events.length,policy:G?.policy,stats:G?.stats,achievements:G?.achievements,pending:!!pendingEvent}),
 step:(n=1)=>{simulationBusy=true;try{for(let i=0;i<n;i++){if(pendingEvent){const ix=pendingEvent.choices.findIndex(c=>!c.cost||G.treasury>=c.cost);$('eventChoices').querySelectorAll('button')[Math.max(0,ix)]?.click()}tick()}}finally{simulationBusy=false;updateHeader();}return G.stats},
 save:()=>archivePayload(),load:(t)=>hydrateSave(t),choose:(i)=>{$('eventChoices').querySelectorAll('button')[i]?.click()},
 reset:(sc='settlement',seedValue=42)=>{chosenScenario=sc;seed(seedValue);invalidateRoads();updateHeader();return G.stats},set:(k,v)=>{G.policy[k]=v;recompute()}};
})();
