Build instructions: docs/BUILD.md
Install/save guidance: docs/INSTALL-AND-SAVES-7.1.1.md
The standalone APK and QA/media are separate deliverables. No signing key is included.
